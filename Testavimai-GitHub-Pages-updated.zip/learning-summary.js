const summaryKey = "testavimai-subject-learning-summary";
const testHistoryKey = "testavimai-test-result-history";
const weeklyActivityKey = "testavimai-weekly-question-activity";

function readSummary() {
  try {
    const stored = JSON.parse(localStorage.getItem(summaryKey) || "{}");
    if (!stored || typeof stored !== "object" || Array.isArray(stored)) {
      throw new Error("Dalykų pažangos duomenų formatas netinkamas.");
    }
    return Object.fromEntries(Object.entries(stored).filter(([subject, stats]) => {
      const valid = typeof subject === "string"
        && stats && Number.isSafeInteger(stats.total) && stats.total >= 0
        && Number.isSafeInteger(stats.correct) && stats.correct >= 0
        && stats.correct <= stats.total;
      if (!valid) console.error("Praleistas netinkamas dalykų pažangos įrašas.", subject);
      return valid;
    }));
  } catch (error) {
    console.error("Nepavyko nuskaityti dalykų pažangos suvestinės.", error);
    return {};
  }
}

export function getSubjectSummary() {
  return readSummary();
}

export function recordSubjectAttempt(subject, isCorrect, topic = "Bendros žinios") {
  if (typeof subject !== "string" || !subject.trim() || typeof isCorrect !== "boolean") {
    throw new TypeError("Dalykų pažangos įrašui perduoti netinkami duomenys.");
  }
  const summary = readSummary();
  const previous = summary[subject] || { total: 0, correct: 0 };
  const topics = previous.topics && typeof previous.topics === "object" ? previous.topics : {};
  const previousTopic = topics[topic] || { total: 0, correct: 0 };
  summary[subject] = {
    total: Number(previous.total || 0) + 1,
    correct: Number(previous.correct || 0) + Number(isCorrect),
    topics: {
      ...topics,
      [topic]: {
        total: Number(previousTopic.total || 0) + 1,
        correct: Number(previousTopic.correct || 0) + Number(isCorrect),
      },
    },
  };
  try {
    localStorage.setItem(summaryKey, JSON.stringify(summary));
  } catch (error) {
    console.error("Nepavyko išsaugoti dalykų pažangos suvestinės.", error);
    throw error;
  }
  try {
    const activity = JSON.parse(localStorage.getItem(weeklyActivityKey) || "[]");
    const validActivity = Array.isArray(activity) ? activity.filter((entry) =>
      typeof entry?.date === "string" && Number.isSafeInteger(entry.count) && entry.count >= 0,
    ) : [];
    const today = new Date();
    const date = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    const todayEntry = validActivity.find((entry) => entry.date === date);
    if (todayEntry) todayEntry.count += 1;
    else validActivity.push({ date, count: 1 });
    localStorage.setItem(weeklyActivityKey, JSON.stringify(validActivity.slice(-14)));
  } catch (error) {
    console.error("Nepavyko atnaujinti savaitės klausimų progreso.", error);
  }
  document.dispatchEvent(new CustomEvent("testavimai:subject-progress", { detail: summary }));
  return summary;
}

export function getWeeklyQuestionCount() {
  try {
    const activity = JSON.parse(localStorage.getItem(weeklyActivityKey) || "[]");
    if (!Array.isArray(activity)) throw new Error("Savaitės aktyvumo duomenų formatas netinkamas.");
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const monday = new Date(now);
    monday.setDate(now.getDate() - (now.getDay() + 6) % 7);
    return activity.filter((entry) => {
      if (typeof entry?.date !== "string" || !Number.isSafeInteger(entry.count) || entry.count < 0) return false;
      const date = new Date(`${entry.date}T00:00:00`);
      return !Number.isNaN(date.getTime()) && date >= monday && date <= now;
    }).reduce((total, entry) => total + entry.count, 0);
  } catch (error) {
    console.error("Nepavyko nuskaityti savaitės klausimų progreso.", error);
    return 0;
  }
}

export function recordTestResult({ title, subject = "", difficulty = "", correct, total }) {
  if (typeof title !== "string" || !title.trim() || !Number.isSafeInteger(correct)
    || !Number.isSafeInteger(total) || total < 1 || correct < 0 || correct > total) {
    throw new TypeError("Testo rezultato įrašui perduoti netinkami duomenys.");
  }
  const history = getTestHistory();
  history.unshift({
    title: title.trim().slice(0, 120),
    subject: String(subject).slice(0, 80),
    difficulty: String(difficulty).slice(0, 30),
    correct,
    total,
    completedAt: new Date().toISOString(),
  });
  try {
    localStorage.setItem(testHistoryKey, JSON.stringify(history.slice(0, 20)));
  } catch (error) {
    console.error("Nepavyko išsaugoti testų istorijos.", error);
    throw error;
  }
  return history.slice(0, 20);
}

export function getTestHistory() {
  try {
    const stored = JSON.parse(localStorage.getItem(testHistoryKey) || "[]");
    if (!Array.isArray(stored)) throw new Error("Testų istorijos formatas netinkamas.");
    return stored.filter((entry) => entry
      && typeof entry.title === "string"
      && Number.isSafeInteger(entry.correct)
      && Number.isSafeInteger(entry.total)
      && entry.total > 0
      && entry.correct >= 0
      && entry.correct <= entry.total
      && typeof entry.completedAt === "string").slice(0, 20);
  } catch (error) {
    console.error("Nepavyko nuskaityti testų istorijos.", error);
    return [];
  }
}
