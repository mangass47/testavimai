const menuToggle = document.querySelector(".menu-toggle");

if (menuToggle) {
  const backdrop = document.createElement("button");
  backdrop.className = "site-drawer-backdrop";
  backdrop.type = "button";
  backdrop.tabIndex = -1;
  backdrop.setAttribute("aria-label", "Uždaryti meniu");

  const drawer = document.createElement("aside");
  drawer.className = "site-drawer";
  drawer.id = "site-drawer";
  drawer.setAttribute("aria-label", "Svetainės meniu");
  drawer.setAttribute("aria-hidden", "true");
  drawer.innerHTML = `
    <div class="site-drawer-heading">
      <span class="brand" data-i18n="menu_heading">Mokymosi erdvė</span>
      <button class="site-drawer-close" type="button" aria-label="Uždaryti meniu">×</button>
    </div>
    <span class="site-drawer-kicker" data-i18n="menu_kicker">GREITOS NUORODOS</span>
    <nav class="site-drawer-links">
      <a href="profilis.html#profile-preferences"><span class="drawer-link-icon">⚙</span><span><strong data-i18n="menu_settings">Nustatymai</strong><small data-i18n="menu_settings_desc">Kalba ir spalvų temos</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="praktika.html?veikla=tips"><span class="drawer-link-icon">✳</span><span><strong data-i18n="menu_tips">Patarimai mokantis</strong><small data-i18n="menu_tips_desc">Kaip geriau įsiminti temas</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="praktika.html?veikla=assessment"><span class="drawer-link-icon">✎</span><span><strong data-i18n="menu_assessment">Pasikartok atsiskaitymui</strong><small data-i18n="menu_assessment_desc">Užduotys 7–10 klasių temoms</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="praktika.html?veikla=rewards"><span class="drawer-link-icon">◇</span><span><strong>Rewards · apdovanojimai</strong><small>Dėžutės, ženkleliai ir jų atlygiai</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="profilis.html#profile-badges"><span class="drawer-link-icon">✦</span><span><strong>Mano ženkleliai</strong><small>Pasirink, kurį rodyti profilyje</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="friends.html"><span class="drawer-link-icon">♡</span><span><strong>Draugai</strong><small>Užklausos ir tavo draugų sąrašas</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="praktika.html?veikla=weekly"><span class="drawer-link-icon">✓</span><span><strong data-i18n="menu_weekly">Savaitės planas</strong><small data-i18n="menu_weekly_desc">Maži tikslai ir pažanga</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="pamokos.html#pamokos"><span class="drawer-link-icon">▤</span><span><strong data-i18n="menu_lessons">Dalykai ir pamokos</strong><small data-i18n="menu_lessons_desc">Matematika, kalba ir daugiau</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="praktika.html"><span class="drawer-link-icon">◎</span><span><strong data-i18n="menu_modes">Praktikavimosi būdai</strong><small data-i18n="menu_modes_desc">Testai, kortelės, užduotys</small></span><span class="drawer-link-arrow">→</span></a>
      <a href="lyderiai.html"><span class="drawer-link-icon">♛</span><span><strong data-i18n="menu_leaderboard">Leaderboard</strong><small data-i18n="menu_leaderboard_desc">XP taškai ir mokinių pažanga</small></span><span class="drawer-link-arrow">→</span></a>
    </nav>
    <form class="drawer-friend-search" id="drawer-friend-search-form">
      <label for="drawer-friend-search-input">Rasti draugą pagal vardą arba @vardą</label>
      <div><input id="drawer-friend-search-input" type="search" minlength="2" maxlength="40" placeholder="@mokinys" required /><button type="submit" aria-label="Ieškoti draugo">Ieškoti</button></div>
      <p class="drawer-friend-search-status" id="drawer-friend-search-status" role="status"></p>
      <ul class="drawer-friend-search-results" id="drawer-friend-search-results"></ul>
    </form>
    <div class="site-drawer-help">
      <strong data-i18n="menu_help">Reikia pagalbos?</strong>
      <p data-i18n="menu_help_desc">Parašyk mums — mielai padėsime.</p>
      <a href="mailto:pagalba@testavimai.lt"><span data-i18n="menu_contact">Susisiekti</span> <span>↗</span></a>
    </div>
    <div class="site-drawer-legal"><a href="privacy-policy.html">Privatumas ir slapukai</a><a href="terms.html">Naudojimo sąlygos</a><button type="button" data-cookie-settings>Slapukų pasirinkimas</button></div>
    <p class="site-drawer-footer">Mokykis savo tempu. ✳</p>
    <div class="drawer-code-entry">
      <button class="drawer-code-toggle" id="drawer-code-toggle" type="button" aria-expanded="false" aria-controls="drawer-code-panel">kodai</button>
      <form class="drawer-code-panel" id="drawer-code-panel" hidden>
        <label for="drawer-code-input">Atlygio kodas</label>
        <div class="drawer-code-form-row">
          <input id="drawer-code-input" name="code" type="text" minlength="8" maxlength="40" autocomplete="off" placeholder="Įrašyk kodą" required />
          <button type="submit">Patikrinti</button>
        </div>
        <p class="drawer-code-status" id="drawer-code-status" role="status" aria-live="polite"></p>
        <div class="drawer-code-reward" id="drawer-code-reward" hidden>
          <strong id="drawer-code-reward-title"></strong>
          <p id="drawer-code-reward-description"></p>
          <button type="button" id="drawer-code-claim">Atsiimti atlygį</button>
        </div>
      </form>
    </div>
  `;

  document.body.append(backdrop, drawer);
  const closeButton = drawer.querySelector(".site-drawer-close");
  const searchForm = drawer.querySelector("#drawer-friend-search-form");
  const searchStatus = drawer.querySelector("#drawer-friend-search-status");
  const searchResults = drawer.querySelector("#drawer-friend-search-results");
  const codeToggle = drawer.querySelector("#drawer-code-toggle");
  const codeForm = drawer.querySelector("#drawer-code-panel");
  const codeInput = drawer.querySelector("#drawer-code-input");
  const codeStatus = drawer.querySelector("#drawer-code-status");
  const codeReward = drawer.querySelector("#drawer-code-reward");
  const codeClaimButton = drawer.querySelector("#drawer-code-claim");
  let pendingRewardCode = "";
  let pendingRewardTheme = "";

  codeToggle.addEventListener("click", () => {
    const expanded = codeToggle.getAttribute("aria-expanded") === "true";
    codeToggle.setAttribute("aria-expanded", String(!expanded));
    codeForm.hidden = expanded;
    if (!expanded) codeInput.focus();
  });
  codeForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const submitButton = codeForm.querySelector('[type="submit"]');
    submitButton.disabled = true;
    codeReward.hidden = true;
    codeStatus.textContent = "Tikrinamas kodas…";
    pendingRewardCode = "";
    pendingRewardTheme = "";
    codeClaimButton.disabled = false;
    codeClaimButton.textContent = "Atsiimti atlygį";
    try {
      const { redeemPromoRewardCode } = await import("./progress.js");
      const reward = await redeemPromoRewardCode(codeInput.value);
      pendingRewardCode = reward.code;
      pendingRewardTheme = reward.theme_id;
      drawer.querySelector("#drawer-code-reward-title").textContent = reward.title;
      drawer.querySelector("#drawer-code-reward-description").textContent = reward.description;
      codeReward.hidden = false;
      codeStatus.textContent = "Kodas galioja. Atsiimk parodytą atlygį.";
    } catch (error) {
      console.error("Atlygio kodo patikrinti nepavyko.", error);
      codeStatus.textContent = error.message;
    } finally {
      submitButton.disabled = false;
    }
  });
  codeClaimButton.addEventListener("click", async () => {
    if (!pendingRewardCode) return;
    codeClaimButton.disabled = true;
    codeStatus.textContent = "Atsiimamas atlygis…";
    try {
      const { claimPromoRewardCode } = await import("./progress.js");
      const reward = await claimPromoRewardCode(pendingRewardCode);
      pendingRewardTheme = reward.theme_id;
      document.dispatchEvent(new CustomEvent("testavimai:select-theme", { detail: pendingRewardTheme }));
      codeStatus.textContent = reward.already_owned
        ? `Atlygis atsiimtas. Šią temą jau turėjai, todėl ji pritaikyta.`
        : `Atlygis „${reward.title}“ atsiimtas ir tema pritaikyta.`;
      codeClaimButton.textContent = "Atlygis atsiimtas ✓";
    } catch (error) {
      console.error("Atlygio kodo atsiimti nepavyko.", error);
      codeStatus.textContent = error.message;
      codeClaimButton.disabled = false;
    }
  });
  drawer.querySelector("[data-cookie-settings]").addEventListener("click", () => {
    document.dispatchEvent(new CustomEvent("testavimai:cookie-settings"));
  });

  searchForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = drawer.querySelector("#drawer-friend-search-input");
    const submit = searchForm.querySelector('button[type="submit"]');
    submit.disabled = true;
    searchStatus.textContent = "Ieškoma viešų paskyrų…";
    searchResults.replaceChildren();
    try {
      const { searchPublicUsers, sendFriendRequest } = await import("./progress.js");
      const users = await searchPublicUsers(input.value);
      if (!users.length) {
        searchStatus.textContent = "Viešų profilių nerasta.";
        return;
      }
      searchStatus.textContent = `Rasta paskyrų: ${users.length}. Privačių profilių paieška nerodo.`;
      users.forEach((user) => {
        const row = document.createElement("li");
        const identity = document.createElement("span");
        identity.textContent = `@${user.username} · ${user.display_name}`;
        const addButton = document.createElement("button");
        addButton.type = "button";
        addButton.textContent = "Pridėti";
        addButton.addEventListener("click", async () => {
          addButton.disabled = true;
          try {
            const result = await sendFriendRequest(user.user_id);
            addButton.textContent = result.status === "accepted" ? "Draugai ✓" : "Užklausa išsiųsta";
          } catch (error) {
            console.error("Draugo užklausos išsiųsti nepavyko.", error);
            searchStatus.textContent = error.message;
            addButton.disabled = false;
          }
        });
        row.append(identity, addButton);
        searchResults.append(row);
      });
    } catch (error) {
      console.error("Draugų paieška nepavyko.", error);
      searchStatus.textContent = error.message;
    } finally {
      submit.disabled = false;
    }
  });

  function closeDrawer() {
    drawer.classList.remove("is-open");
    backdrop.classList.remove("is-visible");
    document.documentElement.classList.remove("site-menu-open");
    drawer.setAttribute("aria-hidden", "true");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.focus();
  }

  function openDrawer() {
    drawer.classList.add("is-open");
    backdrop.classList.add("is-visible");
    document.documentElement.classList.add("site-menu-open");
    drawer.setAttribute("aria-hidden", "false");
    menuToggle.setAttribute("aria-expanded", "true");
    closeButton.focus();
  }

  menuToggle.addEventListener("click", () => {
    if (drawer.classList.contains("is-open")) closeDrawer();
    else openDrawer();
  });
  closeButton.addEventListener("click", closeDrawer);
  backdrop.addEventListener("click", closeDrawer);
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && drawer.classList.contains("is-open")) closeDrawer();
  });
  drawer.querySelectorAll("a").forEach((link) => link.addEventListener("click", closeDrawer));

}

import("./role-ui.js").catch((error) => console.warn("Vaidmens sąsajos nepavyko įkelti.", error));
