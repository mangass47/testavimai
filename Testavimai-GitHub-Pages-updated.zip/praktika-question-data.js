const basePracticeQuestions = [
  { id: "math-fraction", subject: "matematika", prompt: "Kiek yra ¾ iš 20?", answers: ["10", "12", "15", "18"], correct: 2, explanation: "20 ÷ 4 × 3 = 15." },
  { id: "math-angle", subject: "matematika", prompt: "Kiek laipsnių sudaro statusis kampas?", answers: ["45°", "90°", "180°", "360°"], correct: 1, explanation: "Statusis kampas yra 90°." },
  { id: "math-decimal", subject: "matematika", prompt: "Kokia trupmena lygi 0,5?", answers: ["½", "⅓", "¼", "¾"], correct: 0, explanation: "0,5 = 5/10 = ½." },
  { id: "language-adverb", subject: "lietuvių kalba", prompt: "Kokia kalbos dalis yra žodis „greitai“?", answers: ["Daiktavardis", "Veiksmažodis", "Prieveiksmis", "Būdvardis"], correct: 2, explanation: "„Greitai“ nusako, kaip vyksta veiksmas, todėl tai prieveiksmis." },
  { id: "language-comma", subject: "lietuvių kalba", prompt: "Kuriame sakinyje kablelis padėtas taisyklingai?", answers: ["Žinau, kad pavyks.", "Žinau kad, pavyks.", "Žinau kad pavyks,", "Žinau kad pavyks."], correct: 0, explanation: "Šalutinis dėmuo „kad pavyks“ atskiriamas kableliu." },
  { id: "language-narrator", subject: "lietuvių kalba", prompt: "Kas yra pasakotojas kūrinyje?", answers: ["Skaitytojas", "Balsas, pasakojantis įvykius", "Visada autorius", "Kūrinio pavadinimas"], correct: 1, explanation: "Pasakotojas perteikia kūrinio įvykius, bet nebūtinai yra autorius." },
  { id: "biology-photosynthesis", subject: "biologija", prompt: "Ką augalai išskiria fotosintezės metu?", answers: ["Azotą", "Deguonį", "Druską", "Geležį"], correct: 1, explanation: "Fotosintezės metu augalai gamina gliukozę ir išskiria deguonį." },
  { id: "biology-cell", subject: "biologija", prompt: "Kurioje ląstelės dalyje saugoma genetinė informacija?", answers: ["Membranoje", "Citoplazmoje", "Branduolyje", "Sienelėje"], correct: 2, explanation: "Eukariotinės ląstelės branduolyje saugoma genetinė informacija." },
  { id: "biology-heart", subject: "biologija", prompt: "Kiek kamerų turi žmogaus širdis?", answers: ["Dvi", "Trys", "Keturias", "Šešias"], correct: 2, explanation: "Širdį sudaro du prieširdžiai ir du skilveliai." },
  { id: "history-act", subject: "istorija", prompt: "Kada pasirašytas Lietuvos Nepriklausomybės Aktas?", answers: ["1253 m. liepos 6 d.", "1918 m. vasario 16 d.", "1990 m. kovo 11 d.", "1940 m. birželio 15 d."], correct: 1, explanation: "Aktas pasirašytas Vilniuje 1918 m. vasario 16 d." },
  { id: "history-mindaugas", subject: "istorija", prompt: "Kada Mindaugas buvo karūnuotas Lietuvos karaliumi?", answers: ["1009 m.", "1253 m.", "1387 m.", "1410 m."], correct: 1, explanation: "Mindaugas karūnuotas 1253 m. liepos 6 d." },
  { id: "history-restoration", subject: "istorija", prompt: "Ką žymi 1990 m. kovo 11-oji?", answers: ["Lietuvos karūnavimą", "Nepriklausomybės atkūrimą", "Pirmąją konstituciją", "Lietuvos įstojimą į ES"], correct: 1, explanation: "1990 m. kovo 11 d. paskelbtas Lietuvos nepriklausomybės atkūrimas." },
  { id: "physics-speed", subject: "fizika", prompt: "Kaip apskaičiuojamas greitis?", answers: ["Laikas ÷ kelias", "Kelias ÷ laikas", "Kelias × laikas", "Jėga ÷ laikas"], correct: 1, explanation: "Greitis v = s/t: kelias padalytas iš laiko." },
  { id: "physics-force", subject: "fizika", prompt: "Kokiais vienetais matuojama jėga?", answers: ["Niutonais", "Amperais", "Voltais", "Metrais"], correct: 0, explanation: "Jėga matuojama niutonais (N)." },
  { id: "physics-sound", subject: "fizika", prompt: "Ko reikia garsui sklisti?", answers: ["Tik šviesos", "Medžiaginės terpės", "Vakuumo", "Elektros srovės"], correct: 1, explanation: "Garsui sklisti reikalinga medžiaginė terpė." },
];

const questionMetadata = {
  "math-fraction": { topic: "Trupmenos", difficulty: "easy", type: "Pasirinkimas", steps: ["Padalink 20 iš vardiklio 4: gauni 5.", "Padaugink 5 iš skaitiklio 3: gauni 15."] },
  "math-angle": { topic: "Geometrija", difficulty: "easy", type: "Pasirinkimas", steps: ["Statusis kampas pagal apibrėžimą yra lygus 90°.", "Palygink su atsakymų variantais ir pasirink 90°."] },
  "math-decimal": { topic: "Dešimtainės trupmenos", difficulty: "easy", type: "Pasirinkimas", steps: ["Užrašyk 0,5 kaip trupmeną: 5/10.", "Sutrumpink trupmeną iš 5: 1/2."] },
  "language-adverb": { topic: "Kalbos dalys", difficulty: "easy", type: "Pasirinkimas" },
  "language-comma": { topic: "Skyryba", difficulty: "medium", type: "Pasirinkimas" },
  "language-narrator": { topic: "Literatūros sąvokos", difficulty: "medium", type: "Pasirinkimas" },
  "biology-photosynthesis": { topic: "Fotosintezė", difficulty: "easy", type: "Pasirinkimas" },
  "biology-cell": { topic: "Ląstelė", difficulty: "medium", type: "Pasirinkimas" },
  "biology-heart": { topic: "Žmogaus kūnas", difficulty: "easy", type: "Pasirinkimas" },
  "history-act": { topic: "Lietuvos nepriklausomybė", difficulty: "medium", type: "Pasirinkimas" },
  "history-mindaugas": { topic: "Lietuvos valstybingumas", difficulty: "medium", type: "Pasirinkimas" },
  "history-restoration": { topic: "Nepriklausomybės atkūrimas", difficulty: "easy", type: "Pasirinkimas" },
  "physics-speed": { topic: "Judėjimas", difficulty: "easy", type: "Pasirinkimas", steps: ["Greitį žymime v, kelią – s, laiką – t.", "Padalink kelią iš laiko: v = s/t."] },
  "physics-force": { topic: "Jėgos", difficulty: "easy", type: "Pasirinkimas", steps: ["Jėgos SI vienetas pavadintas Izaoko Niutono garbei.", "Jėga matuojama niutonais, žymima N."] },
  "physics-sound": { topic: "Garsas", difficulty: "medium", type: "Pasirinkimas", steps: ["Garsas yra mechaninis virpesys.", "Virpesiams sklisti reikia medžiagos dalelių, todėl garsas nesklinda vakuume."] },
};

export const practiceQuestions = basePracticeQuestions.map((item) => ({
  ...item,
  ...questionMetadata[item.id],
}));

// Order: [en, es, ru, de, fr]; each entry is [prompt, answers|null, explanation].
const translationLanguages = ["en", "es", "ru", "de", "fr"];
const translationTable = {
  "math-fraction": [
    ["What is ¾ of 20?", null, "20 ÷ 4 × 3 = 15."],
    ["¿Cuánto es ¾ de 20?", null, "20 ÷ 4 × 3 = 15."],
    ["Сколько будет ¾ от 20?", null, "20 ÷ 4 × 3 = 15."],
    ["Wie viel sind ¾ von 20?", null, "20 ÷ 4 × 3 = 15."],
    ["Combien font ¾ de 20 ?", null, "20 ÷ 4 × 3 = 15."],
  ],
  "math-angle": [
    ["How many degrees is a right angle?", null, "A right angle is 90°."],
    ["¿Cuántos grados tiene un ángulo recto?", null, "Un ángulo recto mide 90°."],
    ["Сколько градусов в прямом угле?", null, "Прямой угол равен 90°."],
    ["Wie viele Grad hat ein rechter Winkel?", null, "Ein rechter Winkel hat 90°."],
    ["Combien de degrés mesure un angle droit ?", null, "Un angle droit mesure 90°."],
  ],
  "math-decimal": [
    ["Which fraction equals 0.5?", null, "0.5 = 5/10 = ½."],
    ["¿Qué fracción es igual a 0,5?", null, "0,5 = 5/10 = ½."],
    ["Какая дробь равна 0,5?", null, "0,5 = 5/10 = ½."],
    ["Welcher Bruch ist gleich 0,5?", null, "0,5 = 5/10 = ½."],
    ["Quelle fraction est égale à 0,5 ?", null, "0,5 = 5/10 = ½."],
  ],
  "language-adverb": [
    ["Which part of speech is the Lithuanian word “greitai” (“quickly”)?", ["Noun", "Verb", "Adverb", "Adjective"], "“Greitai” tells how an action happens, so it is an adverb."],
    ["¿Qué clase de palabra es la palabra lituana «greitai» («rápidamente»)?", ["Sustantivo", "Verbo", "Adverbio", "Adjetivo"], "«Greitai» indica cómo ocurre la acción, por lo tanto es un adverbio."],
    ["Какая это часть речи: литовское слово «greitai» («быстро»)?", ["Существительное", "Глагол", "Наречие", "Прилагательное"], "«Greitai» показывает, как происходит действие, поэтому это наречие."],
    ["Welche Wortart ist das litauische Wort „greitai“ („schnell“)?", ["Substantiv", "Verb", "Adverb", "Adjektiv"], "„Greitai“ sagt, wie eine Handlung geschieht – also ist es ein Adverb."],
    ["Quelle est la nature du mot lituanien « greitai » (« rapidement ») ?", ["Nom", "Verbe", "Adverbe", "Adjectif"], "« Greitai » indique comment se déroule l’action : c’est un adverbe."],
  ],
  "language-comma": [
    ["In which Lithuanian sentence is the comma placed correctly?", null, "The subordinate clause “kad pavyks” (“that it will work”) is separated by a comma."],
    ["¿En qué oración lituana la coma está bien colocada?", null, "La subordinada «kad pavyks» («que saldrá bien») se separa con coma."],
    ["В каком литовском предложении запятая поставлена правильно?", null, "Придаточное «kad pavyks» («что получится») отделяется запятой."],
    ["In welchem litauischen Satz steht das Komma richtig?", null, "Der Nebensatz „kad pavyks“ („dass es klappt“) wird durch ein Komma abgetrennt."],
    ["Dans quelle phrase lituanienne la virgule est-elle bien placée ?", null, "La subordonnée « kad pavyks » (« que ça réussira ») est séparée par une virgule."],
  ],
  "language-narrator": [
    ["Who is the narrator in a literary work?", ["The reader", "The voice that tells the events", "Always the author", "The title of the work"], "The narrator conveys the events of the work but is not necessarily the author."],
    ["¿Quién es el narrador en una obra literaria?", ["El lector", "La voz que cuenta los hechos", "Siempre el autor", "El título de la obra"], "El narrador transmite los hechos de la obra, pero no es necesariamente el autor."],
    ["Кто такой рассказчик в произведении?", ["Читатель", "Голос, рассказывающий о событиях", "Всегда автор", "Название произведения"], "Рассказчик передаёт события произведения, но не обязательно является автором."],
    ["Wer ist der Erzähler in einem literarischen Werk?", ["Der Leser", "Die Stimme, die die Ereignisse erzählt", "Immer der Autor", "Der Titel des Werks"], "Der Erzähler vermittelt die Ereignisse, ist aber nicht zwingend der Autor."],
    ["Qui est le narrateur dans une œuvre littéraire ?", ["Le lecteur", "La voix qui raconte les événements", "Toujours l’auteur", "Le titre de l’œuvre"], "Le narrateur rapporte les événements de l’œuvre, mais n’est pas forcément l’auteur."],
  ],
  "biology-photosynthesis": [
    ["What do plants release during photosynthesis?", ["Nitrogen", "Oxygen", "Salt", "Iron"], "During photosynthesis plants make glucose and release oxygen."],
    ["¿Qué liberan las plantas durante la fotosíntesis?", ["Nitrógeno", "Oxígeno", "Sal", "Hierro"], "En la fotosíntesis las plantas producen glucosa y liberan oxígeno."],
    ["Что выделяют растения при фотосинтезе?", ["Азот", "Кислород", "Соль", "Железо"], "При фотосинтезе растения создают глюкозу и выделяют кислород."],
    ["Was geben Pflanzen bei der Photosynthese ab?", ["Stickstoff", "Sauerstoff", "Salz", "Eisen"], "Bei der Photosynthese bilden Pflanzen Glukose und geben Sauerstoff ab."],
    ["Que libèrent les plantes lors de la photosynthèse ?", ["De l’azote", "De l’oxygène", "Du sel", "Du fer"], "Lors de la photosynthèse, les plantes produisent du glucose et libèrent de l’oxygène."],
  ],
  "biology-cell": [
    ["Which part of the cell stores genetic information?", ["Membrane", "Cytoplasm", "Nucleus", "Cell wall"], "Genetic information is stored in the nucleus of a eukaryotic cell."],
    ["¿En qué parte de la célula se guarda la información genética?", ["Membrana", "Citoplasma", "Núcleo", "Pared celular"], "La información genética se guarda en el núcleo de la célula eucariota."],
    ["В какой части клетки хранится генетическая информация?", ["Мембрана", "Цитоплазма", "Ядро", "Клеточная стенка"], "Генетическая информация хранится в ядре эукариотической клетки."],
    ["In welchem Teil der Zelle ist die Erbinformation gespeichert?", ["Membran", "Zytoplasma", "Zellkern", "Zellwand"], "Die Erbinformation liegt im Zellkern der eukaryotischen Zelle."],
    ["Dans quelle partie de la cellule l’information génétique est-elle stockée ?", ["La membrane", "Le cytoplasme", "Le noyau", "La paroi"], "L’information génétique est stockée dans le noyau de la cellule eucaryote."],
  ],
  "biology-heart": [
    ["How many chambers does the human heart have?", ["Two", "Three", "Four", "Six"], "The heart has two atria and two ventricles."],
    ["¿Cuántas cavidades tiene el corazón humano?", ["Dos", "Tres", "Cuatro", "Seis"], "El corazón tiene dos aurículas y dos ventrículos."],
    ["Сколько камер у сердца человека?", ["Две", "Три", "Четыре", "Шесть"], "Сердце состоит из двух предсердий и двух желудочков."],
    ["Wie viele Kammern hat das menschliche Herz?", ["Zwei", "Drei", "Vier", "Sechs"], "Das Herz besteht aus zwei Vorhöfen und zwei Kammern."],
    ["Combien de cavités possède le cœur humain ?", ["Deux", "Trois", "Quatre", "Six"], "Le cœur comprend deux oreillettes et deux ventricules."],
  ],
  "history-act": [
    ["When was the Act of Independence of Lithuania signed?", ["6 July 1253", "16 February 1918", "11 March 1990", "15 June 1940"], "The Act was signed in Vilnius on 16 February 1918."],
    ["¿Cuándo se firmó el Acta de Independencia de Lituania?", ["6 de julio de 1253", "16 de febrero de 1918", "11 de marzo de 1990", "15 de junio de 1940"], "El Acta se firmó en Vilna el 16 de febrero de 1918."],
    ["Когда был подписан Акт о независимости Литвы?", ["6 июля 1253 г.", "16 февраля 1918 г.", "11 марта 1990 г.", "15 июня 1940 г."], "Акт был подписан в Вильнюсе 16 февраля 1918 года."],
    ["Wann wurde die Unabhängigkeitserklärung Litauens unterzeichnet?", ["6. Juli 1253", "16. Februar 1918", "11. März 1990", "15. Juni 1940"], "Die Erklärung wurde am 16. Februar 1918 in Vilnius unterzeichnet."],
    ["Quand l’Acte d’indépendance de la Lituanie a-t-il été signé ?", ["6 juillet 1253", "16 février 1918", "11 mars 1990", "15 juin 1940"], "L’Acte a été signé à Vilnius le 16 février 1918."],
  ],
  "history-mindaugas": [
    ["When was Mindaugas crowned King of Lithuania?", null, "Mindaugas was crowned on 6 July 1253."],
    ["¿Cuándo fue coronado Mindaugas rey de Lituania?", null, "Mindaugas fue coronado el 6 de julio de 1253."],
    ["Когда Миндаугас был коронован королём Литвы?", null, "Миндаугас был коронован 6 июля 1253 года."],
    ["Wann wurde Mindaugas zum König von Litauen gekrönt?", null, "Mindaugas wurde am 6. Juli 1253 gekrönt."],
    ["Quand Mindaugas a-t-il été couronné roi de Lituanie ?", null, "Mindaugas a été couronné le 6 juillet 1253."],
  ],
  "history-restoration": [
    ["What does 11 March 1990 mark?", ["The coronation of Lithuania", "The restoration of independence", "The first constitution", "Lithuania joining the EU"], "On 11 March 1990 the restoration of Lithuania’s independence was declared."],
    ["¿Qué marca el 11 de marzo de 1990?", ["La coronación de Lituania", "El restablecimiento de la independencia", "La primera constitución", "La entrada de Lituania en la UE"], "El 11 de marzo de 1990 se proclamó el restablecimiento de la independencia de Lituania."],
    ["Что отмечает 11 марта 1990 года?", ["Коронацию Литвы", "Восстановление независимости", "Первую конституцию", "Вступление Литвы в ЕС"], "11 марта 1990 года было провозглашено восстановление независимости Литвы."],
    ["Woran erinnert der 11. März 1990?", ["An die Krönung Litauens", "An die Wiederherstellung der Unabhängigkeit", "An die erste Verfassung", "An den EU-Beitritt Litauens"], "Am 11. März 1990 wurde die Wiederherstellung der Unabhängigkeit Litauens ausgerufen."],
    ["Que marque le 11 mars 1990 ?", ["Le couronnement de la Lituanie", "Le rétablissement de l’indépendance", "La première constitution", "L’adhésion de la Lituanie à l’UE"], "Le 11 mars 1990, le rétablissement de l’indépendance de la Lituanie a été proclamé."],
  ],
  "physics-speed": [
    ["How is speed calculated?", ["Time ÷ distance", "Distance ÷ time", "Distance × time", "Force ÷ time"], "Speed v = s/t: distance divided by time."],
    ["¿Cómo se calcula la velocidad?", ["Tiempo ÷ distancia", "Distancia ÷ tiempo", "Distancia × tiempo", "Fuerza ÷ tiempo"], "Velocidad v = s/t: distancia dividida entre tiempo."],
    ["Как вычисляется скорость?", ["Время ÷ путь", "Путь ÷ время", "Путь × время", "Сила ÷ время"], "Скорость v = s/t: путь, делённый на время."],
    ["Wie berechnet man die Geschwindigkeit?", ["Zeit ÷ Strecke", "Strecke ÷ Zeit", "Strecke × Zeit", "Kraft ÷ Zeit"], "Geschwindigkeit v = s/t: Strecke geteilt durch Zeit."],
    ["Comment calcule-t-on la vitesse ?", ["Temps ÷ distance", "Distance ÷ temps", "Distance × temps", "Force ÷ temps"], "Vitesse v = d/t : la distance divisée par le temps."],
  ],
  "physics-force": [
    ["In which units is force measured?", ["Newtons", "Amperes", "Volts", "Metres"], "Force is measured in newtons (N)."],
    ["¿En qué unidades se mide la fuerza?", ["Newtons", "Amperios", "Voltios", "Metros"], "La fuerza se mide en newtons (N)."],
    ["В каких единицах измеряется сила?", ["Ньютонах", "Амперах", "Вольтах", "Метрах"], "Сила измеряется в ньютонах (Н)."],
    ["In welcher Einheit wird Kraft gemessen?", ["Newton", "Ampere", "Volt", "Meter"], "Kraft wird in Newton (N) gemessen."],
    ["Dans quelle unité mesure-t-on la force ?", ["Newtons", "Ampères", "Volts", "Mètres"], "La force se mesure en newtons (N)."],
  ],
  "physics-sound": [
    ["What does sound need to travel?", ["Only light", "A material medium", "A vacuum", "Electric current"], "Sound needs a material medium to travel."],
    ["¿Qué necesita el sonido para propagarse?", ["Solo luz", "Un medio material", "El vacío", "Corriente eléctrica"], "El sonido necesita un medio material para propagarse."],
    ["Что нужно звуку для распространения?", ["Только свет", "Вещественная среда", "Вакуум", "Электрический ток"], "Для распространения звука нужна вещественная среда."],
    ["Was braucht Schall, um sich auszubreiten?", ["Nur Licht", "Ein Medium (Stoff)", "Ein Vakuum", "Elektrischen Strom"], "Schall braucht ein stoffliches Medium, um sich auszubreiten."],
    ["De quoi le son a-t-il besoin pour se propager ?", ["Seulement de lumière", "D’un milieu matériel", "Du vide", "De courant électrique"], "Le son a besoin d’un milieu matériel pour se propager."],
  ],
};

export function localizeQuestion(item, lang) {
  const index = translationLanguages.indexOf(lang);
  const entry = index >= 0 ? translationTable[item.id]?.[index] : null;
  if (!entry) return item;
  return { ...item, prompt: entry[0], answers: entry[1] || item.answers, explanation: entry[2] };
}