(() => {
  const languageKey = "testavimai-language";
  const themeKey = "testavimai-theme";
  const accessibilityKeys = {
    largeText: "testavimai-accessibility-large-text",
    highContrast: "testavimai-accessibility-high-contrast",
    reducedMotion: "testavimai-accessibility-reduced-motion",
    showExplanations: "testavimai-show-answer-explanations",
  };
  const guestMode = sessionStorage.getItem("testavimai-demo-guest") === "true";
  const languages = ["lt", "en", "es", "ru", "de", "fr"];
  const themes = {
    ocean: ["#3978d4", "#285bb0", "#edf3fc", "#fff", "#e3eaf5"],
    coral: ["#d84e51", "#ae393d", "#fbeeee", "#fff", "#f0e0df"],
    sunshine: ["#bd8416", "#94680f", "#faf4e7", "#fff", "#eee5d2"],
    forest: ["#246b50", "#19533d", "#edf3ed", "#f8f9f7", "#e8ebe5"],
    tangerine: ["#df702d", "#b6521e", "#fbf0e9", "#fff", "#eee2d8"],
    violet: ["#7652ba", "#593b96", "#f1edf8", "#fff", "#e8e0f2"],
    rose: ["#cf5484", "#a53e68", "#faedf2", "#fff", "#efe0e6"],
    nocturne: ["#d5ad64", "#a8833e", "#16171d", "#101117", "#302e2d"],
    aurum: ["#d2b15d", "#a58a45", "#131923", "#0e131c", "#29313d"],
    velvet: ["#b18be5", "#8768ba", "#191621", "#12101a", "#332d40"],
    sapphire: ["#83b8ff", "#527dc1", "#151c2b", "#101621", "#303d53"],
    obsidian: ["#a6b4c8", "#718198", "#1a2028", "#11161d", "#303943"],
    amethyst: ["#c2a0ff", "#9273d1", "#21192e", "#171221", "#3b2f51"],
    emerald: ["#70d7ac", "#48a881", "#14251f", "#0e1915", "#29483b"],
    crimson: ["#ff8995", "#d45c6b", "#2a171e", "#1b1015", "#4a2c35"],
    arctic: ["#75d9e8", "#43a5b6", "#14242b", "#0e191f", "#29424b"],
    rose_noir: ["#f08bbd", "#c56394", "#291923", "#1b111a", "#472b3e"],
    lavender: ["#7957bd", "#5d4196", "#f3efff", "#faf8ff", "#e5ddf5"],
    peach: ["#b95f42", "#934832", "#fff1e8", "#fffaf6", "#f1ddd1"],
    lagoon: ["#168a91", "#116d73", "#e8f8f7", "#f5fcfb", "#d3ebea"],
    blossom: ["#bd5680", "#964263", "#fff0f5", "#fff9fb", "#efd9e3"],
    sky: ["#3975bd", "#2c5d98", "#edf5ff", "#f8fbff", "#dce8f6"],
    buttercream: ["#987016", "#76550e", "#fff8df", "#fffdf3", "#eee4bd"],
    mint: ["#32825f", "#246348", "#eaf8ee", "#f8fdf9", "#d9ecde"],
    pearl: ["#47798a", "#355d69", "#e7f2f4", "#f4fafb", "#dbe9ed"],
    rosewater: ["#b75470", "#934158", "#f8e8ed", "#fff5f7", "#f1dfe5"],
    lemon: ["#9a7a22", "#735b18", "#f6efce", "#fffbed", "#efe5bc"],
  };
  const copy = {
    lt: {
      nav_practice: "Praktikuokis", nav_assessment: "Atsiskaitymui", nav_tests: "Testuoti save", nav_lessons: "Dienos užduotys", nav_leaderboard: "Leaderboard",
      menu_heading: "Mokymosi erdvė", menu_kicker: "GREITOS NUORODOS", menu_settings: "Nustatymai", menu_settings_desc: "Kalba ir spalvų temos",
      menu_tips: "Patarimai mokantis", menu_tips_desc: "Kaip geriau įsiminti temas", menu_weekly: "Savaitės planas",
      menu_assessment: "Pasikartok atsiskaitymui", menu_assessment_desc: "Užduotys 7–10 klasių temoms",
      menu_weekly_desc: "Maži tikslai ir pažanga", menu_lessons: "Dalykai ir pamokos", menu_lessons_desc: "Matematika, kalba ir daugiau",
      menu_modes: "Praktikavimosi būdai", menu_modes_desc: "Testai, kortelės, užduotys", menu_leaderboard: "Leaderboard", menu_leaderboard_desc: "XP taškai ir mokinių pažanga", menu_help: "Reikia pagalbos?",
      menu_help_desc: "Parašyk mums — mielai padėsime.", menu_contact: "Susisiekti",
      profile_button: "Profilis", sign_out: "Atsijungti", home: "Į pradžią", profile_heading: "Mano profilis.",
      profile_intro: "Čia gali peržiūrėti paskyros informaciją ir mokymosi nustatymus.",
      profile_tabs: "Profilio skiltys", account: "Paskyros informacija", security: "Saugumas ir privatumas",
      content: "Turinio apribojimai", subscriptions: "Prenumeratos", notifications: "Pranešimai",
      website_preferences: "Svetainės nuostatos", account_kicker: "PASKYRA", account_desc: "Tavo vardas, mokykla ir klasė naudojami mokymosi profilyje.",
      first_name: "Vardas", last_name: "Pavardė", school: "Mokykla", grade: "Klasė", email: "El. paštas",
      email_note: "El. pašto adresą ir jo keitimą tvarko prisijungimo paslauga.", save: "Išsaugoti pakeitimus",
      security_desc: "Paskyros slaptažodį saugiai tvarko prisijungimo paslauga. Niekada jo neatskleisk kitiems.",
      new_password: "Naujas slaptažodis", confirm_password: "Pakartok slaptažodį", min_password: "Mažiausiai 12 simbolių",
      password_help: "Naudok bent 12 simbolių, didžiąją ir mažąją raidę, skaičių bei specialųjį simbolį.",
      update_password: "Atnaujinti slaptažodį", private_title: "Viešo profilio nustatymai",
      private_desc: "Profiliai pagal nutylėjimą vieši. Žemiau gali pasirinkti privatų profilį.", content_desc: "„Testavimai“ skirtas mokymuisi: svetainėje pateikiamos mokyklinės pamokos, praktikos užduotys ir pasiruošimo testai.",
      school_content: "Mokyklai pritaikytas turinys", school_content_desc: "Pasirink mokyklą ir klasę paskyros informacijos skiltyje. Testų pasirinkimai pateikiami pagal svetainėje esančias mokymosi temas.",
      no_adult: "Nėra suaugusiesiems skirto turinio", no_adult_desc: "Šioje svetainėje nėra viešų įrašų, pokalbių ar naudotojų kuriamo turinio filtravimo nustatymų.",
      free_plan: "Nemokamas planas", free_plan_desc: "Šiuo metu naudojiesi nemokama „Testavimai“ versija.", active: "AKTYVUS",
      payments_missing: "Mokėjimai dar neprijungti", payments_desc: "Prenumeratų pirkimas ir mokėjimo informacijos tvarkymas šioje svetainėje dar nepasiekiami.",
      notification_desc: "Čia galėsi tvarkyti mokymosi priminimus ir naujienas, kai bus prijungtas jų siuntimas.",
      notifications_missing: "Pranešimų siuntimas dar neprijungtas", notifications_desc: "Šiuo metu svetainė nesiunčia el. pašto ar naršyklės pranešimų, todėl jokių pranešimų nustatymų neišsaugome.",
      preferences_kicker: "TAVO PATIRTIS", preferences_desc: "Pasirink svetainės kalbą ir spalvų temą, taip pat prisitaikyk tekstą, kontrastą ir animaciją. Nuostatos išsaugomos šioje naršyklėje.",
      language_label: "Svetainės kalba", free_themes: "Nemokamos temos", free_themes_desc: "Šviesus fonas su spalvotu akcentu.",
      premium_themes: "Premium temos", premium_desc: "Išskirtinės šviesios ir tamsios visos platformos spalvų paletės.",
      premium_locked: "Premium temai reikia aktyvios Premium prieigos arba atrakinto temos apdovanojimo.",
    },
    en: {
      nav_practice: "Practice", nav_assessment: "Assessment practice", nav_tests: "Take a test", nav_lessons: "Daily tasks", nav_leaderboard: "Leaderboard",
      menu_heading: "Study space", menu_kicker: "QUICK LINKS", menu_settings: "Settings", menu_settings_desc: "Language and color themes",
      menu_tips: "Study tips", menu_tips_desc: "Remember topics more effectively", menu_weekly: "Weekly plan",
      menu_assessment: "Practice for your assessment", menu_assessment_desc: "Exercises for grades 7–10",
      menu_weekly_desc: "Small goals and progress", menu_lessons: "Subjects and lessons", menu_lessons_desc: "Math, language and more",
      menu_modes: "Practice modes", menu_modes_desc: "Quizzes, cards and exercises", menu_leaderboard: "Leaderboard", menu_leaderboard_desc: "XP points and student progress", menu_help: "Need help?",
      menu_help_desc: "Send us a message — we’re happy to help.", menu_contact: "Contact us",
      profile_button: "Profile", sign_out: "Sign out", home: "Home", profile_heading: "My profile.",
      profile_intro: "View your account information and learning preferences here.",
      profile_tabs: "Profile sections", account: "Account information", security: "Security & privacy",
      content: "Content restrictions", subscriptions: "Subscriptions", notifications: "Notifications",
      website_preferences: "Website preferences", account_kicker: "ACCOUNT", account_desc: "Your name, school and grade are used in your learning profile.",
      first_name: "First name", last_name: "Last name", school: "School", grade: "Grade", email: "Email",
      email_note: "Email address changes are managed by the sign-in provider.", save: "Save changes",
      security_desc: "Your password is securely managed by the sign-in provider. Never share it with anyone.",
      new_password: "New password", confirm_password: "Confirm password", min_password: "At least 12 characters",
      password_help: "Use at least 12 characters, including upper- and lowercase letters, a number and a symbol.",
      update_password: "Update password", private_title: "Public profile settings",
      private_desc: "Profiles are public by default. Use the setting below to make yours private.", content_desc: "Testavimai is for learning, with school lessons, practice exercises and preparation tests.",
      school_content: "School-friendly learning content", school_content_desc: "Choose your school and grade in Account information. Tests cover the learning subjects available on this site.",
      no_adult: "No adult content", no_adult_desc: "This site has no public posts, chats, user-generated content or related filtering settings.",
      free_plan: "Free plan", free_plan_desc: "You are currently using the free version of Testavimai.", active: "ACTIVE",
      payments_missing: "Payments are not set up", payments_desc: "Purchasing subscriptions and managing payment information are not available yet.",
      notification_desc: "Manage learning reminders and updates here when notifications are available.",
      notifications_missing: "Notifications are not set up", notifications_desc: "This site does not send email or browser notifications, so no notification settings are stored.",
      preferences_kicker: "YOUR EXPERIENCE", preferences_desc: "Choose the site language and color theme, and adjust text size, contrast, and motion. Preferences are saved in this browser.",
      language_label: "Website language", free_themes: "Free themes", free_themes_desc: "Light background with a colorful accent.",
      premium_themes: "Premium themes", premium_desc: "Exclusive light and dark color palettes for the whole platform.",
      premium_locked: "A Premium theme requires active Premium access or an unlocked theme reward.",
    },
    es: {
      nav_practice: "Practicar", nav_assessment: "Practicar para el examen", nav_tests: "Hacer un test", nav_lessons: "Tareas diarias", nav_leaderboard: "Clasificación",
      menu_heading: "Espacio de estudio", menu_kicker: "ACCESOS RÁPIDOS", menu_settings: "Ajustes", menu_settings_desc: "Idioma y temas de color",
      menu_tips: "Consejos de estudio", menu_tips_desc: "Recuerda mejor los temas", menu_weekly: "Plan semanal",
      menu_assessment: "Practicar para el examen", menu_assessment_desc: "Ejercicios para cursos 7–10",
      menu_weekly_desc: "Pequeños objetivos y progreso", menu_lessons: "Materias y lecciones", menu_lessons_desc: "Matemáticas, lengua y más",
      menu_modes: "Formas de practicar", menu_modes_desc: "Tests, tarjetas y ejercicios", menu_leaderboard: "Clasificación", menu_leaderboard_desc: "Puntos XP y progreso", menu_help: "¿Necesitas ayuda?",
      menu_help_desc: "Escríbenos, estaremos encantados de ayudarte.", menu_contact: "Contactar",
      profile_button: "Perfil", sign_out: "Cerrar sesión", home: "Inicio", profile_heading: "Mi perfil.",
      profile_intro: "Consulta aquí la información de tu cuenta y tus preferencias de aprendizaje.",
      profile_tabs: "Secciones del perfil", account: "Información de la cuenta", security: "Seguridad y privacidad",
      content: "Restricciones de contenido", subscriptions: "Suscripciones", notifications: "Notificaciones",
      website_preferences: "Preferencias del sitio", account_kicker: "CUENTA", account_desc: "Tu nombre, centro y curso se usan en tu perfil de aprendizaje.",
      first_name: "Nombre", last_name: "Apellidos", school: "Centro educativo", grade: "Curso", email: "Correo electrónico",
      email_note: "El proveedor de acceso gestiona los cambios de correo.", save: "Guardar cambios",
      security_desc: "El proveedor de acceso protege tu contraseña. No la compartas con nadie.",
      new_password: "Nueva contraseña", confirm_password: "Confirmar contraseña", min_password: "Al menos 12 caracteres",
      password_help: "Usa 12 caracteres como mínimo, mayúsculas, minúsculas, números y símbolos.",
      update_password: "Actualizar contraseña", private_title: "Configuración del perfil público",
      private_desc: "Los perfiles son públicos por defecto. Usa el ajuste inferior para hacer privado el tuyo.", content_desc: "Testavimai está diseñado para aprender, con lecciones, ejercicios y pruebas de preparación.",
      school_content: "Contenido educativo apropiado", school_content_desc: "Elige tu centro y curso en Información de la cuenta. Los tests cubren las materias disponibles en este sitio.",
      no_adult: "Sin contenido para adultos", no_adult_desc: "Este sitio no tiene publicaciones públicas, chats ni contenido creado por usuarios.",
      free_plan: "Plan gratuito", free_plan_desc: "Estás usando la versión gratuita de Testavimai.", active: "ACTIVO",
      payments_missing: "Pagos no disponibles", payments_desc: "La compra de suscripciones y la gestión de pagos aún no están disponibles.",
      notification_desc: "Aquí podrás gestionar recordatorios y novedades cuando estén disponibles.",
      notifications_missing: "Notificaciones no disponibles", notifications_desc: "El sitio no envía notificaciones por correo ni navegador.",
      preferences_kicker: "TU EXPERIENCIA", preferences_desc: "Elige el idioma y el tema de color, y ajusta el tamaño del texto, el contraste y las animaciones. Los ajustes se guardan en este navegador.",
      language_label: "Idioma del sitio", free_themes: "Temas gratuitos", free_themes_desc: "Fondo claro con un toque de color.",
      premium_themes: "Temas Premium", premium_desc: "Paletas exclusivas claras y oscuras para toda la plataforma.",
      premium_locked: "Para usar un tema Premium, necesitas acceso Premium activo o haber desbloqueado la recompensa del tema.",
    },
    ru: {
      nav_practice: "Практика", nav_assessment: "Подготовка к тесту", nav_tests: "Пройти тест", nav_lessons: "Ежедневные задания", nav_leaderboard: "Таблица лидеров",
      menu_heading: "Учебное пространство", menu_kicker: "БЫСТРЫЕ ССЫЛКИ", menu_settings: "Настройки", menu_settings_desc: "Язык и цветовые темы",
      menu_tips: "Советы по учёбе", menu_tips_desc: "Как лучше запоминать темы", menu_weekly: "План на неделю",
      menu_assessment: "Подготовка к контрольной", menu_assessment_desc: "Задания для 7–10 классов",
      menu_weekly_desc: "Небольшие цели и прогресс", menu_lessons: "Предметы и уроки", menu_lessons_desc: "Математика, языки и другое",
      menu_modes: "Форматы практики", menu_modes_desc: "Тесты, карточки и задания", menu_leaderboard: "Таблица лидеров", menu_leaderboard_desc: "Очки XP и прогресс учеников", menu_help: "Нужна помощь?",
      menu_help_desc: "Напишите нам — мы будем рады помочь.", menu_contact: "Связаться",
      profile_button: "Профиль", sign_out: "Выйти", home: "На главную", profile_heading: "Мой профиль.",
      profile_intro: "Здесь можно посмотреть данные аккаунта и настройки обучения.",
      profile_tabs: "Разделы профиля", account: "Данные аккаунта", security: "Безопасность и конфиденциальность",
      content: "Ограничения контента", subscriptions: "Подписки", notifications: "Уведомления",
      website_preferences: "Настройки сайта", account_kicker: "АККАУНТ", account_desc: "Имя, школа и класс используются в учебном профиле.",
      first_name: "Имя", last_name: "Фамилия", school: "Школа", grade: "Класс", email: "Электронная почта",
      email_note: "Изменением адреса управляет служба входа.", save: "Сохранить изменения",
      security_desc: "Пароль защищён службой входа. Никогда не сообщайте его другим.",
      new_password: "Новый пароль", confirm_password: "Повторите пароль", min_password: "Не менее 12 символов",
      password_help: "Используйте не менее 12 символов, заглавные и строчные буквы, цифры и символы.",
      update_password: "Обновить пароль", private_title: "Настройки публичного профиля",
      private_desc: "Профили открыты по умолчанию. Ниже можно сделать свой профиль закрытым.", content_desc: "Testavimai создан для обучения: уроки, практические задания и подготовительные тесты.",
      school_content: "Учебный контент для школы", school_content_desc: "Укажите школу и класс в данных аккаунта. Тесты охватывают доступные на сайте предметы.",
      no_adult: "Контент для взрослых отсутствует", no_adult_desc: "На сайте нет публичных публикаций, чатов и пользовательского контента.",
      free_plan: "Бесплатный план", free_plan_desc: "Вы используете бесплатную версию Testavimai.", active: "АКТИВЕН",
      payments_missing: "Оплата не настроена", payments_desc: "Покупка подписок и управление оплатой пока недоступны.",
      notification_desc: "Здесь можно будет управлять напоминаниями и новостями, когда они появятся.",
      notifications_missing: "Уведомления не настроены", notifications_desc: "Сайт не отправляет уведомления по почте или в браузере.",
      preferences_kicker: "ВАШИ НАСТРОЙКИ", preferences_desc: "Выберите язык и цветовую тему сайта, а также настройте размер текста, контрастность и анимацию. Настройки сохраняются в этом браузере.",
      language_label: "Язык сайта", free_themes: "Бесплатные темы", free_themes_desc: "Светлый фон с цветным акцентом.",
      premium_themes: "Темы Premium", premium_desc: "Эксклюзивные светлые и тёмные палитры для всей платформы.",
      premium_locked: "Для темы Premium нужен активный доступ Premium или разблокированная награда-тема.",
    },
    de: {
      nav_practice: "Üben", nav_assessment: "Prüfung üben", nav_tests: "Test machen", nav_lessons: "Tägliche Aufgaben", nav_leaderboard: "Rangliste",
      menu_heading: "Lernbereich", menu_kicker: "SCHNELLZUGRIFFE", menu_settings: "Einstellungen", menu_settings_desc: "Sprache und Farbdesigns",
      menu_tips: "Lerntipps", menu_tips_desc: "Themen besser im Gedächtnis behalten", menu_weekly: "Wochenplan",
      menu_assessment: "Für die Prüfung üben", menu_assessment_desc: "Übungen für die Klassen 7–10",
      menu_weekly_desc: "Kleine Ziele und Fortschritte", menu_lessons: "Fächer und Lektionen", menu_lessons_desc: "Mathe, Sprache und mehr",
      menu_modes: "Übungsarten", menu_modes_desc: "Tests, Karten und Aufgaben", menu_leaderboard: "Rangliste", menu_leaderboard_desc: "XP-Punkte und Lernfortschritt", menu_help: "Brauchst du Hilfe?",
      menu_help_desc: "Schreib uns — wir helfen dir gerne.", menu_contact: "Kontakt",
      profile_button: "Profil", sign_out: "Abmelden", home: "Startseite", profile_heading: "Mein Profil.",
      profile_intro: "Hier findest du deine Kontoinformationen und Lerneinstellungen.",
      profile_tabs: "Profilbereiche", account: "Kontoinformationen", security: "Sicherheit & Datenschutz",
      content: "Inhaltsbeschränkungen", subscriptions: "Abonnements", notifications: "Benachrichtigungen",
      website_preferences: "Website-Einstellungen", account_kicker: "KONTO", account_desc: "Name, Schule und Klasse werden in deinem Lernprofil verwendet.",
      first_name: "Vorname", last_name: "Nachname", school: "Schule", grade: "Klasse", email: "E-Mail",
      email_note: "Änderungen der E-Mail-Adresse verwaltet der Anmeldedienst.", save: "Änderungen speichern",
      security_desc: "Dein Passwort wird sicher vom Anmeldedienst verwaltet. Gib es niemals weiter.",
      new_password: "Neues Passwort", confirm_password: "Passwort bestätigen", min_password: "Mindestens 12 Zeichen",
      password_help: "Mindestens 12 Zeichen mit Groß- und Kleinbuchstaben, Zahl und Sonderzeichen verwenden.",
      update_password: "Passwort aktualisieren", private_title: "Einstellungen für öffentliche Profile",
      private_desc: "Profile sind standardmäßig öffentlich. Unten kannst du dein Profil privat stellen.", content_desc: "Testavimai bietet Lerninhalte mit Schullektionen, Übungen und Vorbereitungstests.",
      school_content: "Lerninhalte für die Schule", school_content_desc: "Wähle Schule und Klasse unter Kontoinformationen. Tests behandeln die verfügbaren Schulfächer.",
      no_adult: "Keine Inhalte für Erwachsene", no_adult_desc: "Diese Website enthält keine öffentlichen Beiträge, Chats oder nutzergenerierten Inhalte.",
      free_plan: "Kostenloser Tarif", free_plan_desc: "Du verwendest derzeit die kostenlose Version von Testavimai.", active: "AKTIV",
      payments_missing: "Zahlungen noch nicht verfügbar", payments_desc: "Abonnements und Zahlungsinformationen können noch nicht verwaltet werden.",
      notification_desc: "Hier kannst du Lern-Erinnerungen und Neuigkeiten verwalten, sobald sie verfügbar sind.",
      notifications_missing: "Benachrichtigungen nicht eingerichtet", notifications_desc: "Diese Website versendet keine E-Mail- oder Browserbenachrichtigungen.",
      preferences_kicker: "DEIN ERLEBNIS", preferences_desc: "Wähle Sprache und Farbdesign der Website und passe Textgröße, Kontrast und Bewegung an. Die Einstellungen werden in diesem Browser gespeichert.",
      language_label: "Website-Sprache", free_themes: "Kostenlose Designs", free_themes_desc: "Heller Hintergrund mit farbigem Akzent.",
      premium_themes: "Premium-Designs", premium_desc: "Exklusive helle und dunkle Farbpaletten für die ganze Plattform.",
      premium_locked: "Für ein Premium-Design ist ein aktiver Premium-Zugang oder eine freigeschaltete Design-Belohnung nötig.",
    },
    fr: {
      nav_practice: "S’entraîner", nav_assessment: "Réviser un contrôle", nav_tests: "Faire un test", nav_lessons: "Défis quotidiens", nav_leaderboard: "Classement",
      menu_heading: "Espace d’apprentissage", menu_kicker: "LIENS RAPIDES", menu_settings: "Paramètres", menu_settings_desc: "Langue et thèmes de couleur",
      menu_tips: "Conseils d’étude", menu_tips_desc: "Mieux retenir les notions", menu_weekly: "Plan de la semaine",
      menu_assessment: "Réviser pour un contrôle", menu_assessment_desc: "Exercices pour les classes 7 à 10",
      menu_weekly_desc: "Petits objectifs et progrès", menu_lessons: "Matières et cours", menu_lessons_desc: "Maths, langue et plus",
      menu_modes: "Modes d’entraînement", menu_modes_desc: "Tests, cartes et exercices", menu_leaderboard: "Classement", menu_leaderboard_desc: "Points XP et progrès", menu_help: "Besoin d’aide ?",
      menu_help_desc: "Écrivez-nous, nous serons ravis de vous aider.", menu_contact: "Nous contacter",
      profile_button: "Profil", sign_out: "Se déconnecter", home: "Accueil", profile_heading: "Mon profil.",
      profile_intro: "Consultez ici les informations de votre compte et vos préférences d’apprentissage.",
      profile_tabs: "Sections du profil", account: "Informations du compte", security: "Sécurité et confidentialité",
      content: "Restrictions de contenu", subscriptions: "Abonnements", notifications: "Notifications",
      website_preferences: "Préférences du site", account_kicker: "COMPTE", account_desc: "Votre nom, votre école et votre classe sont utilisés dans votre profil d’apprentissage.",
      first_name: "Prénom", last_name: "Nom", school: "École", grade: "Classe", email: "Adresse e-mail",
      email_note: "Le service de connexion gère les changements d’adresse e-mail.", save: "Enregistrer les modifications",
      security_desc: "Votre mot de passe est protégé par le service de connexion. Ne le partagez jamais.",
      new_password: "Nouveau mot de passe", confirm_password: "Confirmer le mot de passe", min_password: "12 caractères minimum",
      password_help: "Utilisez au moins 12 caractères, avec majuscules, minuscules, chiffres et symboles.",
      update_password: "Mettre à jour le mot de passe", private_title: "Paramètres du profil public",
      private_desc: "Les profils sont publics par défaut. Utilisez le réglage ci-dessous pour rendre le vôtre privé.", content_desc: "Testavimai propose des cours, des exercices et des tests de préparation.",
      school_content: "Contenu éducatif adapté", school_content_desc: "Choisissez votre école et votre classe dans les informations du compte. Les tests portent sur les matières proposées.",
      no_adult: "Aucun contenu pour adultes", no_adult_desc: "Ce site ne contient ni publications publiques, ni discussions, ni contenu créé par les utilisateurs.",
      free_plan: "Offre gratuite", free_plan_desc: "Vous utilisez actuellement la version gratuite de Testavimai.", active: "ACTIVE",
      payments_missing: "Paiements non disponibles", payments_desc: "L’achat d’abonnements et la gestion des paiements ne sont pas encore disponibles.",
      notification_desc: "Vous pourrez gérer les rappels et les actualités lorsque les notifications seront disponibles.",
      notifications_missing: "Notifications non configurées", notifications_desc: "Ce site n’envoie pas de notifications par e-mail ou navigateur.",
      preferences_kicker: "VOTRE EXPÉRIENCE", preferences_desc: "Choisissez la langue et le thème de couleurs, puis ajustez la taille du texte, le contraste et les animations. Les préférences sont enregistrées dans ce navigateur.",
      language_label: "Langue du site", free_themes: "Thèmes gratuits", free_themes_desc: "Fond clair avec une touche de couleur.",
      premium_themes: "Thèmes Premium", premium_desc: "Palettes claires et sombres exclusives pour toute la plateforme.",
      premium_locked: "Un accès Premium actif ou une récompense de thème débloquée est nécessaire.",
    },
  };

  const extraCopy = {
    lt: {
      home_eyebrow: "Tavo pasiruošimas prasideda čia", home_h1: "Žinios, kuriomis<br />gali <span>pasitikėti.</span>",
      home_desc: "Pasiruošk atsiskaitymams savo tempu. Trumpos, aiškios užduotys padės suprasti, ką jau moki, ir kur dar verta pasitreniruoti.",
      home_cta: "Rinktis užduotis", home_ai: "✦ Išbandyti AI korepetitorių", home_sec_eyebrow: "Tavo kitas žingsnis",
      home_sec_h2: "Pasirink, ką <span>pasikartoti.</span>", home_sec_p: "Trumpa praktika šiandien – daugiau užtikrintumo rytoj.", nav_ai: "AI korepetitorius",
      auth_note: "Mokykis savo tempu.", auth_eyebrow: "Tavo mokymosi erdvė", auth_h1: "Prisijunk prie <span>savo paskyros.</span>",
      auth_intro: "Prisijunk prie paskyros arba susikurk naują ir tęsk pasiruošimą.", tab_signin: "Prisijungti", tab_signup: "Sukurti paskyrą",
      auth_email: "El. paštas", auth_password: "Slaptažodis", auth_submit: "Prisijungti",
      lb_h1: "Pasaulinis <span>leaderboard.</span>", lb_p: "Pažanga skaičiuojama pagal XP. Privati paskyra šioje lentelėje nerodoma.",
      lb_back: "← Grįžti į leaderboard", pp_lb_title: "Leaderboard", pp_rank: "{n}. vieta pasaulyje", pp_rank_out: "Ne TOP 10",
      pp_no_bio: "Šis žmogus dar nieko nenurodė apie save.", pp_about: "Apie",
    },
    en: {
      home_eyebrow: "Your preparation starts here", home_h1: "Knowledge you<br />can <span>trust.</span>",
      home_desc: "Prepare for your assessments at your own pace. Short, clear tasks show what you already know and what is worth practicing more.",
      home_cta: "Choose tasks", home_ai: "✦ Try the AI tutor", home_sec_eyebrow: "Your next step",
      home_sec_h2: "Choose what to <span>review.</span>", home_sec_p: "A little practice today means more confidence tomorrow.", nav_ai: "AI tutor",
      auth_note: "Learn at your own pace.", auth_eyebrow: "Your study space", auth_h1: "Sign in to <span>your account.</span>",
      auth_intro: "Sign in or create a new account and continue preparing.", tab_signin: "Sign in", tab_signup: "Create account",
      auth_email: "Email", auth_password: "Password", auth_submit: "Sign in",
      lb_h1: "Global <span>leaderboard.</span>", lb_p: "Progress is counted by XP. Private accounts are not shown in this table.",
      lb_back: "← Back to leaderboard", pp_lb_title: "Leaderboard", pp_rank: "Rank #{n} worldwide", pp_rank_out: "Outside the TOP 10",
      pp_no_bio: "This person has not written anything about themselves yet.", pp_about: "About",
    },
    es: {
      home_eyebrow: "Tu preparación empieza aquí", home_h1: "Conocimientos en los<br />que puedes <span>confiar.</span>",
      home_desc: "Prepárate para tus pruebas a tu ritmo. Tareas cortas y claras te muestran qué ya sabes y qué conviene practicar más.",
      home_cta: "Elegir tareas", home_ai: "✦ Probar el tutor de IA", home_sec_eyebrow: "Tu siguiente paso",
      home_sec_h2: "Elige qué <span>repasar.</span>", home_sec_p: "Un poco de práctica hoy, más seguridad mañana.", nav_ai: "Tutor de IA",
      auth_note: "Aprende a tu ritmo.", auth_eyebrow: "Tu espacio de estudio", auth_h1: "Inicia sesión en <span>tu cuenta.</span>",
      auth_intro: "Inicia sesión o crea una cuenta nueva y sigue preparándote.", tab_signin: "Iniciar sesión", tab_signup: "Crear cuenta",
      auth_email: "Correo electrónico", auth_password: "Contraseña", auth_submit: "Iniciar sesión",
      lb_h1: "Clasificación <span>mundial.</span>", lb_p: "El progreso se cuenta por XP. Las cuentas privadas no aparecen en esta tabla.",
      lb_back: "← Volver a la clasificación", pp_lb_title: "Clasificación", pp_rank: "Puesto n.º {n} en el mundo", pp_rank_out: "Fuera del TOP 10",
      pp_no_bio: "Esta persona aún no ha escrito nada sobre sí misma.", pp_about: "Acerca de",
    },
    ru: {
      home_eyebrow: "Твоя подготовка начинается здесь", home_h1: "Знания,<br />которым можно <span>доверять.</span>",
      home_desc: "Готовься к контрольным в своём темпе. Короткие понятные задания покажут, что ты уже знаешь и что стоит потренировать.",
      home_cta: "Выбрать задания", home_ai: "✦ Попробовать ИИ-репетитора", home_sec_eyebrow: "Твой следующий шаг",
      home_sec_h2: "Выбери, что <span>повторить.</span>", home_sec_p: "Немного практики сегодня — больше уверенности завтра.", nav_ai: "ИИ-репетитор",
      auth_note: "Учись в своём темпе.", auth_eyebrow: "Твоё место для учёбы", auth_h1: "Войди в <span>свой аккаунт.</span>",
      auth_intro: "Войди в аккаунт или создай новый и продолжай подготовку.", tab_signin: "Войти", tab_signup: "Создать аккаунт",
      auth_email: "Эл. почта", auth_password: "Пароль", auth_submit: "Войти",
      lb_h1: "Мировая <span>таблица лидеров.</span>", lb_p: "Прогресс считается по XP. Приватные аккаунты в таблице не показываются.",
      lb_back: "← Назад к таблице лидеров", pp_lb_title: "Таблица лидеров", pp_rank: "{n}-е место в мире", pp_rank_out: "Вне ТОП-10",
      pp_no_bio: "Этот человек пока ничего не рассказал о себе.", pp_about: "О себе",
    },
    de: {
      home_eyebrow: "Deine Vorbereitung beginnt hier", home_h1: "Wissen, dem du<br /><span>vertrauen kannst.</span>",
      home_desc: "Bereite dich in deinem Tempo auf Prüfungen vor. Kurze, klare Aufgaben zeigen, was du schon kannst und was du noch üben solltest.",
      home_cta: "Aufgaben wählen", home_ai: "✦ KI-Tutor ausprobieren", home_sec_eyebrow: "Dein nächster Schritt",
      home_sec_h2: "Wähle, was du <span>wiederholst.</span>", home_sec_p: "Etwas Übung heute – mehr Sicherheit morgen.", nav_ai: "KI-Tutor",
      auth_note: "Lerne in deinem Tempo.", auth_eyebrow: "Dein Lernbereich", auth_h1: "Melde dich bei <span>deinem Konto an.</span>",
      auth_intro: "Melde dich an oder erstelle ein neues Konto und bereite dich weiter vor.", tab_signin: "Anmelden", tab_signup: "Konto erstellen",
      auth_email: "E-Mail", auth_password: "Passwort", auth_submit: "Anmelden",
      lb_h1: "Globale <span>Rangliste.</span>", lb_p: "Der Fortschritt wird in XP gezählt. Private Konten werden in dieser Tabelle nicht angezeigt.",
      lb_back: "← Zurück zur Rangliste", pp_lb_title: "Rangliste", pp_rank: "Platz {n} weltweit", pp_rank_out: "Außerhalb der TOP 10",
      pp_no_bio: "Diese Person hat noch nichts über sich geschrieben.", pp_about: "Über mich",
    },
    fr: {
      home_eyebrow: "Ta préparation commence ici", home_h1: "Des connaissances<br />auxquelles <span>se fier.</span>",
      home_desc: "Prépare tes contrôles à ton rythme. Des exercices courts et clairs montrent ce que tu sais déjà et ce qu’il faut encore travailler.",
      home_cta: "Choisir des exercices", home_ai: "✦ Essayer le tuteur IA", home_sec_eyebrow: "Ta prochaine étape",
      home_sec_h2: "Choisis quoi <span>réviser.</span>", home_sec_p: "Un peu de pratique aujourd’hui, plus de confiance demain.", nav_ai: "Tuteur IA",
      auth_note: "Apprends à ton rythme.", auth_eyebrow: "Ton espace d’étude", auth_h1: "Connecte-toi à <span>ton compte.</span>",
      auth_intro: "Connecte-toi ou crée un compte pour continuer ta préparation.", tab_signin: "Se connecter", tab_signup: "Créer un compte",
      auth_email: "E-mail", auth_password: "Mot de passe", auth_submit: "Se connecter",
      lb_h1: "Classement <span>mondial.</span>", lb_p: "Les progrès sont comptés en XP. Les comptes privés n’apparaissent pas dans ce tableau.",
      lb_back: "← Retour au classement", pp_lb_title: "Classement", pp_rank: "{n}ᵉ place mondiale", pp_rank_out: "Hors du TOP 10",
      pp_no_bio: "Cette personne n’a encore rien écrit sur elle.", pp_about: "À propos",
    },
  };
  languages.forEach((code) => Object.assign(copy[code], extraCopy[code]));

  // Practice hub: [eyebrow, h1 html, intro, pick subject, 5 subjects (all, lt, math, bio, hist, phys), progress label, streak, correct, coins, note]
  const hubTexts = {
    lt: ["MOKYKIS TAIP, KAIP TAU TINKA", "Pasirink savo<br /><span>praktikavimosi būdą.</span>", "Greitas testukas, atminties kortelės ar ramios praktikos užduotys — rinkis ir pradėk nuo šiandien.", "Pasirink dalyką", "Visi dalykai", "Lietuvių kalba", "Matematika", "Biologija", "Istorija", "Fizika", "TAVO PAŽANGA", "dienų serija", "teisingi šiandien", "mokymosi taškai", "+20 XP už teisingą atsakymą · −10 XP už neteisingą · 5 teisingi per dieną tęsia seriją · +80 XP už kiekvieną 10 dienų seriją"],
    en: ["LEARN THE WAY THAT SUITS YOU", "Choose your<br /><span>way to practice.</span>", "A quick quiz, flashcards or calm practice tasks — pick one and start today.", "Choose a subject", "All subjects", "Lithuanian", "Mathematics", "Biology", "History", "Physics", "YOUR PROGRESS", "day streak", "correct today", "learning points", "+20 XP for a correct answer · −10 XP for a wrong one · 5 correct per day keeps your streak · +80 XP for every 10-day streak"],
    es: ["APRENDE COMO TE VAYA MEJOR", "Elige tu<br /><span>forma de practicar.</span>", "Un test rápido, tarjetas de memoria o tareas de práctica tranquilas: elige y empieza hoy.", "Elige una asignatura", "Todas las asignaturas", "Lituano", "Matemáticas", "Biología", "Historia", "Física", "TU PROGRESO", "días de racha", "correctas hoy", "puntos de aprendizaje", "+20 XP por respuesta correcta · −10 XP por incorrecta · 5 correctas al día mantienen la racha · +80 XP por cada 10 días de racha"],
    ru: ["УЧИСЬ ТАК, КАК ТЕБЕ УДОБНО", "Выбери свой<br /><span>способ практики.</span>", "Быстрый тест, карточки или спокойные практические задания — выбирай и начинай уже сегодня.", "Выбери предмет", "Все предметы", "Литовский язык", "Математика", "Биология", "История", "Физика", "ТВОЙ ПРОГРЕСС", "дней подряд", "верных сегодня", "баллов обучения", "+20 XP за верный ответ · −10 XP за неверный · 5 верных в день продлевают серию · +80 XP за каждые 10 дней серии"],
    de: ["LERNE SO, WIE ES DIR PASST", "Wähle deine<br /><span>Übungsart.</span>", "Ein kurzer Test, Lernkarten oder ruhige Übungsaufgaben — wähle aus und starte noch heute.", "Fach wählen", "Alle Fächer", "Litauisch", "Mathematik", "Biologie", "Geschichte", "Physik", "DEIN FORTSCHRITT", "Tage in Folge", "heute richtig", "Lernpunkte", "+20 XP für eine richtige Antwort · −10 XP für eine falsche · 5 richtige pro Tag halten die Serie · +80 XP für jede 10-Tage-Serie"],
    fr: ["APPRENDS COMME TU PRÉFÈRES", "Choisis ta<br /><span>façon de t’entraîner.</span>", "Un quiz rapide, des cartes mémoire ou des exercices tranquilles — choisis et commence dès aujourd’hui.", "Choisis une matière", "Toutes les matières", "Lituanien", "Mathématiques", "Biologie", "Histoire", "Physique", "TA PROGRESSION", "jours de série", "bonnes réponses aujourd’hui", "points d’apprentissage", "+20 XP par bonne réponse · −10 XP par erreur · 5 bonnes réponses par jour prolongent la série · +80 XP par série de 10 jours"],
  };
  // Mode cards: [meta, title, description, action] x 10
  const cardTexts = {
    lt: [
      ["AI MOKYTOJAS · KOREPETITORIUS", "Išmok temą su AI draugu", "Parašyk, kas neaišku, ir gauk trumpą paaiškinimą ar pavyzdį.", "Paklausti Mokio"],
      ["10 KLAUSIMŲ · ~5 MIN.", "Mini testukas apie viską", "Dešimt trumpų klausimų iš skirtingų mokomųjų dalykų.", "Pradėti testuką"],
      ["AI UŽDUOTYS · 7–10 KLASĖS", "Pasikartok atsiskaitymui", "Įrašyk temą, pasirink dalyką ir kiek užduočių nori spręsti.", "Pradėti praktikuotis"],
      ["TAVO UŽDUOTYS · KLASĖS", "Kurk ir spręsk užduotis", "Sukurk savo klausimų rinkinį, klasę arba atlik mokytojo paskirtas užduotis.", "Atidaryti užduotis"],
      ["AKTYVUS ATSIMINIMAS", "Atminties kortelės", "Spėk atsakymą, apversk kortelę ir žymėk, ką jau moki.", "Vartyti korteles"],
      ["30 UŽDUOČIŲ DALYKUI", "Praktikos užduotys", "Spręsk nuosekliai, iškart peržiūrėk paaiškinimą.", "Rinktis užduotis"],
      ["PAGAL MOKYKLĄ", "Bandomasis testas", "Pasirink lengvą, vidutinį arba sunkų lygį ir dalyką.", "Pasirinkti testą"],
      ["DIENOS KLAUSIMŲ IŠŠŪKIS", "Dienos klausimai", "Nemokamai — 10 klausimų per dienos iššūkį. Premium — 15 klausimų per iššūkį ir neribota papildoma praktika.", "Priimti iššūkį"],
      ["45 SEK. KLAUSIMUI", "Greitas testas su laikmačiu", "Susikaupk ir išbandyk save trumpame teste prieš atsiskaitymą.", "Pradėti laikmatį"],
      ["TAVO PAŽANGA", "Pakartoti sunkesnius", "Sugrįžk prie klausimų, kuriuose anksčiau suklydai.", "Peržiūrėti"],
    ],
    en: [
      ["AI TUTOR · COACH", "Learn a topic with your AI buddy", "Write what is unclear and get a short explanation or example.", "Ask Mokis"],
      ["10 QUESTIONS · ~5 MIN.", "Mini quiz on everything", "Ten short questions from different school subjects.", "Start the quiz"],
      ["AI TASKS · GRADES 7–10", "Review for your assessment", "Enter a topic, choose a subject and how many tasks you want to solve.", "Start practicing"],
      ["YOUR TASKS · CLASSES", "Create and solve tasks", "Build your own question set or class, or complete tasks assigned by a teacher.", "Open tasks"],
      ["ACTIVE RECALL", "Flashcards", "Guess the answer, flip the card and mark what you already know.", "Flip the cards"],
      ["30 TASKS PER SUBJECT", "Practice tasks", "Solve step by step and see the explanation right away.", "Choose tasks"],
      ["SCHOOL-BASED", "Mock test", "Choose an easy, medium or hard level and a subject.", "Choose a test"],
      ["DAILY QUESTION CHALLENGE", "Daily questions", "Free: 10 questions in the daily challenge. Premium: 15 challenge questions plus unlimited extra practice.", "Accept the challenge"],
      ["45 SEC. PER QUESTION", "Quick timed test", "Focus and test yourself in a short quiz before your assessment.", "Start the timer"],
      ["YOUR PROGRESS", "Review harder questions", "Go back to the questions you got wrong before.", "Review"],
    ],
    es: [
      ["TUTOR IA · APOYO", "Aprende un tema con tu amigo IA", "Escribe lo que no entiendes y recibe una explicación o ejemplo breve.", "Preguntar a Mokis"],
      ["10 PREGUNTAS · ~5 MIN.", "Mini test de todo", "Diez preguntas cortas de distintas asignaturas.", "Empezar el test"],
      ["TAREAS IA · CURSOS 7–10", "Repasa para tu prueba", "Escribe un tema, elige la asignatura y cuántas tareas quieres resolver.", "Empezar a practicar"],
      ["TUS TAREAS · CLASES", "Crea y resuelve tareas", "Crea tu propio conjunto de preguntas o clase, o realiza las tareas del profesor.", "Abrir tareas"],
      ["MEMORIA ACTIVA", "Tarjetas de memoria", "Adivina la respuesta, da la vuelta a la tarjeta y marca lo que ya sabes.", "Pasar las tarjetas"],
      ["30 TAREAS POR ASIGNATURA", "Tareas de práctica", "Resuelve paso a paso y revisa la explicación al instante.", "Elegir tareas"],
      ["SEGÚN LA ESCUELA", "Test de prueba", "Elige un nivel fácil, medio o difícil y una asignatura.", "Elegir un test"],
      ["RETO DIARIO DE PREGUNTAS", "Preguntas del día", "Gratis: 10 preguntas en el reto diario. Premium: 15 preguntas del reto y práctica adicional ilimitada.", "Aceptar el reto"],
      ["45 SEG. POR PREGUNTA", "Test rápido con temporizador", "Concéntrate y ponte a prueba en un test corto antes de tu examen.", "Iniciar el temporizador"],
      ["TU PROGRESO", "Repetir las más difíciles", "Vuelve a las preguntas en las que fallaste antes.", "Revisar"],
    ],
    ru: [
      ["ИИ-РЕПЕТИТОР · НАСТАВНИК", "Изучи тему с ИИ-другом", "Напиши, что непонятно, и получи короткое объяснение или пример.", "Спросить Мокиса"],
      ["10 ВОПРОСОВ · ~5 МИН.", "Мини-тест обо всём", "Десять коротких вопросов по разным школьным предметам.", "Начать тест"],
      ["ЗАДАНИЯ ИИ · 7–10 КЛАССЫ", "Повтори к контрольной", "Введи тему, выбери предмет и количество заданий.", "Начать практику"],
      ["ТВОИ ЗАДАНИЯ · КЛАССЫ", "Создавай и решай задания", "Создай свой набор вопросов, класс или выполни задания учителя.", "Открыть задания"],
      ["АКТИВНОЕ ЗАПОМИНАНИЕ", "Карточки", "Угадай ответ, переверни карточку и отметь, что уже знаешь.", "Листать карточки"],
      ["30 ЗАДАНИЙ ПО ПРЕДМЕТУ", "Практические задания", "Решай последовательно и сразу смотри объяснение.", "Выбрать задания"],
      ["ПО ШКОЛЕ", "Пробный тест", "Выбери лёгкий, средний или сложный уровень и предмет.", "Выбрать тест"],
      ["ЕЖЕДНЕВНЫЙ ВЫЗОВ", "Вопросы дня", "Бесплатно: 10 вопросов в ежедневном вызове. Premium: 15 вопросов и неограниченная дополнительная практика.", "Принять вызов"],
      ["45 СЕК. НА ВОПРОС", "Быстрый тест с таймером", "Сосредоточься и проверь себя в коротком тесте перед контрольной.", "Запустить таймер"],
      ["ТВОЙ ПРОГРЕСС", "Повторить сложные", "Вернись к вопросам, в которых ты раньше ошибся.", "Посмотреть"],
    ],
    de: [
      ["KI-TUTOR · COACH", "Lerne ein Thema mit deinem KI-Freund", "Schreib, was unklar ist, und erhalte eine kurze Erklärung oder ein Beispiel.", "Mokis fragen"],
      ["10 FRAGEN · ~5 MIN.", "Mini-Test über alles", "Zehn kurze Fragen aus verschiedenen Schulfächern.", "Test starten"],
      ["KI-AUFGABEN · KLASSE 7–10", "Wiederholen für die Arbeit", "Gib ein Thema ein, wähle ein Fach und die Anzahl der Aufgaben.", "Üben starten"],
      ["DEINE AUFGABEN · KLASSEN", "Aufgaben erstellen und lösen", "Erstelle ein eigenes Fragenset, eine Klasse oder löse Aufgaben deiner Lehrkraft.", "Aufgaben öffnen"],
      ["AKTIVES ERINNERN", "Lernkarten", "Rate die Antwort, dreh die Karte um und markiere, was du schon kannst.", "Karten durchgehen"],
      ["30 AUFGABEN PRO FACH", "Übungsaufgaben", "Löse Schritt für Schritt und sieh dir sofort die Erklärung an.", "Aufgaben wählen"],
      ["NACH SCHULE", "Probetest", "Wähle ein leichtes, mittleres oder schweres Niveau und ein Fach.", "Test wählen"],
      ["TÄGLICHE FRAGEN-CHALLENGE", "Tagesfragen", "Kostenlos: 10 Fragen in der Tages-Challenge. Premium: 15 Challenge-Fragen und unbegrenzte zusätzliche Übungen.", "Challenge annehmen"],
      ["45 SEK. PRO FRAGE", "Schneller Test mit Timer", "Konzentriere dich und teste dich vor der Arbeit in einem kurzen Test.", "Timer starten"],
      ["DEIN FORTSCHRITT", "Schwierigere wiederholen", "Kehre zu den Fragen zurück, bei denen du dich geirrt hast.", "Ansehen"],
    ],
    fr: [
      ["TUTEUR IA · COACH", "Apprends un sujet avec ton ami IA", "Écris ce qui n’est pas clair et reçois une courte explication ou un exemple.", "Demander à Mokis"],
      ["10 QUESTIONS · ~5 MIN.", "Mini-quiz sur tout", "Dix questions courtes issues de différentes matières.", "Commencer le quiz"],
      ["EXERCICES IA · CLASSES 7–10", "Révise pour ton contrôle", "Écris un sujet, choisis une matière et le nombre d’exercices à résoudre.", "Commencer à s’entraîner"],
      ["TES EXERCICES · CLASSES", "Crée et résous des exercices", "Crée ton propre ensemble de questions, une classe, ou fais les exercices donnés par l’enseignant.", "Ouvrir les exercices"],
      ["MÉMOIRE ACTIVE", "Cartes mémoire", "Devine la réponse, retourne la carte et note ce que tu sais déjà.", "Feuilleter les cartes"],
      ["30 EXERCICES PAR MATIÈRE", "Exercices pratiques", "Résous pas à pas et consulte tout de suite l’explication.", "Choisir des exercices"],
      ["SELON L’ÉCOLE", "Test d’essai", "Choisis un niveau facile, moyen ou difficile et une matière.", "Choisir un test"],
      ["DÉFI QUOTIDIEN DE QUESTIONS", "Questions du jour", "Gratuit : 10 questions dans le défi quotidien. Premium : 15 questions et des exercices supplémentaires illimités.", "Relever le défi"],
      ["45 SEC. PAR QUESTION", "Test rapide chronométré", "Concentre-toi et teste-toi dans un court test avant ton contrôle.", "Lancer le chrono"],
      ["TA PROGRESSION", "Revoir les plus difficiles", "Reviens aux questions où tu t’es trompé.", "Revoir"],
    ],
  };
  const hubKeys = ["hub_eyebrow", "hub_h1", "hub_p", "hub_pick_subject", "subj_all", "subj_lt", "subj_math", "subj_bio", "subj_hist", "subj_phys", "prog_label", "prog_streak", "prog_correct", "prog_coins", "prog_note"];
  languages.forEach((code) => {
    hubKeys.forEach((key, index) => { copy[code][key] = hubTexts[code][index]; });
    cardTexts[code].forEach((card, index) => {
      ["m", "t", "d", "a"].forEach((part, partIndex) => { copy[code][`c${index + 1}_${part}`] = card[partIndex]; });
    });
  });

  const orbTexts = {
    lt: ["Kodas", "Įrašyk kodą", "Pateikti", "Tikrinamas kodas…", "Gavai +{n} mokymosi taškų! Iš viso: {total}.", "Tema „{title}“ atsiimta ir pritaikyta.", "Toks kodas negalioja."],
    en: ["Code", "Enter a code", "Submit", "Checking code…", "You got +{n} learning points! Total: {total}.", "Theme “{title}” claimed and applied.", "This code is not valid."],
    es: ["Código", "Escribe un código", "Enviar", "Comprobando código…", "¡Has recibido +{n} puntos de aprendizaje! Total: {total}.", "Tema «{title}» obtenido y aplicado.", "Este código no es válido."],
    ru: ["Код", "Введите код", "Отправить", "Проверяем код…", "Вы получили +{n} баллов обучения! Всего: {total}.", "Тема «{title}» получена и применена.", "Этот код недействителен."],
    de: ["Code", "Code eingeben", "Absenden", "Code wird geprüft…", "Du hast +{n} Lernpunkte erhalten! Gesamt: {total}.", "Design „{title}“ erhalten und angewendet.", "Dieser Code ist ungültig."],
    fr: ["Code", "Saisis un code", "Valider", "Vérification du code…", "Tu as reçu +{n} points d’apprentissage ! Total : {total}.", "Thème « {title} » obtenu et appliqué.", "Ce code n’est pas valide."],
  };
  languages.forEach((code) => {
    ["code_orb_label", "code_orb_placeholder", "code_orb_submit", "code_orb_checking", "code_orb_points", "code_orb_theme", "code_orb_invalid"].forEach((key, index) => { copy[code][key] = orbTexts[code][index]; });
  });

  const practiceTexts = {
    task_workspace_kicker: ["MOKYKIS KARTU", "LEARN TOGETHER", "APRENDED JUNTOS", "УЧИСЬ ВМЕСТЕ", "GEMEINSAM LERNEN", "APPRENONS ENSEMBLE"],
    task_workspace_title: ["Užduotys ir <span>klasės.</span>", "Tasks and <span>classes.</span>", "Tareas y <span>clases.</span>", "Задания и <span>классы.</span>", "Aufgaben und <span>Klassen.</span>", "Exercices et <span>classes.</span>"],
    task_workspace_intro: ["Kurk klausimų rinkinius, dalykis užduotimis su savo klase ir stebėk mokymosi pažangą.", "Create question sets, share tasks with your class and follow learning progress.", "Crea cuestionarios, comparte tareas con tu clase y sigue el progreso.", "Создавай наборы вопросов, делись заданиями с классом и следи за успехами.", "Erstelle Fragensammlungen, teile Aufgaben mit deiner Klasse und verfolge den Lernfortschritt.", "Crée des séries de questions, partage-les avec ta classe et suis les progrès."],
    task_create_kicker: ["KURK SAVO KLAUSIMŲ RINKINĮ", "CREATE YOUR QUESTION SET", "CREA TU CUESTIONARIO", "СОЗДАЙ СВОЙ НАБОР ВОПРОСОВ", "ERSTELLE DEIN FRAGENSET", "CRÉE TA SÉRIE DE QUESTIONS"],
    task_create_title: ["Nauja užduotis", "New task", "Nueva tarea", "Новое задание", "Neue Aufgabe", "Nouvel exercice"],
    task_create_intro: ["Mokiniai ir mokytojai gali kurti klausimų projektus. Nemokamai: iki 10 projektų po 30 pasirinkimo klausimų. „Premium“: neribotas projektų ir klausimų skaičius bei visi klausimų tipai.", "Students and teachers can create question sets. Free: up to 10 projects with 30 multiple-choice questions each. Premium: unlimited projects and questions, plus every question type.", "Alumnos y docentes pueden crear cuestionarios. Gratis: hasta 10 proyectos con 30 preguntas tipo test cada uno. Premium: proyectos y preguntas ilimitados y todos los tipos de pregunta.", "Ученики и учителя могут создавать наборы вопросов. Бесплатно: до 10 проектов по 30 вопросов с выбором ответа. Premium: безлимитные проекты и вопросы, доступны все типы.", "Schüler und Lehrkräfte können Fragensets erstellen. Kostenlos: bis zu 10 Projekte mit je 30 Multiple-Choice-Fragen. Premium: unbegrenzt viele Projekte und Fragen sowie alle Fragetypen.", "Élèves et enseignants peuvent créer des séries de questions. Gratuit : jusqu’à 10 projets de 30 QCM chacun. Premium : projets et questions illimités, tous les types de questions."],
    task_title_label: ["Pavadinimas", "Title", "Título", "Название", "Titel", "Titre"],
    task_title_placeholder: ["Pvz., Trupmenų kartojimas", "E.g. Fractions review", "P. ej., Repaso de fracciones", "Напр., повторение дробей", "Z. B. Brüche wiederholen", "Ex. : Révision des fractions"],
    task_instructions_label: ["Instrukcijos", "Instructions", "Instrucciones", "Инструкции", "Anleitung", "Consignes"],
    task_instructions_placeholder: ["Papildomos instrukcijos (nebūtina)", "Extra instructions (optional)", "Instrucciones adicionales (opcional)", "Дополнительные инструкции (необязательно)", "Zusätzliche Hinweise (optional)", "Consignes supplémentaires (facultatif)"],
    task_visibility_label: ["Kam rodyti užduotį", "Who can see this task", "Quién puede ver esta tarea", "Кто может видеть задание", "Wer kann diese Aufgabe sehen", "Qui peut voir cet exercice"],
    task_visibility_private: ["Tik man (asmeninė)", "Only me (private)", "Solo yo (privada)", "Только мне (личное)", "Nur ich (privat)", "Moi seul (privé)"],
    task_visibility_public: ["Visiems (vieša)", "Everyone (public)", "Todos (pública)", "Всем (публичное)", "Alle (öffentlich)", "Tout le monde (public)"],
    task_due_optional: ["Atlikti iki (nebūtina)", "Due date (optional)", "Fecha límite (opcional)", "Срок выполнения (необязательно)", "Fällig am (optional)", "À rendre avant (facultatif)"],
    task_questions_heading: ["Klausimai", "Questions", "Preguntas", "Вопросы", "Fragen", "Questions"],
    task_add_question: ["＋ Pridėti klausimą", "＋ Add a question", "＋ Añadir pregunta", "＋ Добавить вопрос", "＋ Frage hinzufügen", "＋ Ajouter une question"],
    task_save_button: ["Išsaugoti užduotį →", "Save task →", "Guardar tarea →", "Сохранить задание →", "Aufgabe speichern →", "Enregistrer →"],
    task_teacher_space: ["MOKYTOJO ERDVĖ", "TEACHER SPACE", "ESPACIO DOCENTE", "РАБОЧЕЕ МЕСТО УЧИТЕЛЯ", "LEHRKRÄFTEBEREICH", "ESPACE ENSEIGNANT"],
    task_my_classes: ["Tavo klasės", "Your classes", "Tus clases", "Твои классы", "Deine Klassen", "Tes classes"],
    task_class_intro: ["Sukurk klasę ir pakviesk mokinius pagal jų viešus vartotojų vardus.", "Create a class and invite students by their public usernames.", "Crea una clase e invita a alumnos por su nombre de usuario público.", "Создай класс и пригласи учеников по их публичным именам.", "Erstelle eine Klasse und lade Schüler über ihre öffentlichen Benutzernamen ein.", "Crée une classe et invite les élèves par leur nom d’utilisateur public."],
    task_class_name: ["Klasės pavadinimas", "Class name", "Nombre de la clase", "Название класса", "Klassenname", "Nom de la classe"],
    task_class_subject: ["Dalykas", "Subject", "Materia", "Предмет", "Fach", "Matière"],
    task_create_class: ["Sukurti klasę →", "Create class →", "Crear clase →", "Создать класс →", "Klasse erstellen →", "Créer la classe →"],
    task_student_space: ["MOKINIO ERDVĖ", "STUDENT SPACE", "ESPACIO DEL ALUMNO", "ПРОСТРАНСТВО УЧЕНИКА", "SCHÜLERBEREICH", "ESPACE ÉLÈVE"],
    task_invitations_title: ["Kvietimai ir paskirtos užduotys", "Invitations and assigned tasks", "Invitaciones y tareas asignadas", "Приглашения и задания", "Einladungen und Aufgaben", "Invitations et exercices attribués"],
    task_invitations_intro: ["Klasės kvietimas įsigalioja tik tada, kai jį priimi. Paskirtas užduotis gali atlikti čia.", "A class invitation takes effect only after you accept it. Complete assigned tasks here.", "La invitación a una clase solo se activa cuando la aceptas. Completa aquí las tareas asignadas.", "Приглашение в класс действует только после принятия. Выполняй задания здесь.", "Eine Klasseneinladung gilt erst nach deiner Annahme. Bearbeite zugewiesene Aufgaben hier.", "L’invitation à une classe ne prend effet qu’après acceptation. Fais ici les exercices attribués."],
    task_community: ["BENDRUOMENĖ", "COMMUNITY", "COMUNIDAD", "СООБЩЕСТВО", "COMMUNITY", "COMMUNAUTÉ"],
    task_available_title: ["Viešos ir tau atsiųstos užduotys", "Public and shared tasks", "Tareas públicas y compartidas", "Публичные и отправленные задания", "Öffentliche und geteilte Aufgaben", "Exercices publics et partagés"],
    task_available_intro: ["Čia matysi kitų pasidalintas viešas užduotis ir tas, kurias tau tiesiogiai atsiuntė mokytojas ar draugai.", "Find public tasks shared by others and tasks sent directly to you by a teacher or friend.", "Aquí encontrarás tareas públicas y las que te envíen directamente un docente o un amigo.", "Здесь доступны публичные задания и задания, отправленные тебе учителем или другом.", "Hier findest du öffentliche Aufgaben und Aufgaben, die Lehrkräfte oder Freunde direkt mit dir teilen.", "Retrouve ici les exercices publics et ceux partagés directement par un enseignant ou un ami."],
    task_saved_sets: ["IŠSAUGOTI RINKINIAI", "SAVED SETS", "CUESTIONARIOS GUARDADOS", "СОХРАНЁННЫЕ НАБОРЫ", "GESPEICHERTE SETS", "SÉRIES ENREGISTRÉES"],
    task_my_tasks: ["Mano užduotys", "My tasks", "Mis tareas", "Мои задания", "Meine Aufgaben", "Mes exercices"],
    task_my_tasks_intro: ["Tavo sukurtos asmeninės ir viešos užduotys. Gali jas atsiųsti mokytojui ar kitiems pagal @username.", "Your private and public tasks. Share them with a teacher or others by @username.", "Tus tareas privadas y públicas. Compártelas con un docente u otras personas mediante @username.", "Твои личные и публичные задания. Отправляй их учителю или другим по @username.", "Deine privaten und öffentlichen Aufgaben. Teile sie per @username mit Lehrkräften oder anderen.", "Tes exercices privés et publics. Partage-les avec un enseignant ou d’autres personnes via @username."],
    task_class_created: ["Klasė sukurta. Dabar gali pakviesti mokinius pagal jų @username.", "Class created. You can now invite students by @username.", "Clase creada. Ya puedes invitar alumnos por @username.", "Класс создан. Теперь можно приглашать учеников по @username.", "Klasse erstellt. Du kannst jetzt Schüler per @username einladen.", "Classe créée. Tu peux maintenant inviter des élèves par @username."],
    task_question_number: ["Klausimas {n}", "Question {n}", "Pregunta {n}", "Вопрос {n}", "Frage {n}", "Question {n}"],
    task_remove: ["Pašalinti", "Remove", "Quitar", "Удалить", "Entfernen", "Supprimer"],
    task_remove_question: ["Pašalinti klausimą {n}", "Remove question {n}", "Quitar la pregunta {n}", "Удалить вопрос {n}", "Frage {n} entfernen", "Supprimer la question {n}"],
    task_correct_option: ["Teisingas atsakymas: {n} variantas", "Correct answer: option {n}", "Respuesta correcta: opción {n}", "Правильный ответ: вариант {n}", "Richtige Antwort: Option {n}", "Bonne réponse : option {n}"],
    task_answer_option: ["Atsakymo variantas {n}", "Answer option {n}", "Opción de respuesta {n}", "Вариант ответа {n}", "Antwortoption {n}", "Option de réponse {n}"],
    task_question_type: ["Klausimo tipas", "Question type", "Tipo de pregunta", "Тип вопроса", "Fragetyp", "Type de question"],
    task_question_label: ["Klausimas", "Question", "Pregunta", "Вопрос", "Frage", "Question"],
    task_correct_answer: ["Teisingas atsakymas", "Correct answer", "Respuesta correcta", "Правильный ответ", "Richtige Antwort", "Bonne réponse"],
    task_fill_prompt: ["Naudok ___ vietai, kurią mokinys turi užpildyti", "Use ___ for the blank students should fill in", "Usa ___ para el espacio que debe completar el alumno", "Используй ___ для пропуска, который нужно заполнить", "Nutze ___ für die auszufüllende Lücke", "Utilise ___ pour marquer le blanc à compléter"],
    task_enter_question: ["Įrašyk klausimą", "Enter a question", "Escribe una pregunta", "Введите вопрос", "Frage eingeben", "Saisis une question"],
    task_acceptable_placeholder: ["Priimtini atsakymai (po vieną eilutėje)", "Accepted answers (one per line)", "Respuestas válidas (una por línea)", "Допустимые ответы (по одному в строке)", "Akzeptierte Antworten (eine pro Zeile)", "Réponses acceptées (une par ligne)"],
    task_acceptable_answers: ["Priimtini atsakymai", "Accepted answers", "Respuestas válidas", "Допустимые ответы", "Akzeptierte Antworten", "Réponses acceptées"],
    task_fill_marker_error: ["Užpildymo klausime pažymėk vietą simboliais ___ .", "Mark the blank in the fill-in question with ___ .", "Marca el espacio de la pregunta con ___ .", "Отметь пропуск в вопросе символами ___ .", "Markiere die Lücke mit ___ .", "Marque le blanc avec ___ ."],
    task_choose_class: ["Pasirink klasę", "Choose a class", "Elige una clase", "Выбери класс", "Klasse auswählen", "Choisis une classe"],
    task_no_classes: ["Dar neturi klasės. Sukurk pirmąją aukščiau.", "You don't have a class yet. Create your first one above.", "Aún no tienes una clase. Crea la primera arriba.", "У тебя пока нет класса. Создай его выше.", "Du hast noch keine Klasse. Erstelle oben deine erste.", "Tu n’as pas encore de classe. Crée la première ci-dessus."],
    task_create_class_link: ["Sukurti klasę →", "Create a class →", "Crear una clase →", "Создать класс →", "Klasse erstellen →", "Créer une classe →"],
    task_no_invitations: ["Naujų klasės kvietimų nėra.", "No new class invitations.", "No hay invitaciones nuevas.", "Новых приглашений в класс нет.", "Keine neuen Klasseneinladungen.", "Aucune nouvelle invitation à une classe."],
    task_question_count: ["Klausimų: {n}", "Questions: {n}", "Preguntas: {n}", "Вопросов: {n}", "Fragen: {n}", "Questions : {n}"],
    task_fill_answer: ["Įrašyk trūkstamą žodį ar skaičių", "Enter the missing word or number", "Escribe la palabra o el número que falta", "Введи пропущенное слово или число", "Fehlendes Wort oder Zahl eingeben", "Saisis le mot ou le nombre manquant"],
    task_your_answer: ["Tavo atsakymas", "Your answer", "Tu respuesta", "Твой ответ", "Deine Antwort", "Ta réponse"],
    task_check_answers: ["Patikrinti savo atsakymus →", "Check your answers →", "Comprobar respuestas →", "Проверить ответы →", "Antworten prüfen →", "Vérifier tes réponses →"],
    task_update_answer: ["Atnaujinti atsakymą →", "Update submission →", "Actualizar respuesta →", "Обновить ответ →", "Abgabe aktualisieren →", "Mettre à jour la réponse →"],
    task_submit: ["Pateikti užduotį →", "Submit task →", "Entregar tarea →", "Отправить задание →", "Aufgabe abgeben →", "Envoyer l’exercice →"],
    task_your_score: ["Tavo rezultatas: {score} iš {total}.", "Your score: {score} out of {total}.", "Tu resultado: {score} de {total}.", "Твой результат: {score} из {total}.", "Dein Ergebnis: {score} von {total}.", "Ton résultat : {score} sur {total}."],
    task_checked: ["Patikrinta ✓", "Checked ✓", "Comprobado ✓", "Проверено ✓", "Geprüft ✓", "Vérifié ✓"],
    task_submitted_score: ["Užduotis pateikta ir automatiškai įvertinta: {score} iš {total}.", "Task submitted and automatically graded: {score} out of {total}.", "Tarea enviada y corregida automáticamente: {score} de {total}.", "Задание отправлено и оценено автоматически: {score} из {total}.", "Aufgabe abgegeben und automatisch bewertet: {score} von {total}.", "Exercice envoyé et corrigé automatiquement : {score} sur {total}."],
    task_submitted: ["Pateikta ✓", "Submitted ✓", "Entregada ✓", "Отправлено ✓", "Abgegeben ✓", "Envoyé ✓"],
    task_preview_status: ["Tavo peržiūros rinkinys · atsakymai tikrinami šiame puslapyje.", "Your preview set · answers are checked on this page.", "Vista previa · las respuestas se comprueban aquí.", "Предпросмотр · ответы проверяются на этой странице.", "Vorschau-Set · Antworten werden hier geprüft.", "Aperçu · les réponses sont vérifiées sur cette page."],
    task_due_date: ["Atlikti iki {date}", "Due {date}", "Fecha límite: {date}", "Срок: {date}", "Fällig am {date}", "À rendre le {date}"],
    task_score_short: ["Rezultatas: {score}/{total}", "Score: {score}/{total}", "Resultado: {score}/{total}", "Результат: {score}/{total}", "Ergebnis: {score}/{total}", "Score : {score}/{total}"],
    task_submitted_status: ["Pateikta · automatiškai įvertinta", "Submitted · automatically graded", "Entregada · corregida automáticamente", "Отправлено · оценено автоматически", "Abgegeben · automatisch bewertet", "Envoyé · corrigé automatiquement"],
    task_submitted_at: ["Pateikta {date}", "Submitted {date}", "Entregada el {date}", "Отправлено: {date}", "Abgegeben am {date}", "Envoyé le {date}"],
    task_resubmit_note: ["Gali pateikti dar kartą – naujas rezultatas pakeis ankstesnį.", "You can submit again; the new score will replace the previous one.", "Puedes volver a enviarla; el nuevo resultado sustituirá al anterior.", "Можно отправить ещё раз — новый результат заменит предыдущий.", "Du kannst erneut abgeben; das neue Ergebnis ersetzt das vorherige.", "Tu peux renvoyer l’exercice ; le nouveau résultat remplacera l’ancien."],
    task_overdue_status: ["Terminas praėjęs · vis tiek gali pateikti", "Past due · you can still submit", "Plazo vencido · aún puedes entregar", "Срок истёк · задание всё ещё можно отправить", "Frist abgelaufen · du kannst trotzdem abgeben", "Date dépassée · tu peux quand même envoyer"],
    task_not_submitted: ["Nepateikta", "Not submitted", "No entregada", "Не отправлено", "Nicht abgegeben", "Non envoyé"],
    task_class_submitted_count: ["{submitted}/{total} pateikė", "{submitted}/{total} submitted", "{submitted}/{total} entregadas", "Отправлено: {submitted}/{total}", "{submitted}/{total} abgegeben", "{submitted}/{total} envoyés"],
    task_class_scores: ["Įvertinimai", "Scores", "Resultados", "Оценки", "Ergebnisse", "Résultats"],
    task_class_pending: ["Laukia", "Pending", "Pendientes", "Ожидают", "Ausstehend", "En attente"],
    task_no_own_tasks: ["Dar nesukūrei savo užduočių rinkinio.", "You haven't created a task set yet.", "Aún no has creado un conjunto de tareas.", "Ты ещё не создал набор заданий.", "Du hast noch kein Aufgabenset erstellt.", "Tu n’as pas encore créé de série d’exercices."],
    task_create_first: ["Sukurti pirmą užduotį →", "Create your first task →", "Crea tu primera tarea →", "Создать первое задание →", "Erstelle deine erste Aufgabe →", "Crée ton premier exercice →"],
    task_no_student_shares: ["Mokiniai tau dar neatsiuntė užduočių.", "Students haven't shared tasks with you yet.", "Los alumnos aún no han compartido tareas contigo.", "Ученики пока не отправляли тебе задания.", "Schüler haben noch keine Aufgaben mit dir geteilt.", "Les élèves ne t’ont pas encore partagé d’exercices."],
    task_no_available: ["Viešų ar tau atsiųstų užduočių kol kas nėra.", "There are no public or shared tasks yet.", "Aún no hay tareas públicas o compartidas.", "Пока нет публичных или отправленных заданий.", "Es gibt noch keine öffentlichen oder geteilten Aufgaben.", "Aucun exercice public ou partagé pour le moment."],
    task_no_assigned: ["Šiuo metu tau nepaskirta užduočių.", "No tasks have been assigned to you yet.", "Aún no tienes tareas asignadas.", "Тебе пока не назначили задания.", "Dir wurden noch keine Aufgaben zugewiesen.", "Aucun exercice ne t’a encore été attribué."],
    task_premium_limits: ["Premium · sukurta {projects} projektų · projektų ir klausimų skaičius neribojamas.", "Premium · {projects} projects created · unlimited projects and questions.", "Premium · {projects} proyectos creados · proyectos y preguntas ilimitados.", "Premium · создано проектов: {projects} · проекты и вопросы без ограничений.", "Premium · {projects} Projekte erstellt · unbegrenzt viele Projekte und Fragen.", "Premium · {projects} projets créés · projets et questions illimités."],
    task_free_limits: ["Nemokamai · sukurta {projects}/10 projektų (liko {remaining}) · {questions}/30 klausimų šiame projekte. Galimi pasirinkimo klausimai.", "Free · {projects}/10 projects created ({remaining} left) · {questions}/30 questions in this project. Multiple choice is available.", "Gratis · {projects}/10 proyectos ({remaining} restantes) · {questions}/30 preguntas en este proyecto. Disponible el tipo test.", "Бесплатно · создано проектов: {projects}/10 (осталось {remaining}) · вопросов в проекте: {questions}/30. Доступен выбор ответа.", "Kostenlos · {projects}/10 Projekte erstellt ({remaining} übrig) · {questions}/30 Fragen in diesem Projekt. Multiple Choice verfügbar.", "Gratuit · {projects}/10 projets ({remaining} restants) · {questions}/30 questions dans ce projet. QCM disponible."],
    task_premium_link: ["Peržiūrėti Premium →", "Explore Premium →", "Ver Premium →", "Узнать о Premium →", "Premium ansehen →", "Découvrir Premium →"],
    task_premium_question_count: ["{n} klausimų · neribotai su Premium", "{n} questions · unlimited with Premium", "{n} preguntas · ilimitadas con Premium", "{n} вопросов · без ограничений с Premium", "{n} Fragen · unbegrenzt mit Premium", "{n} questions · illimité avec Premium"],
    task_project_limit_reached: ["Nemokamas 10 projektų limitas pasiektas.", "The free limit of 10 projects has been reached.", "Has alcanzado el límite gratuito de 10 proyectos.", "Достигнут бесплатный лимит в 10 проектов.", "Das kostenlose Limit von 10 Projekten ist erreicht.", "La limite gratuite de 10 projets est atteinte."],
    task_project_limit_error: ["Nemokamai galima sukurti iki 10 projektų. Pasirink Premium, kad projektų skaičius būtų neribojamas.", "The free plan allows up to 10 projects. Choose Premium for unlimited projects.", "El plan gratuito permite hasta 10 proyectos. Elige Premium para tener proyectos ilimitados.", "Бесплатно можно создать до 10 проектов. Выбери Premium для неограниченного числа проектов.", "Kostenlos sind bis zu 10 Projekte möglich. Mit Premium gibt es keine Projektbegrenzung.", "Le forfait gratuit permet jusqu’à 10 projets. Choisis Premium pour en créer sans limite."],
    task_question_limit_error: ["Nemokamame projekte gali būti iki 30 pasirinkimo klausimų.", "A free project can have up to 30 multiple-choice questions.", "Un proyecto gratuito puede tener hasta 30 preguntas tipo test.", "В бесплатном проекте может быть до 30 вопросов с выбором ответа.", "Ein kostenloses Projekt kann bis zu 30 Multiple-Choice-Fragen enthalten.", "Un projet gratuit peut contenir jusqu’à 30 QCM."],
    task_created_success: ["Užduotis išsaugota.", "Task saved.", "Tarea guardada.", "Задание сохранено.", "Aufgabe gespeichert.", "Exercice enregistré."],
    task_sign_in_required: ["Užduotims ir klasėms reikia prisijungti prie mokinio arba mokytojo paskyros.", "Sign in with a student or teacher account to use tasks and classes.", "Inicia sesión con una cuenta de alumno o docente para usar tareas y clases.", "Войди в аккаунт ученика или учителя, чтобы пользоваться заданиями и классами.", "Melde dich mit einem Schüler- oder Lehrkraftkonto an, um Aufgaben und Klassen zu nutzen.", "Connecte-toi avec un compte élève ou enseignant pour utiliser les exercices et les classes."],
    task_role_not_allowed: ["Užduotis gali kurti tik mokinio arba mokytojo paskyra.", "Only student and teacher accounts can create tasks.", "Solo las cuentas de alumno y docente pueden crear tareas.", "Создавать задания могут только ученики и учителя.", "Nur Schüler- und Lehrkraftkonten können Aufgaben erstellen.", "Seuls les comptes élève et enseignant peuvent créer des exercices."],
    task_role_unknown: ["Profilio tipas nenustatytas. Patikrink paskyros nustatymus.", "Account type not found. Check your account settings.", "No se encontró el tipo de cuenta. Revisa los ajustes.", "Тип аккаунта не определён. Проверь настройки.", "Kontotyp nicht gefunden. Prüfe deine Kontoeinstellungen.", "Type de compte introuvable. Vérifie tes paramètres."],
    task_teacher_role: ["Mokytojo", "Teacher", "Docente", "Учитель", "Lehrkraft", "Enseignant"],
    task_student_role: ["Mokinio", "Student", "Alumno", "Ученик", "Schüler", "Élève"],
    task_account_connected: ["{role} paskyra prijungta{premium}.", "{role} account connected{premium}.", "Cuenta de {role} conectada{premium}.", "Аккаунт ({role}) подключён{premium}.", "{role}-Konto verbunden{premium}.", "Compte {role} connecté{premium}."],
    task_sign_in_link: ["Prisijungti →", "Sign in →", "Iniciar sesión →", "Войти →", "Anmelden →", "Se connecter →"],
    task_class_sign_in: ["Priimti kvietimą", "Accept invitation", "Aceptar invitación", "Принять приглашение", "Einladung annehmen", "Accepter l’invitation"],
    task_decline_invitation: ["Atsisakyti", "Decline", "Rechazar", "Отклонить", "Ablehnen", "Refuser"],
    task_invite_button: ["Siųsti kvietimus", "Send invitations", "Enviar invitaciones", "Отправить приглашения", "Einladungen senden", "Envoyer les invitations"],
    task_share_button: ["Atsiųsti užduotį", "Share task", "Compartir tarea", "Отправить задание", "Aufgabe teilen", "Partager l’exercice"],
    task_score_label: ["Tavo rezultatas", "Your score", "Tu resultado", "Твой результат", "Dein Ergebnis", "Ton résultat"],
    task_source_shared: ["Atsiųsta tau", "Shared with you", "Compartida contigo", "Отправлено тебе", "Mit dir geteilt", "Partagé avec toi"],
    task_source_public: ["Vieša užduotis", "Public task", "Tarea pública", "Публичное задание", "Öffentliche Aufgabe", "Exercice public"],
    task_visibility_private_short: ["Tik man", "Private", "Privada", "Личное", "Privat", "Privé"],
    task_visibility_public_short: ["Vieša", "Public", "Pública", "Публичное", "Öffentlich", "Public"],
    task_date_locale: ["lt-LT", "en-GB", "es-ES", "ru-RU", "de-DE", "fr-FR"],
    pq_kicker: ["TAVO SESIJA", "YOUR SESSION", "TU SESIÓN", "ТВОЯ СЕССИЯ", "DEINE SITZUNG", "TA SÉANCE"],
    pq_close: ["Uždaryti praktiką", "Close practice", "Cerrar práctica", "Закрыть практику", "Übung schließen", "Fermer l’entraînement"],
    pq_close_short: ["Uždaryti", "Close", "Cerrar", "Закрыть", "Schließen", "Fermer"],
    pq_tip_eyebrow: ["MAŽAS PATARIMAS", "A SMALL TIP", "UN PEQUEÑO CONSEJO", "МАЛЕНЬКИЙ СОВЕТ", "EIN KLEINER TIPP", "UN PETIT CONSEIL"],
    pq_tip_h2: ["Trumpai, bet <span>nuosekliai.</span>", "Short, but <span>consistent.</span>", "Breve, pero <span>constante.</span>", "Коротко, но <span>регулярно.</span>", "Kurz, aber <span>regelmäßig.</span>", "Court, mais <span>régulier.</span>"],
    pq_tip_p: ["Po trumpo testuko peržvelk neteisingus atsakymus. Rytoj sugrįžk prie tų pačių temų — prisiminti savo galva veiksmingiau nei vien skaityti.", "After a short quiz, review your wrong answers. Come back to the same topics tomorrow — recalling from memory works better than just reading.", "Tras un test corto, repasa las respuestas incorrectas. Mañana vuelve a los mismos temas: recordar de memoria es más eficaz que solo leer.", "После короткого теста просмотри неправильные ответы. Завтра вернись к тем же темам — вспоминать самому эффективнее, чем просто читать.", "Sieh dir nach einem kurzen Test die falschen Antworten an. Komm morgen auf dieselben Themen zurück – aus dem Gedächtnis abrufen wirkt besser als nur lesen.", "Après un court quiz, relis tes mauvaises réponses. Reviens demain sur les mêmes sujets : se rappeler de mémoire est plus efficace que simplement lire."],
    pq_tip_link: ["Rasti pamokų", "Find lessons", "Buscar lecciones", "Найти уроки", "Lektionen finden", "Trouver des leçons"],
    pq_week_eyebrow: ["MAŽI ŽINGSNIAI", "SMALL STEPS", "PEQUEÑOS PASOS", "МАЛЕНЬКИЕ ШАГИ", "KLEINE SCHRITTE", "PETITS PAS"],
    pq_week_h2: ["Tavo šios savaitės <span>planas.</span>", "Your plan for <span>this week.</span>", "Tu plan de <span>esta semana.</span>", "Твой план <span>на неделю.</span>", "Dein Plan für <span>diese Woche.</span>", "Ton plan de <span>la semaine.</span>"],
    pq_week_p: ["Pažymėk, ką jau nuveikei. Planas išsaugomas šiame įrenginyje.", "Tick what you have already done. The plan is saved on this device.", "Marca lo que ya has hecho. El plan se guarda en este dispositivo.", "Отметь, что уже сделано. План сохраняется на этом устройстве.", "Hake ab, was du schon erledigt hast. Der Plan wird auf diesem Gerät gespeichert.", "Coche ce que tu as déjà fait. Le plan est enregistré sur cet appareil."],
    pq_goal_review: ["Pakartoti vieną svarbią temą", "Review one important topic", "Repasar un tema importante", "Повторить одну важную тему", "Ein wichtiges Thema wiederholen", "Réviser un sujet important"],
    pq_goal_practice: ["Išspręsti penkias praktikos užduotis", "Solve five practice tasks", "Resolver cinco tareas de práctica", "Решить пять практических заданий", "Fünf Übungsaufgaben lösen", "Résoudre cinq exercices"],
    pq_goal_cards: ["Peržiūrėti atminties korteles", "Go through the flashcards", "Repasar las tarjetas de memoria", "Просмотреть карточки памяти", "Lernkarten durchgehen", "Parcourir les cartes mémoire"],
    pq_week_status: ["Pažymėti {n} iš {m} tikslų.", "{n} of {m} goals ticked.", "{n} de {m} objetivos marcados.", "Отмечено целей: {n} из {m}.", "{n} von {m} Zielen abgehakt.", "{n} objectifs cochés sur {m}."],
    pq_as_eyebrow: ["UŽDUOTYS PAGAL TAVO TEMĄ", "TASKS ON YOUR TOPIC", "TAREAS SOBRE TU TEMA", "ЗАДАНИЯ ПО ТВОЕЙ ТЕМЕ", "AUFGABEN ZU DEINEM THEMA", "EXERCICES SUR TON SUJET"],
    pq_as_p: ["Skirta 7–10 klasių mokiniams: pasirink klasę, dalyką ir temas įrašyk savo. Parinksime užduotis pagal tavo klasių lygį.", "For grades 7–10: pick your grade and subject and type your own topic. We will choose tasks to match your level.", "Para alumnos de 7.º a 10.º: elige curso y materia y escribe tu propio tema. Elegiremos tareas según tu nivel.", "Для учеников 7–10 классов: выбери класс и предмет и впиши свою тему. Мы подберём задания по твоему уровню.", "Für die Klassen 7–10: Wähle Klasse und Fach und gib dein eigenes Thema ein. Wir wählen passende Aufgaben aus.", "Pour les élèves de la 7e à la 10e : choisis ta classe et ta matière et saisis ton propre sujet. Nous choisirons des exercices adaptés."],
    pq_as_grade: ["Klasė", "Grade", "Curso", "Класс", "Klasse", "Classe"],
    pq_grade_suffix: [" klasė", " grade", ".º curso", " класс", ". Klasse", "e année"],
    pq_as_subject: ["Dalykas", "Subject", "Materia", "Предмет", "Fach", "Matière"],
    pq_as_topic: ["Tema", "Topic", "Tema", "Тема", "Thema", "Sujet"],
    pq_as_topic_ph: ["Pvz., trupmenų sudėtis", "E.g. adding fractions", "Ej.: suma de fracciones", "Напр., сложение дробей", "z. B. Brüche addieren", "Ex. : addition de fractions"],
    pq_as_count: ["Užduočių skaičius", "Number of tasks", "Número de tareas", "Количество заданий", "Anzahl der Aufgaben", "Nombre d’exercices"],
    pq_as_less: ["Mažiau užduočių", "Fewer tasks", "Menos tareas", "Меньше заданий", "Weniger Aufgaben", "Moins d’exercices"],
    pq_as_more: ["Daugiau užduočių", "More tasks", "Más tareas", "Больше заданий", "Mehr Aufgaben", "Plus d’exercices"],
    pq_as_submit: ["Parinkti užduotis →", "Choose tasks →", "Elegir tareas →", "Подобрать задания →", "Aufgaben auswählen →", "Choisir les exercices →"],
    pq_as_note: ["Užduotims kurti reikia prisijungti. Gali pasirinkti 1–50 užduočių; nemokamai galima naudoti iki 15 klausimų per dieną, Premium limitas netaikomas. Rezultatas bus parodytas sesijos pabaigoje; šios užduotys dar neįskaičiuojamos į XP.", "You need to sign in to create tasks. You can choose 1–50 tasks; the free plan allows up to 15 questions per day, Premium has no limit. The result is shown at the end of the session; these tasks do not count towards XP yet.", "Necesitas iniciar sesión para crear tareas. Puedes elegir de 1 a 50 tareas; gratis hasta 15 preguntas al día, Premium sin límite. El resultado se muestra al final de la sesión; estas tareas aún no suman XP.", "Для создания заданий нужно войти в аккаунт. Можно выбрать 1–50 заданий; бесплатно — до 15 вопросов в день, у Premium лимита нет. Результат покажем в конце сессии; эти задания пока не дают XP.", "Zum Erstellen von Aufgaben musst du angemeldet sein. Du kannst 1–50 Aufgaben wählen; kostenlos bis zu 15 Fragen pro Tag, Premium ohne Limit. Das Ergebnis erscheint am Ende der Sitzung; diese Aufgaben zählen noch nicht für XP.", "Il faut être connecté pour créer des exercices. Tu peux choisir de 1 à 50 exercices ; gratuit jusqu’à 15 questions par jour, sans limite avec Premium. Le résultat s’affiche à la fin de la séance ; ces exercices ne rapportent pas encore d’XP."],
    pq_as_loading: ["Parenkamos {n} užduočių apie „{topic}“…", "Choosing {n} tasks about “{topic}”…", "Eligiendo {n} tareas sobre «{topic}»…", "Подбираем заданий: {n} по теме «{topic}»…", "{n} Aufgaben zu „{topic}“ werden ausgewählt…", "Sélection de {n} exercices sur « {topic} »…"],
    pq_as_found: ["Parinkta {n} užduočių. Sėkmės praktikuojantis!", "{n} tasks chosen. Good luck practising!", "Se eligieron {n} tareas. ¡Mucha suerte practicando!", "Подобрано заданий: {n}. Удачной практики!", "{n} Aufgaben ausgewählt. Viel Erfolg beim Üben!", "{n} exercices choisis. Bon entraînement !"],
    pq_en_eyebrow: ["TIKROVIŠKAS PASIRUOŠIMAS", "REALISTIC PREPARATION", "PREPARACIÓN REALISTA", "РЕАЛИСТИЧНАЯ ПОДГОТОВКА", "REALISTISCHE VORBEREITUNG", "PRÉPARATION RÉALISTE"],
    pq_en_p: ["Pasirink sunkumą ir dalyką. Testo klausimai, laikmatis ir paaiškinimai atsidarys testo puslapyje.", "Choose a difficulty and subject. The questions, timer and explanations open on the test page.", "Elige dificultad y materia. Las preguntas, el temporizador y las explicaciones se abrirán en la página del test.", "Выбери сложность и предмет. Вопросы, таймер и объяснения откроются на странице теста.", "Wähle Schwierigkeit und Fach. Fragen, Timer und Erklärungen öffnen sich auf der Testseite.", "Choisis la difficulté et la matière. Les questions, le minuteur et les explications s’ouvriront sur la page du test."],
    pq_en_diff: ["Sunkumas", "Difficulty", "Dificultad", "Сложность", "Schwierigkeit", "Difficulté"],
    pq_en_easy: ["Lengvas · easy", "Easy", "Fácil", "Лёгкий", "Leicht", "Facile"],
    pq_en_medium: ["Vidutinis · medium", "Medium", "Medio", "Средний", "Mittel", "Moyen"],
    pq_en_hard: ["Sunkus · hard", "Hard", "Difícil", "Сложный", "Schwer", "Difficile"],
    pq_en_submit: ["Pradėti bandomąjį testą →", "Start the practice test →", "Empezar el test de prueba →", "Начать пробный тест →", "Probetest starten →", "Commencer le test d’essai →"],
    subj_chem: ["Chemija", "Chemistry", "Química", "Химия", "Chemie", "Chimie"],
    subj_litlit: ["Lietuvių kalba ir literatūra", "Lithuanian language and literature", "Lengua y literatura lituanas", "Литовский язык и литература", "Litauische Sprache und Literatur", "Langue et littérature lituaniennes"],
    subj_ru: ["Rusų kalba", "Russian", "Ruso", "Русский язык", "Russisch", "Russe"],
    subj_fr: ["Prancūzų kalba", "French", "Francés", "Французский язык", "Französisch", "Français"],
    subj_es: ["Ispanų kalba", "Spanish", "Español", "Испанский язык", "Spanisch", "Espagnol"],
    subj_de: ["Vokiečių kalba", "German", "Alemán", "Немецкий язык", "Deutsch", "Allemand"],
    subj_geo: ["Geografija", "Geography", "Geografía", "География", "Geographie", "Géographie"],
    subj_it: ["Informatika", "Computer science", "Informática", "Информатика", "Informatik", "Informatique"],
    subj_music: ["Muzika", "Music", "Música", "Музыка", "Musik", "Musique"],
    subj_en: ["Anglų kalba", "English", "Inglés", "Английский язык", "Englisch", "Anglais"],
    pq_as_level: ["Testo lygis", "Test level", "Nivel del test", "Уровень теста", "Testniveau", "Niveau du test"],
    pq_as_topic_hint: ["Siūlomos temos pagal bendrąją programą:", "Suggested topics from the curriculum:", "Temas sugeridos del currículo:", "Темы из программы:", "Themenvorschläge aus dem Lehrplan:", "Sujets proposés selon le programme :"],
    tm_nav_class: ["Mano klasė", "My class", "Mi clase", "Мой класс", "Meine Klasse", "Ma classe"],
    tm_nav_inbox: ["Mokinių atsiųstos", "Shared by students", "Enviadas por alumnos", "От учеников", "Von Schülern geteilt", "Envoyées par les élèves"],
    tm_nav_create: ["Kurti užduotis", "Create tasks", "Crear tareas", "Создать задания", "Aufgaben erstellen", "Créer des exercices"],
    tm_nav_tutor: ["AI korepetitorius", "AI tutor", "Tutor IA", "ИИ-репетитор", "KI-Nachhilfe", "Tuteur IA"],
    tm_nav_board: ["Lyderiai", "Leaderboard", "Clasificación", "Лидеры", "Bestenliste", "Classement"],
    tm_nav_materials: ["Pamokų medžiaga", "Lesson materials", "Material de clase", "Материалы уроков", "Unterrichtsmaterial", "Supports de cours"],
    tm_nav_tools: ["Mokytojo įrankiai", "Teacher tools", "Herramientas docentes", "Инструменты учителя", "Lehrer-Tools", "Outils enseignant"],
    tm_nav_results: ["Klasės rezultatai", "Class results", "Resultados de la clase", "Результаты класса", "Klassenergebnisse", "Résultats de la classe"],
    tm_nav_settings: ["Nustatymai", "Settings", "Ajustes", "Настройки", "Einstellungen", "Paramètres"],
    tm_nav_friends: ["Draugai", "Friends", "Amigos", "Друзья", "Freunde", "Amis"],
    tm_dash_eyebrow: ["MOKYTOJO ERDVĖ", "TEACHER WORKSPACE", "ESPACIO DOCENTE", "РАБОЧЕЕ МЕСТО УЧИТЕЛЯ", "LEHRERBEREICH", "ESPACE ENSEIGNANT"],
    tm_dash_h1: ["Tavo mokytojo darbo vieta", "Your teacher workspace", "Tu espacio de trabajo docente", "Твоё рабочее место учителя", "Dein Lehrer-Arbeitsplatz", "Ton espace de travail"],
    tm_dash_p: ["Valdyk klases, kurk užduotis, sek mokinių rezultatus ir naudok AI korepetitorių pamokoms ruošti.", "Manage classes, create tasks, follow student results and use the AI tutor to prepare lessons.", "Gestiona clases, crea tareas, sigue los resultados y usa el tutor IA para preparar clases.", "Управляй классами, создавай задания, следи за результатами и готовь уроки с ИИ-репетитором.", "Verwalte Klassen, erstelle Aufgaben, verfolge Ergebnisse und bereite Unterricht mit der KI vor.", "Gère tes classes, crée des exercices, suis les résultats et prépare tes cours avec le tuteur IA."],
    tm_card_class_p: ["Kurk klases, kviesk mokinius ir matyk jų pažangą.", "Create classes, invite students and see their progress.", "Crea clases, invita alumnos y mira su progreso.", "Создавай классы, приглашай учеников и смотри их прогресс.", "Klassen anlegen, Schüler einladen, Fortschritt sehen.", "Crée des classes, invite des élèves et suis leur progression."],
    tm_card_inbox_p: ["Peržiūrėk ir spręsk mokinių tau tiesiogiai atsiųstas užduotis.", "Review and solve tasks students have shared directly with you.", "Revisa y resuelve tareas que los alumnos te han enviado directamente.", "Просматривай и решай задания, которые ученики отправили тебе.", "Sieh dir Aufgaben an, die Schüler direkt mit dir geteilt haben.", "Consulte et résous les exercices que les élèves t’ont envoyés directement."],
    tm_card_create_p: ["Sukurk užduotį klasei arba viešai bibliotekai.", "Make a task for a class or the public library.", "Crea una tarea para una clase o la biblioteca pública.", "Создай задание для класса или публичной библиотеки.", "Erstelle eine Aufgabe für eine Klasse oder die öffentliche Bibliothek.", "Crée un exercice pour une classe ou la bibliothèque publique."],
    tm_card_tutor_p: ["Paprašyk AI paaiškinimo, pavyzdžių ar testo temai.", "Ask the AI for an explanation, examples or a test on a topic.", "Pide a la IA una explicación, ejemplos o un test.", "Попроси ИИ объяснение, примеры или тест по теме.", "Bitte die KI um Erklärung, Beispiele oder einen Test.", "Demande à l’IA une explication, des exemples ou un test."],
    tm_card_board_p: ["Pamatyk, kurie mokiniai mokosi aktyviausiai.", "See which students learn the most.", "Mira qué alumnos aprenden más.", "Посмотри, кто учится активнее всех.", "Sieh, welche Schüler am aktivsten lernen.", "Vois quels élèves apprennent le plus."],
    tm_card_materials_p: ["Pamokų konspektai ir pratimai 14 dalykų.", "Lesson notes and exercises in 14 subjects.", "Apuntes y ejercicios en 14 materias.", "Конспекты и упражнения по 14 предметам.", "Notizen und Übungen in 14 Fächern.", "Cours et exercices dans 14 matières."],
    tm_card_tools_p: ["Premium, kodai ir paskyros nustatymai mokytojams.", "Premium, codes and account settings for teachers.", "Premium, códigos y ajustes para docentes.", "Premium, коды и настройки для учителей.", "Premium, Codes und Einstellungen für Lehrkräfte.", "Premium, codes et paramètres pour enseignants."],
    tm_profile_eyebrow: ["MOKYTOJO PROFILIS", "TEACHER PROFILE", "PERFIL DOCENTE", "ПРОФИЛЬ УЧИТЕЛЯ", "LEHRERPROFIL", "PROFIL ENSEIGNANT"],
    task_type_multiple_choice: ["Pasirinkimas", "Multiple choice", "Opción múltiple", "Выбор ответа", "Multiple Choice", "Choix multiple"],
    task_type_true_false: ["Tiesa / netiesa · Premium", "True / false · Premium", "Verdadero / falso · Premium", "Верно / неверно · Premium", "Wahr / falsch · Premium", "Vrai / faux · Premium"],
    task_type_short_answer: ["Trumpas atsakymas · Premium", "Short answer · Premium", "Respuesta corta · Premium", "Краткий ответ · Premium", "Kurzantwort · Premium", "Réponse courte · Premium"],
    task_type_fill_blank: ["Užpildyti tarpą · Premium", "Fill in the blank · Premium", "Completar el espacio · Premium", "Заполнить пропуск · Premium", "Lückentext · Premium", "Texte à trous · Premium"],
    task_true: ["Tiesa", "True", "Verdadero", "Верно", "Wahr", "Vrai"],
    task_false: ["Netiesa", "False", "Falso", "Неверно", "Falsch", "Faux"],
    task_visibility_class: ["Mano klasei", "My class", "Mi clase", "Моему классу", "Meine Klasse", "Ma classe"],
    task_class_member_count: ["{students} mokinių · {invited} laukia kvietimo", "{students} students · {invited} invited", "{students} alumnos · {invited} invitados", "Учеников: {students} · приглашены: {invited}", "{students} Schüler · {invited} eingeladen", "{students} élèves · {invited} invités"],
    task_invite_usernames: ["Mokinių @username (atskirk kableliais arba eilutėmis)", "Student @usernames (separate with commas or new lines)", "@usernames de alumnos (separados por comas o líneas)", "@username учеников (через запятую или с новой строки)", "Schüler-@usernames (durch Kommas oder Zeilenumbrüche trennen)", "@usernames des élèves (séparés par des virgules ou retours à la ligne)"],
    task_invite_sent: ["išsiųstas kvietimas", "invitation sent", "invitación enviada", "приглашение отправлено", "Einladung gesendet", "invitation envoyée"],
    task_invite_already_sent: ["kvietimas jau išsiųstas", "invitation already sent", "invitación ya enviada", "приглашение уже отправлено", "Einladung bereits gesendet", "invitation déjà envoyée"],
    task_invite_member: ["jau prisijungęs", "already joined", "ya se unió", "уже присоединился", "bereits beigetreten", "a déjà rejoint"],
    task_invite_not_found: ["mokinys nerastas", "student not found", "alumno no encontrado", "ученик не найден", "Schüler nicht gefunden", "élève introuvable"],
    task_invalid_username: ["netinkamas @username", "invalid @username", "@username no válido", "неверный @username", "ungültiger @username", "@username invalide"],
    task_action_failed: ["nepavyko", "failed", "error", "ошибка", "fehlgeschlagen", "échec"],
    task_invites_sent: ["Kvietimų išsiųsta.", "Invitations sent.", "Invitaciones enviadas.", "Приглашения отправлены.", "Einladungen gesendet.", "Invitations envoyées."],
    task_member_joined: ["prisijungė", "joined", "se unió", "присоединился", "beigetreten", "a rejoint"],
    task_invite_waiting: ["laukiama atsakymo", "awaiting response", "pendiente de respuesta", "ожидает ответа", "wartet auf Antwort", "en attente de réponse"],
    task_invite_declined: ["atsisakė", "declined", "rechazó", "отклонил", "abgelehnt", "a refusé"],
    task_class_assignments: ["Klasės užduotys ({n})", "Class tasks ({n})", "Tareas de clase ({n})", "Задания класса ({n})", "Klassenaufgaben ({n})", "Exercices de la classe ({n})"],
    task_invited_by: ["Mokytojas: {name} (@{username})", "Teacher: {name} (@{username})", "Docente: {name} (@{username})", "Учитель: {name} (@{username})", "Lehrkraft: {name} (@{username})", "Enseignant : {name} (@{username})"],
    task_joined_class: ["Prisijungei prie klasės.", "You joined the class.", "Te uniste a la clase.", "Ты присоединился к классу.", "Du bist der Klasse beigetreten.", "Tu as rejoint la classe."],
    task_declined_invitation: ["Kvietimo atsisakei.", "You declined the invitation.", "Rechazaste la invitación.", "Ты отклонил приглашение.", "Du hast die Einladung abgelehnt.", "Tu as refusé l’invitation."],
    task_results_label: ["rezultatai", "results", "resultados", "результаты", "Ergebnisse", "résultats"],
    task_previous_score: ["ankstesnis rezultatas", "previous score", "resultado anterior", "предыдущий результат", "vorheriges Ergebnis", "résultat précédent"],
    task_share_by_username: ["Atsiųsti pagal @username", "Share by @username", "Compartir por @username", "Отправить по @username", "Per @username teilen", "Partager via @username"],
    task_shared: ["atsiųsta", "shared", "compartida", "отправлено", "geteilt", "partagé"],
    task_already_shared: ["jau atsiųsta", "already shared", "ya compartida", "уже отправлено", "bereits geteilt", "déjà partagé"],
    task_share_not_found: ["vartotojas nerastas arba profilis privatus", "user not found or profile is private", "usuario no encontrado o perfil privado", "пользователь не найден или профиль закрыт", "Nutzer nicht gefunden oder Profil privat", "utilisateur introuvable ou profil privé"],
    premium_period_label: ["Laikotarpis", "Term", "Periodo", "Период", "Zeitraum", "Durée"],
    premium_teacher_group: ["Mokytojams", "For teachers", "Para docentes", "Для учителей", "Für Lehrkräfte", "Pour les enseignants"],
    premium_school_group: ["Mokyklos vadovams", "For school leaders", "Para directores", "Для руководителей школ", "Für Schulleitungen", "Pour les directions d’établissement"],
    premium_plan_teacher_one: ["1 trimestras · 1,99 € mokiniui", "1 trimester · €1.99 per student", "1 trimestre · 1,99 € por alumno", "1 триместр · 1,99 € за ученика", "1 Trimester · 1,99 € pro Schüler", "1 trimestre · 1,99 € par élève"],
    premium_plan_teacher_two: ["2 trimestrai · 2,99 € mokiniui", "2 trimesters · €2.99 per student", "2 trimestres · 2,99 € por alumno", "2 триместра · 2,99 € за ученика", "2 Trimester · 2,99 € pro Schüler", "2 trimestres · 2,99 € par élève"],
    premium_plan_teacher_year: ["Mokslo metai · 3,99 € mokiniui", "School year · €3.99 per student", "Curso escolar · 3,99 € por alumno", "Учебный год · 3,99 € за ученика", "Schuljahr · 3,99 € pro Schüler", "Année scolaire · 3,99 € par élève"],
    premium_plan_school_one: ["1 trimestras · 0,99 € mokiniui", "1 trimester · €0.99 per student", "1 trimestre · 0,99 € por alumno", "1 триместр · 0,99 € за ученика", "1 Trimester · 0,99 € pro Schüler", "1 trimestre · 0,99 € par élève"],
    premium_plan_school_two: ["2 trimestrai · 1,99 € mokiniui", "2 trimesters · €1.99 per student", "2 trimestres · 1,99 € por alumno", "2 триместра · 1,99 € за ученика", "2 Trimester · 1,99 € pro Schüler", "2 trimestres · 1,99 € par élève"],
    premium_plan_school_three: ["3 trimestrai · 2,99 € mokiniui", "3 trimesters · €2.99 per student", "3 trimestres · 2,99 € por alumno", "3 триместра · 2,99 € за ученика", "3 Trimester · 2,99 € pro Schüler", "3 trimestres · 2,99 € par élève"],
    premium_calendar_title: ["Tavo mokyklos kalendorius", "Your school calendar", "Calendario escolar", "Календарь школы", "Dein Schulkalender", "Calendrier scolaire"],
    premium_calendar_help: ["Aktyvavimo kodai galios iki atitinkamo pasirinkto laikotarpio pabaigos. 1 trimestro planas baigiasi artimiausio trimestro pabaigoje, 2 trimestrų – antro trimestro pabaigoje, o mokslo metų planas – trečio trimestro pabaigoje.", "Activation codes expire at the end of the selected school term. The 1-trimester plan ends at the next term, the 2-trimester plan at the second term, and the school-year plan at the third term.", "Los códigos de activación vencen al final del periodo escolar seleccionado. El plan de 1 trimestre termina al final del próximo trimestre, el de 2 al final del segundo y el anual al final del tercero.", "Коды активации действуют до конца выбранного учебного периода. План на 1 триместр заканчивается в конце ближайшего, на 2 — второго, годовой — третьего триместра.", "Aktivierungscodes gelten bis zum Ende des gewählten Schulzeitraums. Der 1-Trimester-Plan endet mit dem nächsten, der 2-Trimester-Plan mit dem zweiten und der Jahresplan mit dem dritten Trimester.", "Les codes d’activation expirent à la fin de la période scolaire choisie. Le forfait d’un trimestre se termine à la fin du prochain trimestre, celui de deux à la fin du deuxième et l’annuel à la fin du troisième."],
    premium_teacher_purchase_description: ["Mokytojas vienu mokėjimu gali nupirkti 15–75 mokiniams Premium kodus. Kiekvienas mokinys aktyvuoja savo kodą atskiroje paskyroje.", "Teachers can make a one-time purchase of Premium codes for 15–75 students. Each student redeems a code in their own account.", "El docente puede comprar en un solo pago códigos Premium para 15–75 alumnos. Cada alumno canjea su código en su propia cuenta.", "Учитель может единоразово купить коды Premium для 15–75 учеников. Каждый ученик активирует свой код в отдельном аккаунте.", "Lehrkräfte können Premium-Codes für 15–75 Schüler einmalig kaufen. Jeder Schüler löst den eigenen Code im eigenen Konto ein.", "Un enseignant peut acheter en un seul paiement des codes Premium pour 15 à 75 élèves. Chaque élève active son code sur son propre compte."],
    premium_school_purchase_description: ["Mokyklos vadovas vienu mokėjimu gali nupirkti Premium kodus visos mokyklos mokiniams. Mažiausias užsakymas – 150 mokinių; viršutinės mokinių skaičiaus ribos nėra. Kiekvienas mokinys aktyvuoja atskirą kodą.", "School leaders can make a one-time purchase of Premium codes for the whole school. The minimum order is 150 students; there is no student-count cap. Each student redeems a separate code.", "La dirección puede comprar en un solo pago códigos Premium para toda la escuela. El pedido mínimo es de 150 alumnos y no hay límite máximo. Cada alumno canjea un código individual.", "Руководитель школы может единоразово купить коды Premium для всех учеников школы. Минимальный заказ — 150 учеников, максимального ограничения нет. Каждый ученик активирует отдельный код.", "Schulleitungen können Premium-Codes für die ganze Schule einmalig kaufen. Die Mindestbestellung beträgt 150 Schüler; eine Obergrenze gibt es nicht. Jeder Schüler löst einen eigenen Code ein.", "La direction peut acheter en un seul paiement des codes Premium pour toute l’école. La commande minimale est de 150 élèves, sans plafond. Chaque élève active un code individuel."],
    premium_student_count_teacher: ["Mokinių skaičius (15–75)", "Number of students (15–75)", "Número de alumnos (15–75)", "Число учеников (15–75)", "Anzahl der Schüler (15–75)", "Nombre d’élèves (15–75)"],
    premium_student_count_school: ["Mokinių skaičius (nuo 150)", "Number of students (150 or more)", "Número de alumnos (150 o más)", "Число учеников (от 150)", "Anzahl der Schüler (ab 150)", "Nombre d’élèves (150 minimum)"],
    premium_total_line: ["Vienkartinis mokėjimas · {unit} / mokiniui × {count} mokinių · iš viso {amount} už {period}.", "One-time payment · {unit} per student × {count} students · total {amount} for {period}.", "Pago único · {unit} por alumno × {count} alumnos · total {amount} por {period}.", "Разовый платёж · {unit} за ученика × {count} учеников · итого {amount} за {period}.", "Einmalzahlung · {unit} pro Schüler × {count} Schüler · Gesamt {amount} für {period}.", "Paiement unique · {unit} par élève × {count} élèves · total {amount} pour {period}."],
    premium_total_invalid: ["Įvesk tinkamą mokinių skaičių ir pasirink planą.", "Enter a valid student count and choose a plan.", "Introduce un número válido de alumnos y elige un plan.", "Введи корректное число учеников и выбери план.", "Gib eine gültige Schülerzahl ein und wähle einen Tarif.", "Saisis un nombre d’élèves valide et choisis une formule."],
    premium_plan_name_teacher_one: ["1 trimestro mokytojo planas", "Teacher plan · 1 trimester", "Plan docente · 1 trimestre", "План учителя · 1 триместр", "Lehrkräfteplan · 1 Trimester", "Forfait enseignant · 1 trimestre"],
    premium_plan_name_teacher_two: ["2 trimestrų mokytojo planas", "Teacher plan · 2 trimesters", "Plan docente · 2 trimestres", "План учителя · 2 триместра", "Lehrkräfteplan · 2 Trimester", "Forfait enseignant · 2 trimestres"],
    premium_plan_name_teacher_year: ["Mokslo metų mokytojo planas", "Teacher plan · school year", "Plan docente · curso escolar", "План учителя · учебный год", "Lehrkräfteplan · Schuljahr", "Forfait enseignant · année scolaire"],
    premium_plan_name_school_one: ["Mokyklos Premium · 1 trimestras", "School Premium · 1 trimester", "Premium escolar · 1 trimestre", "Premium школы · 1 триместр", "Schul-Premium · 1 Trimester", "Premium école · 1 trimestre"],
    premium_plan_name_school_two: ["Mokyklos Premium · 2 trimestrai", "School Premium · 2 trimesters", "Premium escolar · 2 trimestres", "Premium школы · 2 триместра", "Schul-Premium · 2 Trimester", "Premium école · 2 trimestres"],
    premium_plan_name_school_three: ["Mokyklos Premium · 3 trimestrai", "School Premium · 3 trimesters", "Premium escolar · 3 trimestres", "Premium школы · 3 триместра", "Schul-Premium · 3 Trimester", "Premium école · 3 trimestres"],
    task_shuffle_label: ["Maišyti klausimus ir atsakymų variantus", "Shuffle questions and answer choices", "Mezclar preguntas y opciones de respuesta", "Перемешивать вопросы и варианты ответов", "Fragen und Antwortoptionen mischen", "Mélanger les questions et les réponses"],
    task_preview_button: ["Peržiūrėti kaip mokiniui", "Preview as a student", "Vista previa como alumno", "Предпросмотр для ученика", "Vorschau aus Schülersicht", "Aperçu côté élève"],
    task_preview_heading: ["Užduoties peržiūra", "Task preview", "Vista previa de la tarea", "Предпросмотр задания", "Aufgabenvorschau", "Aperçu de l’exercice"],
    task_draft_saved: ["Juodraštis automatiškai išsaugotas šiame įrenginyje.", "Draft saved on this device.", "Borrador guardado en este dispositivo.", "Черновик сохранён на этом устройстве.", "Entwurf auf diesem Gerät gespeichert.", "Brouillon enregistré sur cet appareil."],
    task_draft_restored: ["Atkūriau šiame įrenginyje išsaugotą juodraštį.", "Restored the draft saved on this device.", "Se restauró el borrador guardado en este dispositivo.", "Восстановлен черновик с этого устройства.", "Der auf diesem Gerät gespeicherte Entwurf wurde wiederhergestellt.", "Le brouillon enregistré sur cet appareil a été restauré."],
    task_draft_save_failed: ["Juodraščio išsaugoti nepavyko. Patikrink naršyklės saugyklą.", "Couldn't save the draft. Check browser storage.", "No se pudo guardar el borrador. Revisa el almacenamiento del navegador.", "Не удалось сохранить черновик. Проверь хранилище браузера.", "Entwurf konnte nicht gespeichert werden. Prüfe den Browserspeicher.", "Impossible d’enregistrer le brouillon. Vérifie le stockage du navigateur."],
    task_draft_clear_failed: ["Juodraščio pašalinti nepavyko.", "Couldn't remove the draft.", "No se pudo eliminar el borrador.", "Не удалось удалить черновик.", "Entwurf konnte nicht entfernt werden.", "Impossible de supprimer le brouillon."],
    task_draft_discard: ["Išvalyti juodraštį", "Discard draft", "Descartar borrador", "Удалить черновик", "Entwurf verwerfen", "Supprimer le brouillon"],
    task_draft_restore_failed: ["Nepavyko atkurti užduoties juodraščio. Sukurk naują užduotį arba patikrink naršyklės saugyklą.", "Couldn't restore the task draft. Start a new task or check browser storage.", "No se pudo restaurar el borrador. Crea una tarea nueva o revisa el almacenamiento.", "Не удалось восстановить черновик. Создай новое задание или проверь хранилище браузера.", "Der Entwurf konnte nicht wiederhergestellt werden. Erstelle eine neue Aufgabe oder prüfe den Browserspeicher.", "Impossible de restaurer le brouillon. Crée un nouvel exercice ou vérifie le stockage du navigateur."],
    task_draft_cleared: ["Išsaugotas juodraštis pašalintas.", "Saved draft discarded.", "Borrador guardado eliminado.", "Сохранённый черновик удалён.", "Gespeicherter Entwurf verworfen.", "Brouillon enregistré supprimé."],
    task_copy_button: ["Kopijuoti į redaktorių", "Copy to editor", "Copiar al editor", "Скопировать в редактор", "In den Editor kopieren", "Copier dans l’éditeur"],
    task_copy_loaded: ["Užduoties kopija įkelta į redaktorių. Išsaugok kaip naują projektą.", "Task copied to the editor. Save it as a new project.", "Tarea copiada al editor. Guárdala como un proyecto nuevo.", "Задание скопировано в редактор. Сохрани его как новый проект.", "Aufgabe in den Editor kopiert. Speichere sie als neues Projekt.", "Exercice copié dans l’éditeur. Enregistre-le comme nouveau projet."],
    task_shuffle_instructions: ["Klausimai ir atsakymų variantai mokiniams bus rodomi atsitiktine tvarka.", "Questions and answer choices will appear in random order for students.", "Las preguntas y opciones aparecerán en orden aleatorio para los alumnos.", "Ученики увидят вопросы и варианты ответов в случайном порядке.", "Fragen und Antwortoptionen erscheinen für Schüler in zufälliger Reihenfolge.", "Les questions et réponses seront présentées dans un ordre aléatoire aux élèves."],
    task_review_mistakes: ["Pakartoti klaidingus atsakymus", "Review incorrect answers", "Repasar respuestas incorrectas", "Повторить ошибки", "Falsche Antworten wiederholen", "Revoir les réponses incorrectes"],
    task_review_empty: ["Puikiai! Šioje užduotyje klaidų nėra.", "Great! There are no mistakes in this task.", "¡Muy bien! No hay errores en esta tarea.", "Отлично! В этом задании нет ошибок.", "Super! In dieser Aufgabe gibt es keine Fehler.", "Bravo ! Aucune erreur dans cet exercice."],
    task_review_loading: ["Įkeliu klaidingus atsakymus…", "Loading incorrect answers…", "Cargando respuestas incorrectas…", "Загружаю неверные ответы…", "Lade falsche Antworten…", "Chargement des réponses incorrectes…"],
    task_review_item: ["Klausimas {n}", "Question {n}", "Pregunta {n}", "Вопрос {n}", "Frage {n}", "Question {n}"],
    task_review_your_answer: ["Tavo atsakymas", "Your answer", "Tu respuesta", "Твой ответ", "Deine Antwort", "Ta réponse"],
    task_review_correct_answer: ["Teisingas atsakymas", "Correct answer", "Respuesta correcta", "Правильный ответ", "Richtige Antwort", "Bonne réponse"],
    task_review_start: ["Pradėti kartojimą", "Start review", "Empezar repaso", "Начать повторение", "Wiederholung starten", "Commencer la révision"],
    task_review_done: ["Kartojimas baigtas. Rezultatas: {score}/{total}.", "Review complete. Score: {score}/{total}.", "Repaso terminado. Resultado: {score}/{total}.", "Повторение завершено. Результат: {score}/{total}.", "Wiederholung beendet. Ergebnis: {score}/{total}.", "Révision terminée. Score : {score}/{total}."],
    task_review_retry: ["Dar kartą peržiūrėti klaidas", "Review mistakes again", "Repasar errores otra vez", "Повторить ошибки ещё раз", "Fehler erneut ansehen", "Revoir les erreurs"],
    task_average_score: ["Klasės vidurkis: {score}%", "Class average: {score}%", "Promedio de clase: {score}%", "Средний балл класса: {score}%", "Klassendurchschnitt: {score}%", "Moyenne de la classe : {score} %"],
    task_analytics_heading: ["Pažangos suvestinė", "Progress summary", "Resumen de progreso", "Сводка успеваемости", "Fortschrittsübersicht", "Bilan de progression"],
    task_no_scores: ["Dar nėra pateiktų atsakymų.", "No submissions yet.", "Aún no hay entregas.", "Пока нет отправленных работ.", "Noch keine Abgaben.", "Aucune réponse envoyée pour le moment."],
    task_hardest_questions: ["Sunkiausi klausimai pagal klasės atsakymus", "Hardest questions based on class responses", "Preguntas más difíciles según las respuestas", "Самые сложные вопросы по ответам класса", "Schwierigste Fragen laut Klassenantworten", "Questions les plus difficiles d’après la classe"],
    task_question_correct_rate: ["Teisingai atsakė {correct}/{total} ({percent}%)", "{correct}/{total} answered correctly ({percent}%)", "{correct}/{total} respuestas correctas ({percent}%)", "Верно ответили {correct}/{total} ({percent}%)", "{correct}/{total} richtig ({percent}%)", "{correct}/{total} bonnes réponses ({percent} %)"],
    task_feedback_label: ["Asmeninė pastaba mokiniui", "Private note for student", "Nota privada para el alumno", "Личная заметка ученику", "Private Notiz für den Schüler", "Note privée pour l’élève"],
    task_feedback_placeholder: ["Trumpas patarimas apie šią užduotį", "A short note about this task", "Consejo breve sobre esta tarea", "Краткий совет по заданию", "Kurzer Hinweis zu dieser Aufgabe", "Petit conseil sur cet exercice"],
    task_feedback_save: ["Išsaugoti pastabą", "Save note", "Guardar nota", "Сохранить заметку", "Notiz speichern", "Enregistrer la note"],
    task_feedback_saved: ["Pastaba išsaugota.", "Note saved.", "Nota guardada.", "Заметка сохранена.", "Notiz gespeichert.", "Note enregistrée."],
    task_feedback_clear: ["Pastaba pašalinta.", "Note removed.", "Nota eliminada.", "Заметка удалена.", "Notiz entfernt.", "Note supprimée."],
    task_feedback_empty: ["Mokytojas dar nepaliko asmeninės pastabos.", "Your teacher hasn't left a private note yet.", "Tu docente aún no ha dejado una nota privada.", "Учитель пока не оставил личную заметку.", "Deine Lehrkraft hat noch keine private Notiz hinterlassen.", "Ton enseignant n’a pas encore laissé de note privée."],
    task_feedback_note: ["Mokytojo pastaba", "Teacher's note", "Nota del docente", "Заметка учителя", "Notiz der Lehrkraft", "Note de l’enseignant"],
    task_search_empty: ["Pagal šiuos filtrus užduočių nerasta.", "No tasks match these filters.", "No hay tareas que coincidan con los filtros.", "По этим фильтрам задания не найдены.", "Keine Aufgaben für diese Filter gefunden.", "Aucun exercice ne correspond à ces filtres."],
    task_reminder_title: ["Artėjantys ir pradelsti darbai", "Upcoming and overdue tasks", "Tareas próximas y vencidas", "Скоро срок или срок истёк", "Bald fällige und überfällige Aufgaben", "Exercices bientôt à rendre ou en retard"],
    task_reminder_due: ["„{title}“ – terminas {date}", "“{title}” – due {date}", "«{title}» – vence el {date}", "«{title}» — срок {date}", "„{title}“ – fällig am {date}", "« {title} » – à rendre le {date}"],
    task_reminder_overdue: ["„{title}“ – terminas praėjo ({date}), bet vis dar gali pateikti", "“{title}” – past due ({date}), but you can still submit", "«{title}» – vencida ({date}), pero aún puedes entregarla", "«{title}» — срок истёк ({date}), но задание ещё можно отправить", "„{title}“ – überfällig ({date}), du kannst sie aber noch abgeben", "« {title} » – en retard ({date}), mais tu peux encore l’envoyer"],
    task_filter_search: ["Ieškoti užduoties", "Search tasks", "Buscar tareas", "Поиск заданий", "Aufgaben suchen", "Rechercher des exercices"],
    task_filter_placeholder: ["Pavadinimas ar dalykas", "Title or subject", "Título o materia", "Название или предмет", "Titel oder Fach", "Titre ou matière"],
    task_filter_status: ["Būsena", "Status", "Estado", "Статус", "Status", "Statut"],
    task_filter_all: ["Visos", "All", "Todas", "Все", "Alle", "Tout"],
    task_filter_pending: ["Nepateiktos", "Not submitted", "Sin entregar", "Не отправлены", "Nicht abgegeben", "Non envoyés"],
    task_filter_submitted: ["Pateiktos", "Submitted", "Entregadas", "Отправлены", "Abgegeben", "Envoyés"],
    accessibility_title: ["Prieinamumas", "Accessibility", "Accesibilidad", "Специальные возможности", "Barrierefreiheit", "Accessibilité"],
    accessibility_large_text: ["Didesnis tekstas", "Larger text", "Texto más grande", "Увеличить текст", "Größerer Text", "Texte plus grand"],
    accessibility_high_contrast: ["Didesnis kontrastas", "Higher contrast", "Mayor contraste", "Повышенная контрастность", "Höherer Kontrast", "Contraste renforcé"],
    accessibility_reduce_motion: ["Sumažinti animaciją", "Reduce motion", "Reducir animación", "Уменьшить анимацию", "Bewegung reduzieren", "Réduire les animations"],
    accessibility_help: ["Šie nustatymai išsaugomi šioje naršyklėje ir galioja visuose puslapiuose.", "These settings are saved in this browser and apply across the site.", "Estos ajustes se guardan en este navegador y se aplican en todo el sitio.", "Настройки сохраняются в этом браузере и действуют на всём сайте.", "Diese Einstellungen werden in diesem Browser gespeichert und gelten für die gesamte Website.", "Ces réglages sont enregistrés dans ce navigateur et s’appliquent à tout le site."],
    accessibility_saved: ["Nuostata išsaugota.", "Preference saved.", "Preferencia guardada.", "Настройка сохранена.", "Einstellung gespeichert.", "Préférence enregistrée."],
    learning_preferences_title: ["Mokymosi nuostatos", "Learning preferences", "Preferencias de aprendizaje", "Настройки обучения", "Lerneinstellungen", "Préférences d’apprentissage"],
    show_explanations: ["Rodyti atsakymų paaiškinimus", "Show answer explanations", "Mostrar explicaciones de respuestas", "Показывать объяснения ответов", "Antworterklärungen anzeigen", "Afficher les explications des réponses"],
    learning_preferences_help: ["Išjungus bus rodomas teisingumas ir rezultatas, bet ne paaiškinimo tekstas.", "When disabled, correctness and scores remain visible, but explanation text is hidden.", "Al desactivarlo, seguirás viendo si acertaste y tu puntuación, pero no el texto explicativo.", "При отключении правильность и результат останутся видны, но текст объяснения будет скрыт.", "Bei Deaktivierung bleiben Richtigkeit und Ergebnis sichtbar, der Erklärungstext wird ausgeblendet.", "Désactivé, le résultat reste visible, mais le texte explicatif est masqué."],
    settings_learning_tab: ["Mokymosi nuostatos", "Learning preferences", "Preferencias de aprendizaje", "Настройки обучения", "Lerneinstellungen", "Préférences d’apprentissage"],
    learning_plan_kicker: ["TAVO MOKYMOSI PLANAS", "YOUR STUDY PLAN", "TU PLAN DE ESTUDIO", "ТВОЙ ПЛАН ОБУЧЕНИЯ", "DEIN LERNPLAN", "TON PLAN D’ÉTUDE"],
    learning_plan_intro: ["Pasirink dalykus, klasę ir sudėtingumą, nuo kurių nori pradėti. Šios nuostatos saugomos tik šiame įrenginyje.", "Choose your subjects, grade and starting difficulty. These preferences are stored only on this device.", "Elige las materias, el curso y la dificultad inicial. Estas preferencias solo se guardan en este dispositivo.", "Выбери предметы, класс и начальный уровень сложности. Настройки хранятся только на этом устройстве.", "Wähle Fächer, Klassenstufe und Schwierigkeitsgrad. Diese Einstellungen werden nur auf diesem Gerät gespeichert.", "Choisis tes matières, ta classe et la difficulté de départ. Ces préférences restent sur cet appareil."],
    learning_default_subject: ["Numatytasis dalykas", "Default subject", "Materia predeterminada", "Предмет по умолчанию", "Standardfach", "Matière par défaut"],
    learning_grade_default: ["Dažniausiai mokaisi šioje klasėje", "Your grade", "Tu curso", "Твой класс", "Deine Klassenstufe", "Ta classe"],
    learning_favorites: ["Mėgstami dalykai (pasirink kelis)", "Favorite subjects (choose several)", "Materias favoritas (elige varias)", "Любимые предметы (можно выбрать несколько)", "Lieblingsfächer (mehrere auswählen)", "Matières favorites (plusieurs choix)"],
    learning_difficulty_default: ["Praktikos sudėtingumas", "Practice difficulty", "Dificultad de práctica", "Сложность практики", "Schwierigkeitsgrad", "Difficulté des exercices"],
    learning_all_levels: ["Visi lygiai", "All levels", "Todos los niveles", "Все уровни", "Alle Stufen", "Tous les niveaux"],
    learning_favorites_help: ["Mėgstami dalykai bus rodomi pirmiau praktikos pasirinkime. Klasės nuostata parenkama ir AI korepetitoriui; atsiskaitymo užduotys šiuo metu kuriamos 7–10 klasėms.", "Favorite subjects appear first in practice. Your grade is also used by the AI tutor; generated assessment tasks currently support grades 7–10.", "Las materias favoritas aparecen primero en la práctica. El curso también se usa para el tutor IA; las tareas de examen generadas admiten actualmente los cursos 7–10.", "Любимые предметы будут первыми в практике. Класс также используется ИИ-репетитором; задания для подготовки сейчас создаются для 7–10 классов.", "Lieblingsfächer erscheinen zuerst in der Übungsauswahl. Deine Klassenstufe wird auch vom KI-Tutor verwendet; erstellte Prüfungsvorbereitung unterstützt derzeit die Klassen 7–10.", "Tes matières favorites apparaissent en premier dans les exercices. Ta classe sert aussi au tuteur IA ; les exercices générés prennent actuellement en charge les classes de 7 à 10."],
    learning_ai_settings: ["AI korepetitoriaus bendravimas", "AI tutor preferences", "Preferencias del tutor IA", "Настройки ИИ-репетитора", "KI-Tutor-Einstellungen", "Préférences du tuteur IA"],
    learning_ai_name: ["Korepetitoriaus vardas", "Tutor name", "Nom del tutor", "Имя репетитора", "Name des Tutors", "Nom du tuteur"],
    learning_ai_mood: ["Nuotaika", "Tone", "Tono", "Тон общения", "Stimmung", "Ton"],
    learning_ai_style: ["Kaip AI turėtų padėti?", "How should the AI help?", "¿Cómo debería ayudarte la IA?", "Как ИИ должен помогать?", "Wie soll die KI helfen?", "Comment l’IA doit-elle t’aider ?"],
    learning_ai_shared: ["Šie nustatymai bendri su AI korepetitoriaus skiltimi ir saugomi šiame įrenginyje.", "These settings are shared with the AI tutor and saved on this device.", "Estos ajustes se comparten con el tutor IA y se guardan en este dispositivo.", "Настройки используются ИИ-репетитором и хранятся на этом устройстве.", "Diese Einstellungen gelten auch für den KI-Tutor und werden auf diesem Gerät gespeichert.", "Ces réglages sont partagés avec le tuteur IA et enregistrés sur cet appareil."],
    buddy_cheerful: ["Linksmas ir žaismingas", "Cheerful and playful", "Alegre y divertido", "Весёлый и игривый", "Fröhlich und verspielt", "Joyeux et ludique"],
    buddy_gloomy: ["Niūrus, bet palaikantis", "Gloomy but supportive", "Serio, pero comprensivo", "Угрюмый, но поддерживающий", "Mürrisch, aber unterstützend", "Morose mais encourageant"],
    buddy_serious: ["Rimtas ir dalykiškas", "Serious and professional", "Serio y profesional", "Серьёзный и деловой", "Ernst und sachlich", "Sérieux et professionnel"],
    buddy_grumpy: ["Juokingai piktas (be įžeidimų)", "Comically grumpy (never insulting)", "Gruñón de broma (sin insultos)", "Шутливо ворчливый (без оскорблений)", "Scherzhaft mürrisch (nie beleidigend)", "Grognon pour rire (sans insultes)"],
    buddy_calm: ["Ramus ir kantrus", "Calm and patient", "Tranquilo y paciente", "Спокойный и терпеливый", "Ruhig und geduldig", "Calme et patient"],
    buddy_motivating: ["Motyvuojantis treneris", "Motivating coach", "Entrenador motivador", "Мотивирующий наставник", "Motivierender Coach", "Coach motivant"],
    buddy_steps: ["Paaiškinti žingsniais", "Explain step by step", "Explicar paso a paso", "Объяснять по шагам", "Schrittweise erklären", "Expliquer étape par étape"],
    buddy_brief: ["Atsakyti trumpai", "Keep answers brief", "Responder brevemente", "Отвечать кратко", "Kurz antworten", "Répondre brièvement"],
    buddy_examples: ["Pateikti pavyzdžių", "Give examples", "Dar ejemplos", "Приводить примеры", "Beispiele geben", "Donner des exemples"],
    buddy_quiz: ["Užduoti klausimų ir patikrinti mane", "Ask questions and quiz me", "Hacer preguntas y ponerme a prueba", "Задавать вопросы и проверять меня", "Fragen stellen und mich abfragen", "Poser des questions et m’interroger"],
    settings_saved_local: ["Nuostata išsaugota šiame įrenginyje.", "Preference saved on this device.", "Preferencia guardada en este dispositivo.", "Настройка сохранена на этом устройстве.", "Einstellung auf diesem Gerät gespeichert.", "Préférence enregistrée sur cet appareil."],
    reminder_intro: ["Pasirink, ar nori vietinio priminimo apie mokymąsi. El. pašto naujienų ir nuotolinių pranešimų siuntimas nėra prijungtas.", "Choose whether to receive a local study reminder. Email updates and remote notifications are not configured.", "Elige si quieres un recordatorio de estudio local. No están configurados los correos ni las notificaciones remotas.", "Настрой локальное напоминание об учёбе. Email-рассылки и удалённые уведомления не настроены.", "Lege fest, ob du eine lokale Lernerinnerung möchtest. E-Mail- und Fernbenachrichtigungen sind nicht eingerichtet.", "Choisis si tu veux un rappel d’étude local. Les e-mails et notifications à distance ne sont pas configurés."],
    reminder_title: ["Mokymosi priminimas šiame įrenginyje", "Study reminder on this device", "Recordatorio de estudio en este dispositivo", "Напоминание об учёбе на этом устройстве", "Lernerinnerung auf diesem Gerät", "Rappel d’étude sur cet appareil"],
    reminder_enabled: ["Įjungti kasdienį naršyklės priminimą", "Enable daily browser reminder", "Activar recordatorio diario del navegador", "Включить ежедневное напоминание в браузере", "Tägliche Browser-Erinnerung aktivieren", "Activer le rappel quotidien du navigateur"],
    reminder_time: ["Priminimo laikas", "Reminder time", "Hora del recordatorio", "Время напоминания", "Erinnerungszeit", "Heure du rappel"],
    reminder_help: ["Priminimas siunčiamas tik šiame įrenginyje, jei naršyklė leidžia pranešimus ir svetainė yra atidaryta nustatytu laiku. Tai nėra el. pašto ar fone veikiančio priminimo paslauga.", "The reminder is local to this device and appears only if browser notifications are allowed and the site is open at the chosen time. It is not an email or background reminder service.", "El recordatorio es local y solo aparece si el navegador permite notificaciones y el sitio está abierto a la hora elegida. No es un servicio de correo ni funciona en segundo plano.", "Напоминание создаётся только на этом устройстве, если браузер разрешает уведомления и сайт открыт в выбранное время. Email-рассылки и фоновой службы нет.", "Die Erinnerung erscheint nur auf diesem Gerät, wenn Browser-Benachrichtigungen erlaubt sind und die Website zur gewählten Zeit geöffnet ist. Es gibt keinen E-Mail- oder Hintergrunddienst.", "Le rappel est local et ne s’affiche que si le navigateur autorise les notifications et que le site est ouvert à l’heure choisie. Aucun e-mail ni service en arrière-plan n’est utilisé."],
    reminder_permission_button: ["Leisti naršyklės pranešimus", "Allow browser notifications", "Permitir notificaciones del navegador", "Разрешить уведомления браузера", "Browser-Benachrichtigungen erlauben", "Autoriser les notifications du navigateur"],
    reminder_invalid_time: ["Pasirink galiojantį priminimo laiką.", "Choose a valid reminder time.", "Elige una hora válida para el recordatorio.", "Выбери корректное время напоминания.", "Wähle eine gültige Erinnerungszeit.", "Choisis une heure de rappel valide."],
    reminder_need_permission: ["Įjungta, bet priminimas veiks tik leidus naršyklės pranešimus.", "Enabled, but browser notification permission is required.", "Activado, pero se necesita permiso para las notificaciones del navegador.", "Включено, но требуется разрешение браузера на уведомления.", "Aktiviert, aber Browser-Benachrichtigungen müssen erlaubt sein.", "Activé, mais l’autorisation des notifications du navigateur est requise."],
    reminder_disabled: ["Priminimai išjungti.", "Reminders are off.", "Los recordatorios están desactivados.", "Напоминания выключены.", "Erinnerungen sind ausgeschaltet.", "Les rappels sont désactivés."],
    reminder_permission_granted: ["Leidimas suteiktas. Vietinis priminimas bus rodomas pasirinktu laiku, kai svetainė atidaryta.", "Permission granted. The local reminder will appear at the selected time while the site is open.", "Permiso concedido. El recordatorio local aparecerá a la hora elegida mientras el sitio esté abierto.", "Разрешение получено. Локальное напоминание появится в выбранное время, пока сайт открыт.", "Erlaubnis erteilt. Die lokale Erinnerung erscheint zur gewählten Zeit, solange die Website geöffnet ist.", "Autorisation accordée. Le rappel local apparaîtra à l’heure choisie lorsque le site est ouvert."],
    reminder_permission_denied: ["Pranešimai užblokuoti. Pakeisk leidimą naršyklės svetainės nustatymuose.", "Notifications are blocked. Change the permission in your browser's site settings.", "Las notificaciones están bloqueadas. Cambia el permiso en los ajustes del sitio del navegador.", "Уведомления заблокированы. Измени разрешение в настройках сайта браузера.", "Benachrichtigungen sind blockiert. Ändere die Berechtigung in den Website-Einstellungen des Browsers.", "Les notifications sont bloquées. Modifie l’autorisation dans les réglages du site du navigateur."],
    reminder_permission_missing: ["Leidimas nesuteiktas; priminimai neveiks.", "Permission was not granted; reminders will not work.", "No se concedió el permiso; los recordatorios no funcionarán.", "Разрешение не предоставлено; напоминания работать не будут.", "Keine Erlaubnis erteilt; Erinnerungen funktionieren nicht.", "Autorisation non accordée ; les rappels ne fonctionneront pas."],
    reminder_not_supported: ["Ši naršyklė nepalaiko naršyklės pranešimų.", "This browser does not support notifications.", "Este navegador no admite notificaciones.", "Этот браузер не поддерживает уведомления.", "Dieser Browser unterstützt keine Benachrichtigungen.", "Ce navigateur ne prend pas en charge les notifications."],
    reminder_https: ["Naršyklės pranešimams reikia saugaus HTTPS ryšio.", "Browser notifications require a secure HTTPS connection.", "Las notificaciones requieren una conexión HTTPS segura.", "Для уведомлений браузера требуется безопасное HTTPS-соединение.", "Browser-Benachrichtigungen benötigen eine sichere HTTPS-Verbindung.", "Les notifications nécessitent une connexion HTTPS sécurisée."],
    reminder_permission_error: ["Nepavyko paprašyti leidimo: {message}", "Could not request permission: {message}", "No se pudo solicitar el permiso: {message}", "Не удалось запросить разрешение: {message}", "Berechtigung konnte nicht angefordert werden: {message}", "Impossible de demander l’autorisation : {message}"],
    data_controls_title: ["Privatumas ir tavo duomenys", "Privacy and your data", "Privacidad y tus datos", "Конфиденциальность и данные", "Datenschutz und deine Daten", "Confidentialité et données"],
    data_controls_description: ["Mokymosi istorija, atminties kortelės ir savaitės planas saugomi šios naršyklės vietinėje saugykloje. Pažanga ir paskyros duomenys, kuriuos sinchronizuoja serveris, lieka atskirai.", "Learning history, flashcards and weekly plans are stored in this browser. Progress and account data synced by the server are separate.", "El historial, las tarjetas y el plan semanal se guardan en este navegador. El progreso y los datos sincronizados con el servidor son independientes.", "История обучения, карточки и недельный план хранятся в этом браузере. Синхронизируемые сервером данные и прогресс хранятся отдельно.", "Lernverlauf, Karteikarten und Wochenplan werden in diesem Browser gespeichert. Serverseitig synchronisierte Konto- und Fortschrittsdaten sind davon getrennt.", "L’historique, les cartes et le plan hebdomadaire sont stockés dans ce navigateur. Les données synchronisées par le serveur restent séparées."],
    data_export_button: ["Atsisiųsti vietinius mokymosi duomenis", "Export local learning data", "Descargar datos de aprendizaje locales", "Экспортировать локальные учебные данные", "Lokale Lerndaten exportieren", "Exporter les données d’apprentissage locales"],
    data_clear_button: ["Išvalyti šio įrenginio mokymosi istoriją", "Clear learning history on this device", "Borrar el historial de aprendizaje de este dispositivo", "Очистить историю обучения на этом устройстве", "Lernverlauf auf diesem Gerät löschen", "Effacer l’historique d’apprentissage de cet appareil"],
    data_session_title: ["Aktyvios sesijos ir paskyros ištrynimas", "Active sessions and account deletion", "Sesiones activas y eliminación de la cuenta", "Активные сеансы и удаление аккаунта", "Aktive Sitzungen und Kontolöschung", "Sessions actives et suppression du compte"],
    data_session_prefix: ["Šioje svetainėje negalima peržiūrėti ar nuotoliniu būdu atjungti kitų sesijų. Norėdamas ištrinti paskyrą, parašyk ", "This site cannot show or remotely sign out other sessions. To request account deletion, email ", "Este sitio no permite ver ni cerrar otras sesiones de forma remota. Para solicitar la eliminación de la cuenta, escribe a ", "На этом сайте нельзя просматривать или удалённо завершать другие сеансы. Чтобы запросить удаление аккаунта, напиши на ", "Diese Website kann andere Sitzungen weder anzeigen noch aus der Ferne abmelden. Um die Kontolöschung zu beantragen, schreibe an ", "Ce site ne permet pas de consulter ni de fermer d’autres sessions à distance. Pour demander la suppression du compte, écris à "],
    data_session_suffix: ["; gali reikėti patvirtinti paskyros savininkystę.", "; account ownership may need to be verified.", "; puede ser necesario verificar que eres el titular.", "; может потребоваться подтверждение владельца аккаунта.", "; möglicherweise musst du deine Kontoinhaberschaft bestätigen.", "; une vérification de propriété du compte peut être nécessaire."],
    data_export_success: ["Vietinių mokymosi duomenų eksportas paruoštas JSON formatu. Serverio duomenys neįtraukti.", "Local learning data was exported as JSON. Server data is not included.", "Los datos locales se exportaron en formato JSON. No se incluyen los datos del servidor.", "Локальные учебные данные экспортированы в JSON. Данные сервера не включены.", "Lokale Lerndaten wurden als JSON exportiert. Serverdaten sind nicht enthalten.", "Les données locales ont été exportées au format JSON. Les données du serveur ne sont pas incluses."],
    data_export_read_error: ["Nepavyko perskaityti vietinių duomenų. Patikrink naršyklės saugyklos leidimus.", "Could not read local data. Check your browser storage permissions.", "No se pudieron leer los datos locales. Comprueba los permisos de almacenamiento del navegador.", "Не удалось прочитать локальные данные. Проверь разрешения хранилища браузера.", "Lokale Daten konnten nicht gelesen werden. Prüfe die Speicherberechtigungen des Browsers.", "Impossible de lire les données locales. Vérifie les autorisations de stockage du navigateur."],
    data_clear_confirm: ["Ištrinti šiame įrenginyje saugomą mokymosi istoriją, atminties kortelių eigą, savaitės planus ir svečio pažangą? Šis veiksmas negrįžtamas. Serverio paskyros duomenys nebus pakeisti.", "Delete this device's learning history, flashcard progress, weekly plans and guest progress? This cannot be undone. Server account data will not change.", "¿Borrar el historial, el progreso de las tarjetas, los planes semanales y el progreso de invitado de este dispositivo? No se puede deshacer. Los datos del servidor no cambiarán.", "Удалить историю обучения, прогресс карточек, недельные планы и гостевой прогресс на этом устройстве? Это действие нельзя отменить. Данные аккаунта на сервере не изменятся.", "Lernverlauf, Karteikartenfortschritt, Wochenpläne und Gastfortschritt auf diesem Gerät löschen? Dies kann nicht rückgängig gemacht werden. Serverdaten bleiben unverändert.", "Supprimer l’historique, la progression des cartes, les plans hebdomadaires et la progression invitée de cet appareil ? Cette action est irréversible. Les données du serveur ne changeront pas."],
    data_clear_success: ["Šio įrenginio mokymosi istorija išvalyta. Serverio paskyros duomenys nepakeisti.", "Learning history on this device was cleared. Server account data was not changed.", "Se borró el historial de este dispositivo. Los datos de la cuenta en el servidor no cambiaron.", "История обучения на этом устройстве очищена. Данные аккаунта на сервере не изменились.", "Der Lernverlauf auf diesem Gerät wurde gelöscht. Serverdaten des Kontos blieben unverändert.", "L’historique de cet appareil a été effacé. Les données du compte sur le serveur n’ont pas changé."],
    data_clear_error: ["Nepavyko išvalyti visų duomenų: {message}", "Could not clear all data: {message}", "No se pudieron borrar todos los datos: {message}", "Не удалось очистить все данные: {message}", "Nicht alle Daten konnten gelöscht werden: {message}", "Impossible d’effacer toutes les données : {message}"],
    settings_save_error: ["Nepavyko išsaugoti nuostatos. Patikrink naršyklės saugyklos leidimus.", "Could not save the preference. Check your browser storage permissions.", "No se pudo guardar la preferencia. Comprueba los permisos de almacenamiento del navegador.", "Не удалось сохранить настройку. Проверь разрешения хранилища браузера.", "Einstellung konnte nicht gespeichert werden. Prüfe die Speicherberechtigungen des Browsers.", "Impossible d’enregistrer la préférence. Vérifie les autorisations de stockage du navigateur."],
    settings_restore_error: ["Nepavyko atkurti nuostatų: {message}", "Could not restore preferences: {message}", "No se pudieron restaurar las preferencias: {message}", "Не удалось восстановить настройки: {message}", "Einstellungen konnten nicht wiederhergestellt werden: {message}", "Impossible de restaurer les préférences : {message}"],
    settings_restore_title: ["Numatytųjų nuostatų atkūrimas", "Restore default preferences", "Restaurar preferencias predeterminadas", "Восстановление настроек по умолчанию", "Standardeinstellungen wiederherstellen", "Restaurer les préférences par défaut"],
    settings_restore_description: ["Atkurs kalbą, temą, prieinamumo, mokymosi, AI ir priminimų nuostatas. Tavo pažanga, testų istorija ir paskyros duomenys nebus ištrinti.", "Resets language, theme, accessibility, learning, AI and reminder preferences. Your progress, test history and account data are kept.", "Restablece el idioma, el tema, la accesibilidad, el aprendizaje, la IA y los recordatorios. Se conservan el progreso, el historial y los datos de la cuenta.", "Сбросит язык, тему, настройки доступности, обучения, ИИ и напоминаний. Прогресс, история тестов и данные аккаунта сохранятся.", "Setzt Sprache, Design, Barrierefreiheit, Lernen, KI und Erinnerungen zurück. Fortschritt, Testverlauf und Kontodaten bleiben erhalten.", "Réinitialise la langue, le thème, l’accessibilité, l’apprentissage, l’IA et les rappels. La progression, l’historique et les données du compte sont conservés."],
    settings_restore_button: ["Atkurti numatytąsias nuostatas", "Restore defaults", "Restaurar valores predeterminados", "Восстановить настройки по умолчанию", "Standardeinstellungen wiederherstellen", "Restaurer les valeurs par défaut"],
    settings_restore_confirm: ["Atkurti numatytąsias nuostatas? Mokymosi istorija ir pažanga liks nepakeista.", "Restore default preferences? Your learning history and progress will remain unchanged.", "¿Restaurar las preferencias predeterminadas? El historial y el progreso no cambiarán.", "Восстановить настройки по умолчанию? История обучения и прогресс останутся без изменений.", "Standardeinstellungen wiederherstellen? Lernverlauf und Fortschritt bleiben unverändert.", "Restaurer les préférences par défaut ? L’historique et la progression resteront inchangés."],
    settings_restore_success: ["Numatytosios nuostatos atkurtos. Mokymosi istorija ir pažanga išsaugota.", "Defaults restored. Learning history and progress were preserved.", "Se restauraron los valores predeterminados. Se conservaron el historial y el progreso.", "Настройки восстановлены. История обучения и прогресс сохранены.", "Standardeinstellungen wiederhergestellt. Lernverlauf und Fortschritt bleiben erhalten.", "Valeurs par défaut restaurées. L’historique et la progression ont été conservés."],
    learning_summary_title: ["Tavo dalykų pažanga", "Your subject progress", "Tu progreso por materia", "Твой прогресс по предметам", "Dein Lernfortschritt nach Fach", "Ta progression par matière"],
    learning_summary_empty: ["Atsakyk į praktikos klausimus – čia matysi savo rezultatus pagal dalyką. Suvestinė saugoma šiame įrenginyje.", "Answer practice questions to see your results by subject. This summary is saved on this device.", "Responde preguntas de práctica para ver tus resultados por materia. Este resumen se guarda en este dispositivo.", "Отвечай на практические вопросы, чтобы видеть результаты по предметам. Сводка хранится на этом устройстве.", "Beantworte Übungsfragen, um deine Ergebnisse nach Fach zu sehen. Diese Übersicht wird auf diesem Gerät gespeichert.", "Réponds aux questions d’entraînement pour voir tes résultats par matière. Ce résumé est enregistré sur cet appareil."],
    learning_summary_count: ["{correct} iš {total} teisingai · {percent} %", "{correct} of {total} correct · {percent}%", "{correct} de {total} correctas · {percent} %", "Правильно: {correct} из {total} · {percent} %", "{correct} von {total} richtig · {percent} %", "{correct} sur {total} correctes · {percent} %"],
    adaptive_recommendation: ["Kitas rekomenduojamas sunkumas: {level}.", "Recommended difficulty next: {level}.", "Dificultad recomendada para el próximo test: {level}.", "Рекомендуемая сложность следующего теста: {level}.", "Empfohlener Schwierigkeitsgrad für den nächsten Test: {level}.", "Difficulté recommandée pour le prochain test : {level}."],
    pq_daily: ["Dienos iššūkis", "Daily challenge", "Reto diario", "Ежедневный вызов", "Tages-Challenge", "Défi quotidien"],
    pq_progress: ["{s} · {i} iš {n}", "{s} · {i} of {n}", "{s} · {i} de {n}", "{s} · {i} из {n}", "{s} · {i} von {n}", "{s} · {i} sur {n}"],
    pq_next: ["Kitas klausimas →", "Next question →", "Siguiente pregunta →", "Следующий вопрос →", "Nächste Frage →", "Question suivante →"],
    pq_result: ["Peržiūrėti rezultatą →", "See the result →", "Ver el resultado →", "Посмотреть результат →", "Ergebnis ansehen →", "Voir le résultat →"],
    pq_right: ["Teisingai!", "Correct!", "¡Correcto!", "Верно!", "Richtig!", "Correct !"],
    pq_wrong: ["Dar ne visai.", "Not quite.", "Todavía no.", "Пока не совсем.", "Noch nicht ganz.", "Pas tout à fait."],
    pq_streak_bonus: [" Pasiekei 10 dienų seriją — gavai papildomų 80 XP!", " You reached a 10-day streak — you earned an extra 80 XP!", " Has llegado a una racha de 10 días: ¡80 XP extra!", " Ты достиг серии в 10 дней — получаешь дополнительные 80 XP!", " Du hast eine 10-Tage-Serie erreicht – 80 Extra-XP!", " Tu as atteint une série de 10 jours : 80 XP en plus !"],
    pq_limit_reached: ["Šiandienos klausimų limitas pasiektas; atsakymas nebuvo įskaitytas į pažangą.", "Today’s question limit is reached; this answer did not count towards your progress.", "Se alcanzó el límite de preguntas de hoy; la respuesta no se contó en tu progreso.", "Лимит вопросов на сегодня исчерпан; ответ не засчитан в прогресс.", "Das heutige Fragenlimit ist erreicht; die Antwort zählte nicht für den Fortschritt.", "La limite de questions du jour est atteinte ; la réponse n’a pas été comptée dans ta progression."],
    pq_timer: ["Likęs laikas: {t}", "Time left: {t}", "Tiempo restante: {t}", "Осталось времени: {t}", "Verbleibende Zeit: {t}", "Temps restant : {t}"],
    pq_great: ["Puikiai padirbėta!", "Great job!", "¡Muy buen trabajo!", "Отличная работа!", "Super gemacht!", "Excellent travail !"],
    pq_good: ["Geras žingsnis į priekį!", "A good step forward!", "¡Un buen paso adelante!", "Хороший шаг вперёд!", "Ein guter Schritt nach vorn!", "Un bon pas en avant !"],
    pq_score: ["Teisingai atsakei į {c} iš {n} klausimų ({p} %).", "You answered {c} of {n} questions correctly ({p}%).", "Respondiste bien {c} de {n} preguntas ({p} %).", "Правильных ответов: {c} из {n} ({p} %).", "Du hast {c} von {n} Fragen richtig beantwortet ({p} %).", "Tu as répondu juste à {c} questions sur {n} ({p} %)."],
    pq_retry: ["Bandyk dar kartą →", "Try again →", "Inténtalo de nuevo →", "Попробуй ещё раз →", "Noch einmal versuchen →", "Réessayer →"],
    pq_no_review: ["Dar neturi išsaugotų klaidingų atsakymų šiam dalykui. Pirmiausia atlik mini testuką arba pasirink kitą dalyką.", "You have no saved wrong answers for this subject yet. Take a mini quiz first or pick another subject.", "Aún no tienes respuestas incorrectas guardadas para esta materia. Haz primero un minitest o elige otra materia.", "У тебя пока нет сохранённых ошибок по этому предмету. Сначала пройди мини-тест или выбери другой предмет.", "Du hast für dieses Fach noch keine gespeicherten falschen Antworten. Mach zuerst einen Minitest oder wähle ein anderes Fach.", "Tu n’as pas encore de mauvaises réponses enregistrées pour cette matière. Fais d’abord un mini-quiz ou choisis une autre matière."],
    pq_daily_done: ["Šiandien išnaudojai 15 nemokamų klausimų. Premium nariams dienos klausimų limitas netaikomas.", "You have used your 15 free questions today. Premium members have no daily question limit.", "Hoy has usado tus 15 preguntas gratuitas. Los miembros Premium no tienen límite diario.", "Сегодня ты использовал 15 бесплатных вопросов. У Premium-участников дневного лимита нет.", "Du hast heute deine 15 kostenlosen Fragen verbraucht. Premium-Mitglieder haben kein Tageslimit.", "Tu as utilisé tes 15 questions gratuites aujourd’hui. Les membres Premium n’ont pas de limite quotidienne."],
    pq_limit_err: ["Nepavyko patikrinti dienos limito: {m}", "Could not check the daily limit: {m}", "No se pudo comprobar el límite diario: {m}", "Не удалось проверить дневной лимит: {m}", "Das Tageslimit konnte nicht geprüft werden: {m}", "Impossible de vérifier la limite quotidienne : {m}"],
    pq_no_cards: ["Šiam dalykui kortelių nėra. Pasirink kitą dalyką.", "There are no cards for this subject. Pick another subject.", "No hay tarjetas para esta materia. Elige otra.", "Для этого предмета карточек нет. Выбери другой предмет.", "Für dieses Fach gibt es keine Karten. Wähle ein anderes Fach.", "Aucune carte pour cette matière. Choisis-en une autre."],
    pq_card_flip: ["Apversti atminties kortelę", "Flip the memory card", "Dar la vuelta a la tarjeta", "Перевернуть карточку", "Lernkarte umdrehen", "Retourner la carte mémoire"],
    pq_card_hint: ["Spėk atsakymą ir paspausk kortelę, kad ją apverstum", "Guess the answer and press the card to flip it", "Adivina la respuesta y pulsa la tarjeta para darle la vuelta", "Угадай ответ и нажми на карточку, чтобы перевернуть её", "Rate die Antwort und tippe auf die Karte, um sie umzudrehen", "Devine la réponse puis appuie sur la carte pour la retourner"],
    pq_again: ["Dar kartą", "Again", "Otra vez", "Ещё раз", "Nochmal", "Encore"],
    pq_know: ["Moku ✓", "I know it ✓", "Lo sé ✓", "Знаю ✓", "Kann ich ✓", "Je sais ✓"],
    pq_cards_done: ["Peržiūrėjai visas {n} korteles. Puikus darbas!", "You went through all {n} cards. Great work!", "Has repasado las {n} tarjetas. ¡Buen trabajo!", "Ты просмотрел все карточки: {n}. Отличная работа!", "Du hast alle {n} Karten durchgesehen. Tolle Arbeit!", "Tu as parcouru les {n} cartes. Beau travail !"],
    pq_rec_guest: ["Atsakymas patikrintas. Svečio režime XP, ženkleliai ir mokymosi taškai nekaupiami.", "Answer checked. In guest mode XP, badges and learning points are not collected.", "Respuesta comprobada. En modo invitado no se acumulan XP, insignias ni puntos.", "Ответ проверен. В гостевом режиме XP, значки и баллы не накапливаются.", "Antwort geprüft. Im Gastmodus werden keine XP, Abzeichen oder Lernpunkte gesammelt.", "Réponse vérifiée. En mode invité, XP, badges et points ne sont pas cumulés."],
    pq_rec_ok: ["Teisingas atsakymas", "Correct answer", "Respuesta correcta", "Правильный ответ", "Richtige Antwort", "Bonne réponse"],
    pq_rec_bad: ["Neteisingas atsakymas", "Wrong answer", "Respuesta incorrecta", "Неправильный ответ", "Falsche Antwort", "Mauvaise réponse"],
    pq_rec_streak: [" · 10 dienų serijos premija: +80 XP!", " · 10-day streak bonus: +80 XP!", " · bonificación de racha de 10 días: +80 XP!", " · бонус за серию в 10 дней: +80 XP!", " · 10-Tage-Serienbonus: +80 XP!", " · bonus de série de 10 jours : +80 XP !"],
    pq_rec_fail: ["Atsakymas išsaugotas, bet XP įrašyti nepavyko: {m}", "Answer saved, but XP could not be recorded: {m}", "Respuesta guardada, pero no se pudo registrar el XP: {m}", "Ответ сохранён, но записать XP не удалось: {m}", "Antwort gespeichert, aber XP konnten nicht erfasst werden: {m}", "Réponse enregistrée, mais les XP n’ont pas pu l’être : {m}"],
  };
  Object.entries(practiceTexts).forEach(([key, values]) => {
    languages.forEach((code, index) => { copy[code][key] = values[index]; });
  });

  const flagShapes = {
    lt: '<rect width="30" height="7" fill="#FDB913"/><rect y="7" width="30" height="6" fill="#006A44"/><rect y="13" width="30" height="7" fill="#C1272D"/>',
    en: '<rect width="30" height="20" fill="#012169"/><path d="M0 0l30 20M30 0L0 20" stroke="#fff" stroke-width="4"/><path d="M0 0l30 20M30 0L0 20" stroke="#C8102E" stroke-width="1.6"/><path d="M15 0v20M0 10h30" stroke="#fff" stroke-width="6"/><path d="M15 0v20M0 10h30" stroke="#C8102E" stroke-width="3.6"/>',
    es: '<rect width="30" height="20" fill="#AA151B"/><rect y="5" width="30" height="10" fill="#F1BF00"/>',
    ru: '<rect width="30" height="7" fill="#fff"/><rect y="7" width="30" height="6" fill="#0039A6"/><rect y="13" width="30" height="7" fill="#D52B1E"/>',
    de: '<rect width="30" height="7" fill="#000"/><rect y="7" width="30" height="6" fill="#DD0000"/><rect y="13" width="30" height="7" fill="#FFCE00"/>',
    fr: '<rect width="10" height="20" fill="#0055A4"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#EF4135"/>',
  };
  const languageNames = { lt: "Lietuvių", en: "English", es: "Español", ru: "Русский", de: "Deutsch", fr: "Français" };
  const flagSvg = (code) => `<svg class="flag-icon" viewBox="0 0 30 20" width="24" height="16" aria-hidden="true" focusable="false">${flagShapes[code]}</svg>`;
  const translate = (key, values = {}) => {
    const text = copy[document.documentElement.lang]?.[key] ?? copy.lt[key] ?? "";
    return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
  };

  function readPreference(key, fallback) {
    try {
      return localStorage.getItem(key) || fallback;
    } catch (error) {
      console.error(`Nepavyko nuskaityti nustatymo ${key}.`, error);
      return fallback;
    }
  }

  function writePreference(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (error) {
      console.error(`Nepavyko išsaugoti nustatymo ${key}.`, error);
      const status = document.querySelector("#profile-preferences-status");
      if (status) {
        status.textContent = "Nepavyko išsaugoti nustatymo. Patikrink naršyklės saugyklos leidimus.";
        status.className = "profile-status error";
      }
      throw error;
    }
  }

  function applyAccessibility() {
    document.documentElement.dataset.largeText = readPreference(accessibilityKeys.largeText, "false");
    document.documentElement.dataset.highContrast = readPreference(accessibilityKeys.highContrast, "false");
    document.documentElement.dataset.reducedMotion = readPreference(accessibilityKeys.reducedMotion, "false");
  }

  function initializeAccessibilitySettings() {
    const controls = [
      ["largeText", "#accessibility-large-text", "false"],
      ["highContrast", "#accessibility-high-contrast", "false"],
      ["reducedMotion", "#accessibility-reduced-motion", "false"],
      ["showExplanations", "#learning-show-explanations", "true"],
    ];
    controls.forEach(([key, selector]) => {
      const control = document.querySelector(selector);
      if (!control) return;
      control.checked = readPreference(accessibilityKeys[key], key === "showExplanations" ? "true" : "false") === "true";
      control.addEventListener("change", () => {
        writePreference(accessibilityKeys[key], String(control.checked));
        applyAccessibility();
        const status = document.querySelector("#profile-preferences-status");
        if (status) {
          status.textContent = translate("accessibility_saved");
          status.className = "profile-status success";
        }
      });
    });
  }

  function applyLanguage(language) {
    const selected = languages.includes(language) ? language : "lt";
    document.documentElement.lang = selected;
    document.querySelectorAll("[data-i18n]").forEach((element) => {
      const value = copy[selected][element.dataset.i18n];
      if (value) element.textContent = value;
    });
    document.querySelectorAll("[data-i18n-aria]").forEach((element) => {
      const value = copy[selected][element.dataset.i18nAria];
      if (value) element.setAttribute("aria-label", value);
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
      const value = copy[selected][element.dataset.i18nPlaceholder];
      if (value) element.placeholder = value;
    });
    document.querySelectorAll("[data-i18n-label]").forEach((element) => {
      const value = copy[selected][element.dataset.i18nLabel];
      if (value) element.label = value;
    });
    const languageSelect = document.querySelector("#profile-language");
    if (languageSelect) languageSelect.value = selected;
    document.querySelectorAll("[data-i18n-html]").forEach((element) => {
      const value = copy[selected][element.dataset.i18nHtml];
      if (value) element.innerHTML = value;
    });
    document.querySelectorAll(".nav-ai-link").forEach((element) => {
      element.textContent = copy[selected].nav_ai;
    });
    document.querySelectorAll(".lang-switcher-button").forEach((button) => {
      button.querySelector(".lang-flag").innerHTML = flagSvg(selected);
      button.querySelector(".lang-code").textContent = selected.toUpperCase();
    });
    document.querySelectorAll("[data-lang-option]").forEach((option) => {
      const active = option.dataset.langOption === selected;
      option.classList.toggle("is-active", active);
      option.setAttribute(option.getAttribute("role") === "option" ? "aria-selected" : "aria-pressed", String(active));
    });
  }

  function setLanguage(code) {
    if (!languages.includes(code)) return;
    writePreference(languageKey, code);
    applyLanguage(code);
    document.dispatchEvent(new CustomEvent("testavimai:language-changed", { detail: code }));
  }

  function languageOptions(role) {
    return languages.map((code) => `<button type="button" class="lang-option" data-lang-option="${code}" role="${role}">${flagSvg(code)}<span>${languageNames[code]}</span></button>`).join("");
  }

  function buildLanguageDropdown(modifier) {
    const root = document.createElement("div");
    root.className = `lang-switcher ${modifier}`;
    root.innerHTML = `<button type="button" class="lang-switcher-button" aria-haspopup="listbox" aria-expanded="false" aria-label="Language"><span class="lang-flag"></span><span class="lang-code"></span><span class="lang-caret" aria-hidden="true">▾</span></button><div class="lang-switcher-menu" role="listbox" hidden>${languageOptions("option")}</div>`;
    const button = root.querySelector(".lang-switcher-button");
    const menu = root.querySelector(".lang-switcher-menu");
    const close = () => {
      menu.hidden = true;
      button.setAttribute("aria-expanded", "false");
    };
    button.addEventListener("click", () => {
      const open = menu.hidden;
      document.querySelectorAll(".lang-switcher-menu").forEach((other) => { other.hidden = true; });
      menu.hidden = !open;
      button.setAttribute("aria-expanded", String(open));
    });
    menu.addEventListener("click", (event) => {
      const option = event.target.closest("[data-lang-option]");
      if (!option) return;
      setLanguage(option.dataset.langOption);
      close();
    });
    document.addEventListener("click", (event) => { if (!root.contains(event.target)) close(); });
    document.addEventListener("keydown", (event) => { if (event.key === "Escape") close(); });
    return root;
  }

  function buildLanguageGrid() {
    const grid = document.createElement("div");
    grid.className = "lang-grid";
    grid.setAttribute("role", "group");
    grid.innerHTML = languageOptions("button");
    grid.addEventListener("click", (event) => {
      const option = event.target.closest("[data-lang-option]");
      if (option) setLanguage(option.dataset.langOption);
    });
    return grid;
  }

  function mountLanguageSwitchers() {
    if (document.body.dataset.page === "auth") {
      document.querySelector(".auth-header")?.append(buildLanguageDropdown("lang-switcher--auth"));
    }
    const select = document.querySelector("#profile-language");
    if (select) {
      select.hidden = true;
      select.after(buildLanguageGrid());
    }
  }

  function initEffects() {
    const header = document.querySelector(".site-header");
    if (header) {
      const update = () => header.classList.toggle("is-scrolled", window.scrollY > 8);
      window.addEventListener("scroll", update, { passive: true });
      update();
    }
    const revealElements = [...document.querySelectorAll(".subject-card, .step, .practice-mode-card, .practice-tool-panel, .profile-info-card, .leaderboard-card, .public-profile-card, .auth-card")];
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches || document.hidden) {
      revealElements.forEach((element) => element.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.08, rootMargin: "0px 0px -6% 0px" });
    const revealWhenHidden = () => {
      if (!document.hidden) return;
      revealElements.forEach((element) => element.classList.add("is-visible"));
      observer.disconnect();
      document.removeEventListener("visibilitychange", revealWhenHidden);
    };
    document.addEventListener("visibilitychange", revealWhenHidden);
    revealElements.forEach((element, index) => {
      element.classList.add("reveal");
      element.style.setProperty("--reveal-delay", `${Math.min(index % 6, 5) * 70}ms`);
      observer.observe(element);
    });
  }

  window.testavimai = {
    t: translate,
    setLanguage,
    refresh: () => applyLanguage(document.documentElement.lang || "lt"),
    showExplanations: () => readPreference(accessibilityKeys.showExplanations, "true") !== "false",
  };

  function applyTheme(theme, animate = false) {
    const selected = guestMode ? "forest" : Object.hasOwn(themes, theme) ? theme : "forest";
    const update = () => {
      document.documentElement.dataset.theme = selected;
      const themeColor = document.querySelector('meta[name="theme-color"]');
      if (themeColor) themeColor.content = themes[selected][3];
      document.querySelectorAll("[data-theme-option]").forEach((button) => {
        const active = button.dataset.themeOption === selected;
        button.classList.toggle("is-selected", active);
        button.setAttribute("aria-pressed", String(active));
        if (guestMode) button.disabled = !active;
      });
      document.dispatchEvent(new CustomEvent("testavimai:theme-applied", { detail: selected }));
    };
    if (animate && document.startViewTransition && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      document.startViewTransition(update);
    } else {
      update();
    }
  }

  function persistGuestTheme() {
    try {
      writePreference(themeKey, "forest");
    } catch (error) {
      console.error("Svečio numatytosios temos išsaugoti nepavyko.", error);
    }
  }

  async function updatePremiumThemeAccess() {
    const premiumButtons = [...document.querySelectorAll("[data-theme-option]")].filter((button) => isPremiumTheme(button.dataset.themeOption));
    if (premiumButtons.length === 0) return;
    try {
      const { getMyProgress } = await import("./progress.js");
      const progress = await getMyProgress();
      const unlocked = new Set(progress.owned_themes || []);
      premiumButtons.forEach((button) => {
        const available = Boolean(progress.is_premium || unlocked.has(button.dataset.themeOption));
        button.classList.toggle("is-locked", !available);
        button.setAttribute("aria-label", `${button.querySelector(".theme-name").textContent}${available ? "" : " — reikia Premium arba atrakinti už taškus"}`);
        let lock = button.querySelector(".theme-lock");
        if (!available && !lock) {
          lock = document.createElement("span");
          lock.className = "theme-lock";
          lock.textContent = "Užrakinta";
          button.append(lock);
        } else if (available) {
          lock?.remove();
        }
      });
    } catch (error) {
      console.error("Nepavyko patikrinti Premium temų prieigos.", error);
      const status = document.querySelector("#profile-preferences-status");
      if (status) {
        status.textContent = `Premium temų prieigos patikrinti nepavyko: ${error.message}`;
        status.className = "profile-status error";
      }
    }
  }

  const language = readPreference(languageKey, "lt");
  const theme = guestMode ? "forest" : readPreference(themeKey, "forest");
  if (guestMode) persistGuestTheme();
  applyLanguage(language);
  applyTheme(theme);
  applyAccessibility();

  document.addEventListener("DOMContentLoaded", () => {
    applyLanguage(language);
    applyTheme(theme);
    mountLanguageSwitchers();
    applyLanguage(readPreference(languageKey, "lt"));
    initializeAccessibilitySettings();
    initEffects();
    initializeLocalReminder();
    updatePremiumThemeAccess();
    document.addEventListener("testavimai:owned-themes", updatePremiumThemeAccess);
    window.addEventListener("storage", (event) => {
      if (event.key !== themeKey) return;
      if (guestMode) {
        persistGuestTheme();
        applyTheme("forest");
        return;
      }
      if (!event.newValue || !Object.hasOwn(themes, event.newValue)) return;
      applyTheme(event.newValue);
    });
    document.addEventListener("testavimai:select-theme", (event) => {
      const selectedTheme = event.detail;
      if (!Object.hasOwn(themes, selectedTheme)) return;
      if (guestMode && selectedTheme !== "forest") {
        persistGuestTheme();
        applyTheme("forest");
        return;
      }
      writePreference(themeKey, selectedTheme);
      applyTheme(selectedTheme, true);
    });
    if (isPremiumTheme(theme)) {
      import("./progress.js")
        .then(({ getMyProgress }) => getMyProgress())
        .then((progress) => {
          if (progress.is_premium || (progress.owned_themes || []).includes(theme)) return;
          writePreference(themeKey, "forest");
          applyTheme("forest");
        })
        .catch((error) => {
          console.error("Nepavyko patikrinti Premium temos prieigos.", error);
          const status = document.querySelector("#profile-preferences-status");
          if (status) {
            status.textContent = `Nepavyko patikrinti Premium prieigos. Palikome išsaugotą temą nepakeistą: ${error.message}`;
            status.className = "profile-status error";
          }
        });
    }
    document.querySelector("#profile-language")?.addEventListener("change", (event) => {
      setLanguage(event.target.value);
    });
    document.querySelectorAll("[data-theme-option]").forEach((button) => {
      button.addEventListener("click", async () => {
        const selectedTheme = button.dataset.themeOption;
        if (guestMode && selectedTheme !== "forest") {
          const status = document.querySelector("#profile-preferences-status");
          if (status) {
            status.textContent = "Svečio režime galima naudoti tik numatytąją temą.";
            status.className = "profile-status error";
          }
          persistGuestTheme();
          applyTheme("forest");
          return;
        }
        if (isPremiumTheme(selectedTheme)) {
          const status = document.querySelector("#profile-preferences-status");
          try {
            const { getMyProgress } = await import("./progress.js");
            const progress = await getMyProgress();
            const owned = progress.owned_themes || [];
            if (!progress.is_premium && !owned.includes(selectedTheme)) {
              if (status) {
                status.textContent = copy[document.documentElement.lang].premium_locked;
                status.className = "profile-status error";
              }
              return;
            }
          } catch (error) {
            console.error("Nepavyko patikrinti Premium temos prieigos.", error);
            if (status) {
              status.textContent = `Nepavyko patikrinti temos prieigos: ${error.message}`;
              status.className = "profile-status error";
            }
            return;
          }
        }
        writePreference(themeKey, selectedTheme);
        applyTheme(selectedTheme, true);
        const status = document.querySelector("#profile-preferences-status");
        if (status) {
          status.textContent = `Tema „${button.querySelector(".theme-name").textContent}“ pritaikyta ir išsaugota šioje naršyklėje.`;
          status.className = "profile-status success";
        }
      });
    });
  });

  function isPremiumTheme(theme) {
    return ["nocturne", "aurum", "velvet", "sapphire", "obsidian", "amethyst", "emerald", "crimson", "arctic", "rose_noir", "lavender", "peach", "lagoon", "blossom", "sky", "buttercream", "mint", "pearl", "rosewater", "lemon"].includes(theme);
  }

  function initializeLocalReminder() {
    const enabledKey = "testavimai-reminders-enabled";
    const timeKey = "testavimai-reminder-time";
    const sentKey = "testavimai-reminders-last-sent";
    const checkReminder = () => {
      if (localStorage.getItem(enabledKey) !== "true" || !("Notification" in window) || Notification.permission !== "granted") return;
      const time = localStorage.getItem(timeKey) || "18:00";
      if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)) return;
      const now = new Date();
      const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
      const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      if (currentTime < time || localStorage.getItem(sentKey) === today) return;
      new Notification("Testavimai", { body: "Laikas trumpai pasimokyti. Atverk savaitės planą ir pasirink mažą tikslą." });
      localStorage.setItem(sentKey, today);
    };
    const safelyCheckReminder = () => {
      try {
        checkReminder();
      } catch (error) {
        console.error("Vietinio mokymosi priminimo parodyti nepavyko.", error);
      }
    };
    safelyCheckReminder();
    window.setInterval(safelyCheckReminder, 30_000);
    document.addEventListener("visibilitychange", safelyCheckReminder);
  }
})();
