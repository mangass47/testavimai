const roleKey = "testavimai-account-type";
const t = (key) => window.testavimai?.t?.(key) ?? key;

const teacherLinks = [
  { href: "uzduotys.html#teacher-classroom-panel", icon: "▦", key: "tm_nav_results", descKey: "tm_card_class_p" },
  { href: "uzduotys.html#available-tasks-title", icon: "↙", key: "tm_nav_inbox", descKey: "tm_card_inbox_p" },
  { href: "uzduotys.html#create-task-title", icon: "✎", key: "tm_nav_create", descKey: "tm_card_create_p" },
  { href: "praktika.html?veikla=ai", icon: "✦", key: "tm_nav_tutor", descKey: "tm_card_tutor_p" },
  { href: "pamokos.html#pamokos", icon: "▤", key: "tm_nav_materials", descKey: "tm_card_materials_p" },
  { href: "profilis.html#profile-subscriptions", icon: "◆", key: "tm_nav_tools", descKey: "tm_card_tools_p" },
];

const hiddenForTeachers = {
  "praktika.html": [".practice-hub-hero", ".practice-progress-card", ".practice-mode-grid", "#atsiskaitymui", "#entrance-test-panel", "#rewards", "#achievements", "#practice-session", "#tips", "#weekly-plan"],
  "pamokos.html": [".lesson-card-bottom", "#praktika"],
  "profilis.html": [".profile-community-stats", "#profile-badges", ".profile-leaderboard-link", "label:has(select[name=\"grade\"])", "label:has(#profile-featured-badge)"],
  "uzduotys.html": ["section[aria-labelledby=\"invitations-title\"]"],
};

const pageName = () => window.location.pathname.split("/").pop() || "index.html";

function applyRole(role) {
  document.documentElement.dataset.role = role;
  if (role !== "teacher") return;
  if (pageName() === "index.html") {
    window.location.replace("praktika.html");
    return;
  }
  if (pageName() === "testas.html") {
    window.location.replace("praktika.html?veikla=ai");
    return;
  }

  const style = document.createElement("style");
  const selectors = hiddenForTeachers[pageName()] || [];
  style.textContent = selectors.map((selector) => `html[data-role="teacher"] ${selector}`).join(",\n") + (selectors.length ? " { display: none !important; }" : "");
  document.head.append(style);

  const nav = document.querySelector(".main-nav");
  if (nav) {
    nav.replaceChildren(...teacherLinks.slice(0, 5).map((link) => {
      const anchor = document.createElement("a");
      anchor.className = "nav-link";
      anchor.href = link.href;
      anchor.dataset.i18n = link.key;
      return anchor;
    }));
  }

  const drawer = document.querySelector(".site-drawer-links");
  if (drawer) {
    const settings = { href: "profilis.html#profile-preferences", icon: "⚙", key: "tm_nav_settings", descKey: "menu_settings_desc" };
    drawer.replaceChildren(...[...teacherLinks, settings].map((link) => {
      const anchor = document.createElement("a");
      anchor.href = link.href;
      anchor.innerHTML = '<span class="drawer-link-icon"></span><span><strong></strong><small></small></span><span class="drawer-link-arrow">→</span>';
      anchor.querySelector(".drawer-link-icon").textContent = link.icon;
      anchor.querySelector("strong").dataset.i18n = link.key;
      anchor.querySelector("small").dataset.i18n = link.descKey;
      return anchor;
    }));
  }

  if (pageName() === "praktika.html") injectDashboard();
  if (pageName() === "uzduotys.html") {
    const inboxTitle = document.querySelector("#available-tasks-title");
    const inboxDescription = inboxTitle?.parentElement?.querySelector("p");
    if (inboxTitle) inboxTitle.textContent = t("tm_nav_inbox");
    if (inboxDescription) inboxDescription.textContent = t("tm_card_inbox_p");
  }
  if (pageName() === "profilis.html") {
    const eyebrow = document.querySelector(".profile-shell .eyebrow");
    if (eyebrow) eyebrow.replaceChildren(Object.assign(document.createElement("span"), { textContent: "✳ " }), Object.assign(document.createElement("span"), { textContent: "" }));
    if (eyebrow) eyebrow.lastChild.dataset.i18n = "tm_profile_eyebrow";
    injectProfileActions();
  }
  window.testavimai?.refresh?.();
}

function injectDashboard() {
  const study = document.querySelector("#study-buddy");
  if (!study) return;
  const section = document.createElement("section");
  section.className = "teacher-dashboard";
  const head = document.createElement("div");
  head.className = "teacher-dashboard-head";
  head.innerHTML = '<span class="eyebrow"></span><h1></h1><p></p>';
  head.querySelector(".eyebrow").dataset.i18n = "tm_dash_eyebrow";
  head.querySelector("h1").dataset.i18n = "tm_dash_h1";
  head.querySelector("p").dataset.i18n = "tm_dash_p";
  const grid = document.createElement("div");
  grid.className = "teacher-dashboard-grid";
  teacherLinks.filter((link) => link.key !== "tm_nav_tutor").forEach((link) => {
    const card = document.createElement("a");
    card.className = "teacher-dashboard-card";
    card.href = link.href;
    card.innerHTML = '<span class="teacher-dashboard-icon"></span><strong></strong><small></small>';
    card.querySelector(".teacher-dashboard-icon").textContent = link.icon;
    card.querySelector("strong").dataset.i18n = link.key;
    card.querySelector("small").dataset.i18n = link.descKey;
    grid.append(card);
  });
  section.append(head, grid);
  study.before(section);
}

function injectProfileActions() {
  const heading = document.querySelector("#profile-heading");
  if (!heading) return;
  const row = document.createElement("div");
  row.className = "teacher-dashboard-grid teacher-profile-actions";
  teacherLinks.filter((link) => link.key !== "tm_nav_materials").forEach((link) => {
    const card = document.createElement("a");
    card.className = "teacher-dashboard-card";
    card.href = link.href;
    card.innerHTML = '<span class="teacher-dashboard-icon"></span><strong></strong>';
    card.querySelector(".teacher-dashboard-icon").textContent = link.icon;
    card.querySelector("strong").dataset.i18n = link.key;
    row.append(card);
  });
  heading.after(row);
}

async function detectRole() {
  const cached = localStorage.getItem(roleKey);
  if (cached) applyRole(cached);
  try {
    const { getMyProgress } = await import("./progress.js");
    const progress = await getMyProgress();
    const role = ["teacher", "student", "school_admin"].includes(progress?.account_type) ? progress.account_type : "";
    if (role) localStorage.setItem(roleKey, role);
    else localStorage.removeItem(roleKey);
    if (role && cached && cached !== role) window.location.reload();
    else if (role && !cached) applyRole(role);
    else if (!role && cached) window.location.reload();
  } catch (error) {
    console.warn("Nepavyko nustatyti paskyros tipo.", error);
  }
}

detectRole();
