export const SUPABASE_URL = "https://gqofuqzcdubufgcygcoo.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_K7co-ejlxGDRIFWyL2_5IQ_SLxAuB6E";
