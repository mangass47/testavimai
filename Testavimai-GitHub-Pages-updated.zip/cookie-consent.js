(() => {
  const consentKey = "testavimai-cookie-consent";
  const policyVersion = "2026-10-28";
  let savedConsent;
  try {
    savedConsent = JSON.parse(localStorage.getItem(consentKey) || "null");
  } catch (error) {
    console.error("Slapukų pasirinkimo nuskaityti nepavyko.", error);
  }

  const banner = document.createElement("section");
  banner.className = "cookie-consent-banner";
  banner.setAttribute("aria-label", "Slapukų ir vietinės saugyklos nustatymai");
  banner.hidden = savedConsent?.version === policyVersion;
  banner.innerHTML = `
    <div class="cookie-consent-copy">
      <h2>Privatumas ir slapukai</h2>
      <p>Būtini prisijungimo ir svetainės nuostatų saugojimo elementai veikia visada. Analitinių ar reklaminių slapukų šiuo metu nenaudojame. Gali pasirinkimą pakeisti Privatumo ir slapukų politikoje.</p>
    </div>
    <div class="cookie-consent-actions">
      <button type="button" data-cookie-choice="necessary">Tik būtini</button>
      <button type="button" data-cookie-choice="all">Sutikti</button>
      <a href="privacy-policy.html#cookies">Apie slapukus</a>
    </div>
  `;
  document.body.append(banner);
  banner.querySelectorAll("[data-cookie-choice]").forEach((button) => {
    button.addEventListener("click", () => {
      try {
        localStorage.setItem(consentKey, JSON.stringify({
          version: policyVersion,
          necessary: true,
          analytics: button.dataset.cookieChoice === "all",
          saved_at: new Date().toISOString(),
        }));
        banner.hidden = true;
      } catch (error) {
        console.error("Slapukų pasirinkimo išsaugoti nepavyko.", error);
        const message = document.createElement("p");
        message.textContent = "Pasirinkimo išsaugoti nepavyko. Patikrink naršyklės saugyklos leidimus.";
        banner.append(message);
      }
    });
  });

  document.querySelectorAll("[data-cookie-settings]").forEach((button) => {
    button.addEventListener("click", () => { banner.hidden = false; });
  });
  document.addEventListener("testavimai:cookie-settings", () => { banner.hidden = false; });
})();
