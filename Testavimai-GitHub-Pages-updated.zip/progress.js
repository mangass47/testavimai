import { SUPABASE_ANON_KEY, SUPABASE_URL } from "./supabase-config.js";

const guestKey = "testavimai-demo-guest";
const guestProgressKey = "testavimai-demo-progress";
const guestDailyKey = "testavimai-demo-daily";
const ownedThemesKey = "testavimai-owned-themes";
const freeDailyLimit = 15;
const rewards = {
  theme_nocturne: { cost: 100, theme: "nocturne" },
  theme_aurum: { cost: 100, theme: "aurum" },
  theme_velvet: { cost: 100, theme: "velvet" },
  theme_sapphire: { cost: 100, theme: "sapphire" },
  theme_obsidian: { cost: 100, theme: "obsidian" },
  theme_amethyst: { cost: 100, theme: "amethyst" },
  theme_emerald: { cost: 100, theme: "emerald" },
  theme_crimson: { cost: 100, theme: "crimson" },
  theme_arctic: { cost: 100, theme: "arctic" },
  theme_rose_noir: { cost: 100, theme: "rose_noir" },
  theme_lavender: { cost: 100, theme: "lavender" },
  theme_peach: { cost: 100, theme: "peach" },
  theme_lagoon: { cost: 100, theme: "lagoon" },
  theme_blossom: { cost: 100, theme: "blossom" },
  theme_sky: { cost: 100, theme: "sky" },
  theme_buttercream: { cost: 100, theme: "buttercream" },
  theme_mint: { cost: 100, theme: "mint" },
  premium_30_days: { cost: 10000, days: 30 },
};
const learningCaseRewards = [
  { theme: "lavender", rarity: "common" },
  { theme: "peach", rarity: "common" },
  { theme: "lagoon", rarity: "common" },
  { theme: "blossom", rarity: "rare" },
  { theme: "sky", rarity: "rare" },
  { theme: "buttercream", rarity: "epic" },
  { theme: "mint", rarity: "epic" },
  { theme: "sapphire", rarity: "epic" },
  { theme: "amethyst", rarity: "legendary" },
  { theme: "emerald", rarity: "legendary" },
  { theme: "arctic", rarity: "legendary" },
  { theme: "rose_noir", rarity: "legendary" },
];
const learningCaseCost = 250;
const learningCaseTierWeights = { common: 60, rare: 28, epic: 11, legendary: 1 };
const learningCaseFixedPrizes = [
  { prize_id: "coins_50", kind: "coins", amount: 50, rarity: "rare", name: "50 taškų", icon: "◇" },
  { prize_id: "coins_100", kind: "coins", amount: 100, rarity: "epic", name: "100 taškų", icon: "◆" },
  { prize_id: "premium_7d", kind: "premium", days: 7, rarity: "epic", name: "Premium · 7 dienos", icon: "★" },
  { prize_id: "coins_250", kind: "coins", amount: 250, rarity: "legendary", name: "250 taškų", icon: "✦" },
  { prize_id: "premium_20d", kind: "premium", days: 20, rarity: "legendary", name: "Premium · 20 dienų", icon: "★" },
];
const localDemoMode = ["localhost", "testavimai.localhost", "testavimai.com", "www.testavimai.com", "127.0.0.1", "[::1]"].includes(window.location.hostname);
let clientPromise;

export const learningCaseOpeningCost = learningCaseCost;

export function getLearningCaseOdds(ownedThemes = [], { includePremium = true } = {}) {
  const owned = new Set(Array.isArray(ownedThemes) ? ownedThemes : []);
  const pool = [
    ...learningCaseFixedPrizes.filter((prize) => includePremium || prize.kind !== "premium"),
    ...learningCaseRewards
      .filter((reward) => !owned.has(reward.theme))
      .map((reward) => ({
        prize_id: `theme_${reward.theme}`,
        kind: "theme",
        theme_id: reward.theme,
        rarity: reward.rarity,
      })),
  ];
  const tierCounts = pool.reduce((counts, prize) => ({ ...counts, [prize.rarity]: (counts[prize.rarity] || 0) + 1 }), {});
  const weighted = pool.map((prize) => ({ ...prize, weight: learningCaseTierWeights[prize.rarity] / tierCounts[prize.rarity] }));
  const totalWeight = weighted.reduce((total, prize) => total + prize.weight, 0);
  return { standard: weighted.map((prize) => ({ ...prize, chance: (prize.weight / totalWeight) * 100 })) };
}

function isGuestMode() {
  return sessionStorage.getItem(guestKey) === "true";
}

async function getClient() {
  if (isGuestMode()) return null;
  if (SUPABASE_URL.includes("YOUR-PROJECT") || SUPABASE_ANON_KEY.includes("YOUR_SUPABASE")) {
    if (localDemoMode) return null;
    throw new Error("Prisijungimas prie bendros pažangos dar nesukonfigūruotas.");
  }
  if (!clientPromise) {
    clientPromise = import("https://esm.sh/@supabase/supabase-js@2")
      .then(({ createClient }) => createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true },
      }));
  }
  return clientPromise;
}

function localStats() {
  try {
    return JSON.parse(localStorage.getItem(guestProgressKey) || "{}");
  } catch (error) {
    console.error("Nepavyko nuskaityti vietinės mokymosi pažangos.", error);
    return {};
  }
}

function saveLocalStats(stats) {
  try {
    localStorage.setItem(guestProgressKey, JSON.stringify(stats));
  } catch (error) {
    console.error("Nepavyko išsaugoti vietinės mokymosi pažangos.", error);
    throw new Error("Pažangos išsaugoti nepavyko. Patikrink naršyklės saugyklos leidimus.");
  }
}

async function isCorrectPracticeAnswer(questionId, answerIndex) {
  const { practiceQuestions } = await import("./praktika-question-data.js");
  const practiceQuestion = practiceQuestions.find((item) => item.id === questionId);
  if (practiceQuestion) return answerIndex === practiceQuestion.correct;
  if (questionId.startsWith("worksheet-")) {
    const subjectAndIndex = questionId.slice("worksheet-".length);
    const separator = subjectAndIndex.lastIndexOf("-");
    const subject = subjectAndIndex.slice(0, separator);
    const questionIndex = Number(subjectAndIndex.slice(separator + 1));
    const { worksheetCorrectAnswers } = await import("./worksheet-answer-data.js");
    const correctAnswer = worksheetCorrectAnswers[subject]?.[questionIndex];
    if (correctAnswer !== undefined) return answerIndex === correctAnswer;
  }
  throw new Error("Praktikos klausimas nerastas.");
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function readLocalDaily() {
  try {
    const value = JSON.parse(localStorage.getItem(guestDailyKey) || "{}");
    return value.date === todayKey() ? value : { date: todayKey(), questions: 0, images: 0 };
  } catch (error) {
    console.error("Nepavyko nuskaityti dienos limitų.", error);
    return { date: todayKey(), questions: 0, images: 0 };
  }
}

function achievementsFor(stats) {
  const answers = Number(stats.total_questions || 0);
  const correct = Number(stats.total_correct || 0);
  const xp = Number(stats.lifetime_xp || 0);
  const streak = Number(stats.best_streak || 0);
  const streakMilestones = [1, 5, 10, 25, 50, 100, 250, 500, 1000];
  const xpMilestones = [100, 500, 1000, 2500];
  return [
    ["first-answer", "Pirmas žingsnis", "Atsakyk į pirmą klausimą.", "✦", answers >= 1],
    ["first-correct", "Pataikei!", "Teisingai atsakyk į pirmą klausimą.", "✓", correct >= 1],
    ["five-correct", "Penki iš eilės", "Atsakyk teisingai į 5 klausimus.", "⚡", correct >= 5],
    ["ten-correct", "Dešimtukas", "Atsakyk teisingai į 10 klausimų.", "✧", correct >= 10],
    ["twenty-five-correct", "Žinių kibirkštis", "Atsakyk teisingai į 25 klausimus.", "✺", correct >= 25],
    ["fifty-correct", "Žinių žvaigždė", "Atsakyk teisingai į 50 klausimų.", "★", correct >= 50],
    ["hundred-correct", "Šimtukas", "Atsakyk teisingai į 100 klausimų.", "🏅", correct >= 100],
    ["two-hundred-fifty-correct", "Tikras žinovas", "Atsakyk teisingai į 250 klausimų.", "♛", correct >= 250],
    ["five-hundred-correct", "Ekspertas", "Atsakyk teisingai į 500 klausimų.", "◆", correct >= 500],
    ["thousand-correct", "Neprilygstamas", "Atsakyk teisingai į 1 000 klausimų.", "♛", correct >= 1000],
    ["ten-answers", "Pradžia padaryta", "Atsakyk į 10 klausimų.", "◉", answers >= 10],
    ["fifty-answers", "Įsibėgėji", "Atsakyk į 50 klausimų.", "➶", answers >= 50],
    ["hundred-answers", "Šimtas klausimų", "Atsakyk į 100 klausimų.", "◎", answers >= 100],
    ["two-hundred-fifty-answers", "Atkaklus mokinys", "Atsakyk į 250 klausimų.", "✧", answers >= 250],
    ["five-hundred-answers", "Nuoseklus mokinys", "Atsakyk į 500 klausimų.", "⌘", answers >= 500],
    ["thousand-answers", "Mokymosi maratonininkas", "Atsakyk į 1 000 klausimų.", "⌁", answers >= 1000],
    ["two-thousand-answers", "Mokymosi legenda", "Atsakyk į 2 000 klausimų.", "♜", answers >= 2000],
    ...streakMilestones.map((value) => [`streak-${value}`, `${value} d. serija`, `Pasiek ${value} dienų geriausią seriją.`, "☼", streak >= value]),
    ...xpMilestones.map((value) => [`xp-${value}`, `${value} XP`, `Uždirbk ${value} XP per mokymąsi.`, "✦", xp >= value]),
  ].map(([id, title, description, icon, earned]) => ({ id, title, description, icon, earned }));
}

function setOwnedThemes(themes) {
  const premiumThemes = ["nocturne", "aurum", "velvet", "sapphire", "obsidian", "amethyst", "emerald", "crimson", "arctic", "rose_noir", "lavender", "peach", "lagoon", "blossom", "sky", "buttercream", "mint"];
  const validThemes = [...new Set(themes.filter((theme) => premiumThemes.includes(theme)))];
  try {
    localStorage.setItem(ownedThemesKey, JSON.stringify(validThemes));
    document.dispatchEvent(new CustomEvent("testavimai:owned-themes", { detail: validThemes }));
  } catch (error) {
    console.error("Nepavyko išsaugoti atrakintų temų.", error);
  }
}

function updateLocalProgress(isCorrect) {
  const daily = readLocalDaily();
  if (daily.questions >= freeDailyLimit) {
    throw new Error("Pasiekei šios dienos 15 klausimų limitą. Premium nariams dienos klausimų skaičius neribojamas.");
  }
  if (isGuestMode()) {
    daily.questions += 1;
    localStorage.setItem(guestDailyKey, JSON.stringify(daily));
    return {
      xp: 0,
      lifetime_xp: 0,
      reward_coins: 0,
      current_streak: 0,
      correct_today: 0,
      is_correct: isCorrect,
      points_delta: 0,
      streak_bonus: 0,
      daily_questions_used: daily.questions,
      daily_questions_remaining: Math.max(0, freeDailyLimit - daily.questions),
      daily_images_used: daily.images,
      daily_images_remaining: Math.max(0, 5 - daily.images),
      is_premium: false,
      is_guest: true,
      achievements: [],
      owned_themes: [],
      local_only: true,
    };
  }
  const stats = localStats();
  const previousXp = Number(stats.xp || 0);
  const previousLifetimeXp = Number(stats.lifetime_xp || 0);
  const today = new Date().toISOString().slice(0, 10);
  const previousDay = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const sameDay = stats.activityDate === today;
  const correctToday = sameDay ? Number(stats.correctToday || 0) : 0;
  let currentStreak = Number(stats.currentStreak || 0);
  let streakBonus = 0;

  if (isCorrect) {
    const nextCorrectCount = correctToday + 1;
    if (nextCorrectCount >= 5 && stats.streakDate !== today) {
      currentStreak = stats.streakDate === previousDay ? currentStreak + 1 : 1;
      stats.streakDate = today;
      if (currentStreak % 10 === 0) streakBonus = 80;
    }
    stats.correctToday = nextCorrectCount;
  } else {
    stats.correctToday = correctToday;
  }

  stats.activityDate = today;
  stats.currentStreak = currentStreak;
  stats.bestStreak = Math.max(Number(stats.bestStreak || 0), currentStreak);
  const positiveXp = (isCorrect ? 20 : 0) + streakBonus;
  stats.lifetime_xp = previousLifetimeXp + positiveXp;
  stats.xp = Math.max(0, previousXp + (isCorrect ? 20 : -10) + streakBonus);
  stats.total_questions = Number(stats.total_questions || 0) + 1;
  if (isCorrect) stats.total_correct = Number(stats.total_correct || 0) + 1;
  stats.reward_coins = Number(stats.reward_coins || 0)
    + Math.floor(stats.lifetime_xp / 100) * 10 - Math.floor(previousLifetimeXp / 100) * 10;
  daily.questions += 1;
  localStorage.setItem(guestDailyKey, JSON.stringify(daily));
  saveLocalStats(stats);
  return {
    ...stats,
    current_streak: currentStreak,
    correct_today: stats.correctToday,
    is_correct: isCorrect,
    points_delta: stats.xp - previousXp,
    streak_bonus: streakBonus,
    daily_questions_used: daily.questions,
    daily_questions_remaining: Math.max(0, freeDailyLimit - daily.questions),
    is_premium: false,
    achievements: achievementsFor(stats),
    local_only: true,
  };
}

export async function recordPracticeAnswer(questionId, answerIndex) {
  if (sessionStorage.getItem(guestKey) === "true") {
    return updateLocalProgress(await isCorrectPracticeAnswer(questionId, answerIndex));
  }

  const client = await getClient();
  if (!client) {
    return updateLocalProgress(await isCorrectPracticeAnswer(questionId, answerIndex));
  }

  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) {
    return updateLocalProgress(await isCorrectPracticeAnswer(questionId, answerIndex));
  }

  const { data, error } = await client.rpc("record_practice_answer", {
    p_question_id: questionId,
    p_answer_index: answerIndex,
  });
  if (error) throw error;
  return data;
}

export async function recordPracticeAnswers(questionIds, answerIndices) {
  if (questionIds.length !== answerIndices.length || questionIds.length === 0) {
    throw new Error("Atsakymų sąrašas netinkamas.");
  }
  const client = await getClient();
  if (!client) {
    const outcomes = [];
    for (const [index, questionId] of questionIds.entries()) {
      if (readLocalDaily().questions >= freeDailyLimit) break;
      outcomes.push(await recordPracticeAnswer(questionId, answerIndices[index]));
    }
    return { answers: outcomes, progress: isGuestMode() ? await getMyProgress() : localStats(), unprocessed_answers: questionIds.length - outcomes.length };
  }
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) {
    const outcomes = [];
    for (const [index, questionId] of questionIds.entries()) {
      if (readLocalDaily().questions >= freeDailyLimit) break;
      outcomes.push(await recordPracticeAnswer(questionId, answerIndices[index]));
    }
    return { answers: outcomes, progress: isGuestMode() ? await getMyProgress() : localStats(), unprocessed_answers: questionIds.length - outcomes.length };
  }
  const { data, error } = await client.rpc("record_practice_answers", {
    p_question_ids: questionIds,
    p_answer_indices: answerIndices,
  });
  if (error) throw error;
  return data;
}

export async function getMyProgress() {
  if (isGuestMode()) {
    const daily = readLocalDaily();
    return {
      xp: 0,
      lifetime_xp: 0,
      reward_coins: 0,
      current_streak: 0,
      correct_today: 0,
      daily_questions_used: daily.questions,
      daily_questions_remaining: Math.max(0, freeDailyLimit - daily.questions),
      daily_images_used: daily.images,
      daily_images_remaining: Math.max(0, 5 - daily.images),
      is_premium: false,
      is_guest: true,
      achievements: [],
      owned_themes: [],
      local_only: true,
    };
  }
  const client = await getClient();
  if (!client) {
    const daily = readLocalDaily();
    const stats = localStats();
    return {
      ...stats,
      daily_questions_used: daily.questions,
      daily_questions_remaining: Math.max(0, freeDailyLimit - daily.questions),
      daily_images_used: daily.images,
      daily_images_remaining: Math.max(0, 5 - daily.images),
      is_premium: false,
      achievements: achievementsFor(stats),
      owned_themes: JSON.parse(localStorage.getItem(ownedThemesKey) || "[]"),
      local_only: true,
    };
  }
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) {
    const daily = readLocalDaily();
    const stats = localStats();
    return {
      ...stats,
      daily_questions_used: daily.questions,
      daily_questions_remaining: Math.max(0, freeDailyLimit - daily.questions),
      daily_images_used: daily.images,
      daily_images_remaining: Math.max(0, 5 - daily.images),
      is_premium: false,
      achievements: achievementsFor(stats),
      owned_themes: JSON.parse(localStorage.getItem(ownedThemesKey) || "[]"),
      local_only: true,
    };
  }
  const { error: ensureError } = await client.rpc("ensure_my_public_profile");
  if (ensureError) throw ensureError;
  const { data, error } = await client.rpc("get_my_progress");
  if (error) throw error;
  setOwnedThemes(data.owned_themes || []);
  return data;
}

export async function redeemReward(rewardId) {
  if (isGuestMode()) throw new Error("Svečiai negali naudotis atlygiais. Prisijunk prie paskyros, kad kauptum pažangą.");
  if (!Object.hasOwn(rewards, rewardId)) throw new Error("Šis atlygis nerastas.");
  const client = await getClient();
  if (!client) {
    const reward = rewards[rewardId];
    const stats = localStats();
    const coins = Number(stats.reward_coins || 0);
    if (coins < reward.cost) throw new Error("Šiam atlygiui dar nepakanka mokymosi taškų.");
    if (reward.theme) {
      const owned = JSON.parse(localStorage.getItem(ownedThemesKey) || "[]");
      if (owned.includes(reward.theme)) throw new Error("Šią temą jau turi.");
      stats.reward_coins = coins - reward.cost;
      saveLocalStats(stats);
      setOwnedThemes([...owned, reward.theme]);
      return { reward_coins: stats.reward_coins, owned_themes: [...owned, reward.theme] };
    }
    throw new Error("Premium laiką gali atrakinti tik prisijungęs naudotojas.");
  }
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) throw new Error("Prisijunk prie paskyros, kad išsaugotum atlygį.");
  const { data, error } = await client.rpc("redeem_learning_reward", { p_reward_id: rewardId });
  if (error) throw error;
  setOwnedThemes(data.owned_themes || []);
  return data;
}

export async function openLearningCase(caseId) {
  if (isGuestMode()) throw new Error("Svečiai negali atidaryti mokymosi dėžučių. Prisijunk prie paskyros.");
  const cost = learningCaseCost;
  if (caseId !== "standard") throw new Error("Ši mokymosi dėžutė nerasta.");
  const client = await getClient();
  if (!client) {
    const stats = localStats();
    const coins = Number(stats.reward_coins || 0);
    if (coins < cost) throw new Error(`Dėžutei reikia ${cost} taškų.`);
    const owned = JSON.parse(localStorage.getItem(ownedThemesKey) || "[]");
    const prizes = getLearningCaseOdds(owned, { includePremium: false }).standard;
    let roll = Math.random() * 100;
    const selectedPrize = prizes.find((item) => (roll -= item.chance) < 0) || prizes[prizes.length - 1];
    const coinsWon = selectedPrize.kind === "coins" ? selectedPrize.amount : 0;
    stats.reward_coins = coins - cost + coinsWon;
    saveLocalStats(stats);
    const nextOwned = selectedPrize.kind === "theme" ? [...owned, selectedPrize.theme_id] : owned;
    if (selectedPrize.kind === "theme") setOwnedThemes(nextOwned);
    return {
      prize_id: selectedPrize.prize_id,
      kind: selectedPrize.kind,
      theme_id: selectedPrize.theme_id || null,
      rarity: selectedPrize.rarity,
      coins_won: coinsWon,
      premium_days: 0,
      reward_coins: stats.reward_coins,
      owned_themes: nextOwned,
    };
  }
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) throw new Error("Prisijunk, kad atidarytum ir išsaugotum dėžutės prizą.");
  const { data, error } = await client.rpc("open_learning_case", { p_case_id: caseId });
  if (error) throw error;
  setOwnedThemes(data.owned_themes || []);
  return data;
}

async function invokeStudyBuddy(client, body) {
  const { data, error } = await client.functions.invoke("study-buddy", { body });
  if (error) {
    let message = error.message || "AI mokytojo užklausos nepavyko išsiųsti.";
    if (error.context instanceof Response) {
      if (error.context.status === 404) {
        message = "AI funkcija dar neįdiegta šiame Supabase projekte. Administratorius turi įdiegti study-buddy funkciją ir nustatyti OPENAI_API_KEY.";
      } else {
        const payload = await error.context.json();
        if (typeof payload.error === "string") message = payload.error;
      }
    }
    throw new Error(message);
  }
  return data;
}

async function getStudyBuddyClient() {
  const client = await getClient();
  if (!client) throw new Error("AI mokymosi draugui reikia prisijungti prie paskyros.");
  const { data, error } = await client.auth.getSession();
  if (error) throw error;
  if (!data.session) throw new Error("Prisijunk prie paskyros, kad galėtum naudotis AI mokytoju.");
  return client;
}

export async function askStudyBuddy({ question, buddyName, grade, mood = "cheerful", teachingStyle = "steps", imageFiles = [] }) {
  const client = await getClient();
  if (!client) throw new Error("AI mokymosi draugui reikia prisijungti prie paskyros.");
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) throw new Error("Prisijunk prie paskyros, kad galėtum paklausti AI mokytojo.");
  if (!question.trim() || question.length > 2500) throw new Error("Įvesk klausimą iki 2 500 simbolių.");
  if (![5, 6, 7, 8, 9, 10, 11, 12].includes(grade)) throw new Error("AI mokytojui pasirink 5–12 klasę.");
  if (imageFiles.length > 10) throw new Error("Vienu metu galima pridėti iki 10 nuotraukų.");
  const paths = [];
  try {
    for (const file of imageFiles) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024) {
        throw new Error("Nuotraukos turi būti JPG, PNG arba WEBP formato ir ne didesnės nei 5 MB.");
      }
      const path = `${sessionData.session.user.id}/${crypto.randomUUID()}`;
      const { error } = await client.storage.from("study-buddy-images").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type,
      });
      if (error) throw error;
      paths.push(path);
    }
    return await invokeStudyBuddy(client, {
      question,
      buddyName: buddyName.trim().slice(0, 24) || "Mokis",
      tutorGrade: grade,
      mood,
      teachingStyle,
      imagePaths: paths,
    });
  } catch (error) {
    if (paths.length > 0) {
      const { error: cleanupError } = await client.storage.from("study-buddy-images").remove(paths);
      if (cleanupError) console.error("Nepavyko pašalinti nepanaudotų mokytojo nuotraukų.", cleanupError);
    }
    throw error;
  }
}

export async function generateAssessmentQuestions({ grade, subject, topic, count, level = "hard", previousQuestions = [] }) {
  const normalizedTopic = typeof topic === "string" ? topic.trim() : "";
  if (![7, 8, 9, 10].includes(grade)) throw new Error("Pasirink 7–10 klasę.");
  if (!["matematika", "lietuviu", "istorija", "biologija", "fizika", "chemija", "geografija", "informatika", "muzika", "anglu", "rusu", "prancuzu", "ispanu", "vokieciu", "kita"].includes(subject)) throw new Error("Pasirink vieną iš sarašo dalykų.");
  if (normalizedTopic.length < 2 || normalizedTopic.length > 120) throw new Error("Temos pavadinimą sudaro 2–120 simbolių.");
  if (!Number.isInteger(count) || count < 1 || count > 50) throw new Error("Pasirink nuo 1 iki 50 užduočių.");
  if (!Array.isArray(previousQuestions) || previousQuestions.some((prompt) => typeof prompt !== "string" || prompt.length > 600)) {
    throw new Error("Ankstesnių užduočių sąrašas netinkamas.");
  }

  const client = await getStudyBuddyClient();
  const data = await invokeStudyBuddy(client, {
    tutorGrade: grade,
    practice: {
      grade,
      subject,
      topic: normalizedTopic,
      count,
      level: ["easy", "medium", "hard"].includes(level) ? level : "hard",
      previousQuestions: previousQuestions.slice(-8),
    },
  });
  if (!data || !Array.isArray(data.questions) || data.questions.length < 1 || data.questions.length > count) {
    throw new Error("AI nesukūrė visų prašytų užduočių. Pabandyk pasirinkti mažesnį skaičių.");
  }
  return data.questions;
}

export async function getLeaderboard() {
  const client = await getClient();
  if (!client) return [];
  const { data, error } = await client.rpc("get_public_leaderboard");
  if (error) throw error;
  return data || [];
}

export async function getPublicProfile(userId) {
  const client = await getClient();
  if (!client) throw new Error("Vieši profiliai veikia tik prijungus bendrą Supabase paskyrą.");
  const { data, error } = await client.rpc("get_public_profile", { p_user_id: userId });
  if (error) throw error;
  return data;
}

export async function searchPublicUsers(query) {
  const normalizedQuery = String(query || "").trim();
  if (normalizedQuery.replace(/^@/, "").length < 2) throw new Error("Įrašyk bent 2 vardo simbolius.");
  const client = await getClient();
  if (!client) throw new Error("Draugų paieškai prisijunk prie paskyros.");
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) throw new Error("Draugų paieškai prisijunk prie paskyros.");
  const { data, error } = await client.rpc("search_public_users", { p_query: normalizedQuery });
  if (error) throw error;
  if (!Array.isArray(data)) throw new Error("Draugų paieškos atsakymas netinkamas.");
  return data;
}

export async function sendFriendRequest(userId) {
  const client = await getClient();
  if (!client) throw new Error("Norint pridėti draugų reikia prisijungti.");
  const { data, error } = await client.rpc("send_friend_request", { p_user_id: userId });
  if (error) throw error;
  return data;
}

export async function getMyFriendData() {
  const client = await getClient();
  if (!client) throw new Error("Draugų sąrašui peržiūrėti prisijunk prie paskyros.");
  const { data, error } = await client.rpc("get_my_friend_data");
  if (error) throw error;
  if (!data || !Array.isArray(data.friends) || !Array.isArray(data.incoming_requests)) {
    throw new Error("Draugų sąrašo atsakymas netinkamas.");
  }
  return data;
}

export async function respondToFriendRequest(userId, accept) {
  const client = await getClient();
  if (!client) throw new Error("Norint tvarkyti draugų užklausas reikia prisijungti.");
  const { error } = await client.rpc("respond_to_friend_request", {
    p_user_id: userId,
    p_accept: Boolean(accept),
  });
  if (error) throw error;
}

export async function removeFriend(userId) {
  const client = await getClient();
  if (!client) throw new Error("Norint tvarkyti draugus reikia prisijungti.");
  const { error } = await client.rpc("remove_friend", { p_user_id: userId });
  if (error) throw error;
}

export async function claimAchievementReward(achievementId) {
  if (!achievementId) throw new Error("Ženklelio atlygis nenurodytas.");
  const client = await getClient();
  if (!client) throw new Error("Norint atsiimti ženklelio atlygį reikia prisijungti.");
  const { data, error } = await client.rpc("claim_achievement_reward", {
    p_achievement_id: achievementId,
  });
  if (error) throw error;
  return data;
}

export async function redeemPromoRewardCode(code) {
  const client = await getClient();
  if (!client) throw new Error("Atlygio kodams panaudoti prisijunk prie savo paskyros.");
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) throw new Error("Atlygio kodams panaudoti prisijunk prie savo paskyros.");
  const { data, error } = await client.rpc("redeem_promo_reward_code", { p_code: code });
  if (error) throw error;
  if (
    typeof data?.code !== "string" ||
    typeof data?.title !== "string" ||
    typeof data?.description !== "string" ||
    typeof data?.theme_id !== "string" ||
    data?.status !== "pending"
  ) {
    throw new Error("Atlygio kodo atsakymas netinkamas.");
  }
  return data;
}

export async function claimPromoRewardCode(code) {
  const client = await getClient();
  if (!client) throw new Error("Atlygiui atsiimti prisijunk prie savo paskyros.");
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) throw new Error("Atlygiui atsiimti prisijunk prie savo paskyros.");
  const { data, error } = await client.rpc("claim_promo_reward_code", { p_code: code });
  if (error) throw error;
  if (
    typeof data?.title !== "string" ||
    typeof data?.theme_id !== "string" ||
    typeof data?.already_owned !== "boolean" ||
    !Array.isArray(data?.owned_themes)
  ) {
    throw new Error("Atlygio atsiėmimo atsakymas netinkamas.");
  }
  setOwnedThemes(data.owned_themes);
  return data;
}

export async function updateCommunityProfile({ displayName, avatarUrl, isPrivate, bio = "", featuredBadgeId = null }) {
  const client = await getClient();
  if (!client) throw new Error("Privatumo nustatymai veikia tik su registruota paskyra.");
  const { data, error } = await client.rpc("update_my_public_profile", {
    p_display_name: displayName,
    p_avatar_url: avatarUrl,
    p_is_private: isPrivate,
    p_bio: bio,
    p_featured_badge_id: featuredBadgeId || null,
  });
  if (error) throw error;
  return data;
}

async function invokeTeacherFunction(name, body) {
  const client = await getClient();
  if (!client) throw new Error("Šiai funkcijai reikia prisijungti prie paskyros.");
  const { data, error } = await client.functions.invoke(name, { body });
  if (error) {
    if (error.context instanceof Response) {
      let result;
      try {
        result = await error.context.clone().json();
      } catch {
        throw error;
      }
      if (typeof result?.error === "string") throw new Error(result.error);
    }
    throw error;
  }
  if (data?.error) throw new Error(data.error);
  return data;
}

export async function createTeacherCheckoutSession({ studentCount, plan, termEndDates }) {
  const data = await invokeTeacherFunction("teacher-checkout-session", {
    student_count: studentCount,
    plan,
    term_end_dates: termEndDates,
  });
  if (typeof data?.url !== "string") throw new Error("Stripe atsiskaitymo nuoroda negauta.");
  return data.url;
}

export async function getTeacherPurchaseCodes(sessionId) {
  const data = await invokeTeacherFunction("teacher-purchase-codes", { session_id: sessionId });
  if (!Array.isArray(data?.codes) || !data.codes.every((code) => typeof code === "string")) {
    throw new Error("Mokyklos aktyvavimo kodų atsakymas netinkamas.");
  }
  return data;
}

export async function getMyTeacherPurchases() {
  const client = await getClient();
  if (!client) throw new Error("Mokytojų pirkimų istorijai reikia prisijungti prie paskyros.");
  const { data, error } = await client.rpc("get_my_teacher_purchases");
  if (error) throw error;
  if (!Array.isArray(data)) throw new Error("Mokytojų pirkimų sąrašo atsakymas netinkamas.");
  return data;
}

export async function getMyTeacherWorkspace() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_teacher_workspace");
  if (error) throw error;
  return data;
}

export async function createTeacherClass({ name, subject }) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("create_teacher_class", {
    p_name: name,
    p_subject: subject,
  });
  if (error) throw error;
  return data;
}

export async function inviteStudentsToTeacherClass(classroomId, usernames) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("invite_students_to_teacher_class", {
    p_classroom_id: classroomId,
    p_usernames: usernames,
  });
  if (error) throw error;
  return data || [];
}

export async function respondToTeacherClassInvitation(classroomId, accept) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("respond_to_teacher_class_invitation", {
    p_classroom_id: classroomId,
    p_accept: accept,
  });
  if (error) throw error;
  return data;
}

export async function createLearningTask({
  classroomId = null,
  title,
  instructions,
  dueDate = null,
  questions,
  visibility = null,
  shuffleQuestions = false,
}) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("create_learning_task_with_options", {
    p_classroom_id: classroomId,
    p_title: title,
    p_instructions: instructions,
    p_due_date: dueDate || null,
    p_questions: questions,
    p_visibility: visibility,
    p_shuffle_questions: Boolean(shuffleQuestions),
  });
  if (error) throw error;
  return data;
}

export async function getCurrentUserId() {
  const client = await getClient();
  if (!client || isGuestMode()) return null;
  const { data, error } = await client.auth.getSession();
  if (error) throw error;
  return data.session?.user.id || null;
}

export async function getMyTaskDeliverySettings() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_task_delivery_settings");
  if (error) throw error;
  if (!Array.isArray(data)) throw new Error("Užduočių nustatymų atsakymas netinkamas.");
  return data;
}

export async function getMyAssignmentReview(assignmentId) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_assignment_review", {
    p_assignment_id: assignmentId,
  });
  if (error) throw error;
  if (!Array.isArray(data)) throw new Error("Klaidingų atsakymų peržiūros atsakymas netinkamas.");
  return data;
}

export async function getMyAssignmentFeedback() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_assignment_feedback");
  if (error) throw error;
  if (!Array.isArray(data)) throw new Error("Mokytojo pastabų atsakymas netinkamas.");
  return data;
}

export async function saveTeacherAssignmentFeedback(assignmentId, studentId, feedback) {
  const client = await getStudyBuddyClient();
  const { error } = await client.rpc("save_teacher_assignment_feedback", {
    p_assignment_id: assignmentId,
    p_student_id: studentId,
    p_feedback: feedback,
  });
  if (error) throw error;
}

export async function getMyTeacherAssignmentAnalytics() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_teacher_assignment_analytics");
  if (error) throw error;
  if (!Array.isArray(data)) throw new Error("Mokytojo analitikos atsakymas netinkamas.");
  return data;
}

export async function shareLearningTask(assignmentId, usernames) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("share_learning_task", {
    p_assignment_id: assignmentId,
    p_usernames: usernames,
  });
  if (error) throw error;
  return data || [];
}

export async function getMyLearningTasks() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_learning_tasks");
  if (error) throw error;
  return data || [];
}

export async function getMyTaskCreationUsage() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_my_task_creation_usage");
  if (error) throw error;
  if (
    !data ||
    !Number.isSafeInteger(Number(data.created_projects)) ||
    typeof data.is_premium !== "boolean"
  ) {
    throw new Error("Užduočių kūrimo limitų atsakymas netinkamas.");
  }
  return { created_projects: Number(data.created_projects), is_premium: data.is_premium };
}

export async function getAvailableLearningTasks() {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("get_available_learning_tasks");
  if (error) throw error;
  return data || [];
}

export async function submitTeacherAssignment(assignmentId, answers) {
  const client = await getStudyBuddyClient();
  const { data, error } = await client.rpc("submit_teacher_assignment", {
    p_assignment_id: assignmentId,
    p_answers: answers,
  });
  if (error) throw error;
  return data;
}

export async function getMyTeacherPremiumUntil() {
  const client = await getClient();
  if (!client) return null;
  const { data, error } = await client.rpc("get_my_teacher_premium_until");
  if (error) throw error;
  if (data !== null && typeof data !== "string") {
    throw new Error("Mokytojo Premium prieigos datos atsakymas netinkamas.");
  }
  return data;
}

export async function redeemTeacherPremiumCode(code) {
  const data = await invokeTeacherFunction("redeem-teacher-premium-code", { code });
  if (data?.redeemed !== true || typeof data.access_until !== "string") {
    throw new Error("Mokytojo kodo aktyvavimo atsakymas netinkamas.");
  }
  return data;
}

export async function uploadAvatar(file) {
  const client = await getClient();
  if (!client) throw new Error("Nuotraukos įkėlimui reikia registruotos paskyros.");
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 3 * 1024 * 1024) {
    throw new Error("Pasirink JPG, PNG arba WEBP nuotrauką iki 3 MB.");
  }
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  const userId = sessionData.session?.user.id;
  if (!userId) throw new Error("Pirmiausia prisijunk prie paskyros.");
  const path = `${userId}/${crypto.randomUUID()}`;
  const { error: uploadError } = await client.storage.from("profile-avatars").upload(path, file, {
    cacheControl: "3600",
    upsert: false,
  });
  if (uploadError) throw uploadError;
  const { data } = client.storage.from("profile-avatars").getPublicUrl(path);
  return data.publicUrl;
}
