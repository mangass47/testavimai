const settingKeys = {
  defaultSubject: "testavimai-learning-default-subject",
  grade: "testavimai-learning-grade",
  favoriteSubjects: "testavimai-learning-favorite-subjects",
  difficulty: "testavimai-learning-default-difficulty",
  buddyName: "testavimai-buddy-name",
  buddyMood: "testavimai-buddy-mood",
  buddyStyle: "testavimai-buddy-style",
  remindersEnabled: "testavimai-reminders-enabled",
  reminderTime: "testavimai-reminder-time",
  reminderLastSent: "testavimai-reminders-last-sent",
};

const translate = (key, values = {}) => window.testavimai?.t?.(key, values) ?? key;
const learningDataKeys = [
  "testavimai-subject-learning-summary",
  "testavimai-test-result-history",
  "testavimai-weekly-question-activity",
  "testavimai-practice-review",
  "testavimai-flashcard-progress",
  "testavimai-demo-progress",
  "testavimai-demo-daily",
];
const preferenceKeys = [
  "testavimai-language",
  "testavimai-theme",
  "testavimai-accessibility-large-text",
  "testavimai-accessibility-high-contrast",
  "testavimai-accessibility-reduced-motion",
  "testavimai-show-answer-explanations",
  ...Object.values(settingKeys),
];

function setStatus(element, message, kind = "info") {
  if (!element) return;
  element.textContent = message;
  element.className = `profile-status${kind === "info" ? "" : ` ${kind}`}`;
}

function readSetting(key, fallback = "") {
  try {
    return localStorage.getItem(key) ?? fallback;
  } catch (error) {
    console.error(`Nepavyko nuskaityti nuostatos ${key}.`, error);
    return fallback;
  }
}

function saveSetting(key, value, status) {
  try {
    localStorage.setItem(key, value);
    setStatus(status, translate("settings_saved_local"), "success");
    return true;
  } catch (error) {
    console.error(`Nepavyko išsaugoti nuostatos ${key}.`, error);
    setStatus(status, translate("settings_save_error"), "error");
    return false;
  }
}

function initializeLearningSettings() {
  const status = document.querySelector("#learning-settings-status");
  const defaultSubject = document.querySelector("#learning-default-subject");
  const grade = document.querySelector("#learning-grade");
  const favorites = document.querySelector("#learning-favorite-subjects");
  const difficulty = document.querySelector("#learning-default-difficulty");
  const buddyName = document.querySelector("#settings-buddy-name");
  const buddyMood = document.querySelector("#settings-buddy-mood");
  const buddyStyle = document.querySelector("#settings-buddy-style");

  const savedSubject = readSetting(settingKeys.defaultSubject, "all");
  if ([...defaultSubject.options].some((option) => option.value === savedSubject)) defaultSubject.value = savedSubject;
  const savedGrade = readSetting(settingKeys.grade);
  if ([...grade.options].some((option) => option.value === savedGrade)) grade.value = savedGrade;
  const savedDifficulty = readSetting(settingKeys.difficulty, "all");
  if ([...difficulty.options].some((option) => option.value === savedDifficulty)) difficulty.value = savedDifficulty;

  try {
    const savedFavorites = JSON.parse(readSetting(settingKeys.favoriteSubjects, "[]"));
    if (Array.isArray(savedFavorites)) {
      [...favorites.options].forEach((option) => { option.selected = savedFavorites.includes(option.value); });
    }
  } catch (error) {
    console.error("Nepavyko nuskaityti mėgstamų mokomųjų dalykų.", error);
  }

  buddyName.value = readSetting(settingKeys.buddyName, "Mokis");
  const savedMood = readSetting(settingKeys.buddyMood, "cheerful");
  if ([...buddyMood.options].some((option) => option.value === savedMood)) buddyMood.value = savedMood;
  const savedStyle = readSetting(settingKeys.buddyStyle, "steps");
  if ([...buddyStyle.options].some((option) => option.value === savedStyle)) buddyStyle.value = savedStyle;

  defaultSubject.addEventListener("change", () => saveSetting(settingKeys.defaultSubject, defaultSubject.value, status));
  grade.addEventListener("change", () => saveSetting(settingKeys.grade, grade.value, status));
  favorites.addEventListener("change", () => {
    const selected = [...favorites.selectedOptions].map((option) => option.value);
    saveSetting(settingKeys.favoriteSubjects, JSON.stringify(selected), status);
  });
  difficulty.addEventListener("change", () => saveSetting(settingKeys.difficulty, difficulty.value, status));
  buddyName.addEventListener("change", () => {
    buddyName.value = buddyName.value.trim().slice(0, 24) || "Mokis";
    saveSetting(settingKeys.buddyName, buddyName.value, status);
  });
  buddyMood.addEventListener("change", () => saveSetting(settingKeys.buddyMood, buddyMood.value, status));
  buddyStyle.addEventListener("change", () => saveSetting(settingKeys.buddyStyle, buddyStyle.value, status));
}

function initializeReminders() {
  const enabled = document.querySelector("#learning-reminders-enabled");
  const time = document.querySelector("#learning-reminder-time");
  const permissionButton = document.querySelector("#enable-browser-reminders");
  const status = document.querySelector("#reminder-settings-status");
  enabled.checked = readSetting(settingKeys.remindersEnabled) === "true";
  const savedTime = readSetting(settingKeys.reminderTime, "18:00");
  if (/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(savedTime)) time.value = savedTime;

  enabled.addEventListener("change", () => {
    if (!saveSetting(settingKeys.remindersEnabled, String(enabled.checked), status)) {
      enabled.checked = !enabled.checked;
      return;
    }
    if (enabled.checked && (!("Notification" in window) || Notification.permission !== "granted")) {
      setStatus(status, translate("reminder_need_permission"), "info");
    } else if (!enabled.checked) {
      setStatus(status, translate("reminder_disabled"), "success");
    }
  });
  time.addEventListener("change", () => {
    if (!time.value) {
      time.value = "18:00";
      setStatus(status, translate("reminder_invalid_time"), "error");
      return;
    }
    saveSetting(settingKeys.reminderTime, time.value, status);
  });
  permissionButton.addEventListener("click", async () => {
    if (!("Notification" in window)) {
      setStatus(status, translate("reminder_not_supported"), "error");
      return;
    }
    if (!window.isSecureContext) {
      setStatus(status, translate("reminder_https"), "error");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        setStatus(status, translate("reminder_permission_granted"), "success");
      } else {
        setStatus(status, translate(permission === "denied" ? "reminder_permission_denied" : "reminder_permission_missing"), "error");
      }
    } catch (error) {
      console.error("Nepavyko paprašyti naršyklės pranešimų leidimo.", error);
      setStatus(status, translate("reminder_permission_error", { message: error.message }), "error");
    }
  });
}

function readLocalLearningData() {
  const result = {};
  const keys = [...learningDataKeys];
  try {
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key?.startsWith("testavimai-assessment-history-") || key?.startsWith("testavimai-weekly-plan-")) keys.push(key);
    }
    [...new Set(keys)].forEach((key) => {
      const value = localStorage.getItem(key);
      if (value === null) return;
      try {
        result[key] = JSON.parse(value);
      } catch (error) {
        console.warn(`Vietinis mokymosi įrašas ${key} nėra JSON; eksportuojama neapdorota reikšmė.`, error);
        result[key] = value;
      }
    });
  } catch (error) {
    console.error("Nepavyko paruošti vietinių mokymosi duomenų eksporto.", error);
    throw new Error(translate("data_export_read_error"));
  }
  return result;
}

function initializeDataControls() {
  const status = document.querySelector("#profile-data-status");
  document.querySelector("#export-learning-data").addEventListener("click", () => {
    try {
      const payload = {
        exportedAt: new Date().toISOString(),
        scope: "Šiame įrenginyje saugomi mokymosi duomenys; serverio duomenys neįtraukti.",
        data: readLocalLearningData(),
      };
      const file = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(file);
      const link = document.createElement("a");
      link.href = url;
      link.download = `testavimai-mokymosi-duomenys-${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus(status, translate("data_export_success"), "success");
    } catch (error) {
      console.error("Mokymosi duomenų eksportuoti nepavyko.", error);
      setStatus(status, error.message, "error");
    }
  });

  document.querySelector("#clear-learning-data").addEventListener("click", () => {
    if (!window.confirm(translate("data_clear_confirm"))) return;
    try {
      const keys = [...learningDataKeys];
      for (let index = 0; index < localStorage.length; index += 1) {
        const key = localStorage.key(index);
        if (key?.startsWith("testavimai-assessment-history-") || key?.startsWith("testavimai-weekly-plan-")) keys.push(key);
      }
      [...new Set(keys)].forEach((key) => localStorage.removeItem(key));
      setStatus(status, translate("data_clear_success"), "success");
    } catch (error) {
      console.error("Vietinių mokymosi duomenų išvalyti nepavyko.", error);
      setStatus(status, translate("data_clear_error", { message: error.message }), "error");
    }
  });
}

function initializeRestoreDefaults() {
  document.querySelector("#restore-profile-defaults").addEventListener("click", () => {
    if (!window.confirm(translate("settings_restore_confirm"))) return;
    try {
      preferenceKeys.forEach((key) => localStorage.removeItem(key));
      const status = document.querySelector("#profile-preferences-status");
      setStatus(status, translate("settings_restore_success"), "success");
      window.setTimeout(() => window.location.reload(), 500);
    } catch (error) {
      console.error("Numatytųjų nuostatų atkurti nepavyko.", error);
      setStatus(document.querySelector("#profile-preferences-status"), translate("settings_restore_error", { message: error.message }), "error");
    }
  });
}

initializeLearningSettings();
initializeReminders();
initializeDataControls();
initializeRestoreDefaults();
