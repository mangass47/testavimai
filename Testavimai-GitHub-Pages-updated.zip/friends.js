import {
  getMyFriendData,
  removeFriend,
  respondToFriendRequest,
  searchPublicUsers,
  sendFriendRequest,
} from "./progress.js";

const searchForm = document.querySelector("#friends-search-form");
const searchInput = document.querySelector("#friends-search-input");
const searchStatus = document.querySelector("#friends-search-status");
const searchResults = document.querySelector("#friends-search-results");
const requestsStatus = document.querySelector("#friend-requests-status");
const requestsList = document.querySelector("#friend-requests-list");
const friendsStatus = document.querySelector("#my-friends-status");
const friendsList = document.querySelector("#my-friends-list");

function renderPerson(container, user, actionLabel, action, secondaryAction) {
  const row = document.createElement("li");
  row.className = "friend-row";
  const identity = document.createElement("div");
  identity.className = "friend-row-identity";
  const name = document.createElement("strong");
  name.textContent = user.display_name;
  const username = document.createElement("span");
  username.textContent = `@${user.username}`;
  identity.append(name, username);
  const actions = document.createElement("div");
  actions.className = "friend-row-actions";
  const primary = document.createElement("button");
  primary.type = "button";
  primary.className = "profile-secondary-button";
  primary.textContent = actionLabel;
  primary.addEventListener("click", async () => {
    primary.disabled = true;
    try {
      await action();
      await loadFriendData();
    } catch (error) {
      console.error("Draugų veiksmas nepavyko.", error);
      primary.disabled = false;
      primary.title = error.message;
      primary.textContent = error.message;
    }
  });
  actions.append(primary);
  if (secondaryAction) {
    const secondary = document.createElement("button");
    secondary.type = "button";
    secondary.className = "profile-secondary-button";
    secondary.textContent = secondaryAction.label;
    secondary.addEventListener("click", async () => {
      secondary.disabled = true;
      try {
        await secondaryAction.run();
        await loadFriendData();
      } catch (error) {
        console.error("Draugų veiksmas nepavyko.", error);
        secondary.disabled = false;
        secondary.title = error.message;
        secondary.textContent = error.message;
      }
    });
    actions.append(secondary);
  }
  row.append(identity, actions);
  container.append(row);
}

async function loadFriendData() {
  requestsStatus.textContent = "Kraunama…";
  friendsStatus.textContent = "Kraunama…";
  try {
    const data = await getMyFriendData();
    requestsList.replaceChildren();
    if (!data.incoming_requests.length) {
      requestsStatus.textContent = "Naujų užklausų nėra.";
    } else {
      requestsStatus.textContent = `Gautos užklausos: ${data.incoming_requests.length}.`;
      data.incoming_requests.forEach((user) => {
        renderPerson(
          requestsList,
          user,
          "Priimti",
          () => respondToFriendRequest(user.user_id, true),
          { label: "Atmesti", run: () => respondToFriendRequest(user.user_id, false) },
        );
      });
    }

    friendsList.replaceChildren();
    if (!data.friends.length) {
      friendsStatus.textContent = "Draugų dar nėra. Ieškok pagal @vartotojo_vardą.";
    } else {
      friendsStatus.textContent = `Draugai: ${data.friends.length}.`;
      data.friends.forEach((user) => {
        renderPerson(friendsList, user, "Pašalinti", () => removeFriend(user.user_id));
      });
    }
  } catch (error) {
    console.error("Draugų sąrašo įkelti nepavyko.", error);
    requestsStatus.textContent = `Draugų užklausų įkelti nepavyko: ${error.message}`;
    friendsStatus.textContent = `Draugų sąrašo įkelti nepavyko: ${error.message}`;
  }
}

searchForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = searchForm.querySelector('button[type="submit"]');
  button.disabled = true;
  searchStatus.textContent = "Ieškoma viešų profilių…";
  searchResults.replaceChildren();
  try {
    const users = await searchPublicUsers(searchInput.value);
    if (!users.length) {
      searchStatus.textContent = "Viešų profilių nerasta.";
      return;
    }
    searchStatus.textContent = `Rasta paskyrų: ${users.length}. Privačių profilių paieška nerodo.`;
    users.forEach((user) => {
      renderPerson(searchResults, user, "Pridėti draugą", async () => {
        const result = await sendFriendRequest(user.user_id);
        searchStatus.textContent = result.status === "accepted"
          ? `Su @${user.username} dabar esate draugai.`
          : `Draugo užklausa @${user.username} išsiųsta.`;
      });
    });
  } catch (error) {
    console.error("Draugų paieška nepavyko.", error);
    searchStatus.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

void loadFriendData();
