import { subjectCatalog, gradeBands } from "./subjects.js";

const existing = new Set(["lietuviu", "matematika", "biologija", "istorija", "fizika"]);
const list = document.querySelector("#pamokos");
const tr = (key) => window.testavimai?.t?.(key) ?? key;

if (list) {
  subjectCatalog.filter((subject) => !existing.has(subject.id)).forEach((subject) => {
    const article = document.createElement("article");
    article.className = "lesson-card";
    article.dataset.subject = subject.id;

    const heading = document.createElement("div");
    heading.className = "lesson-card-heading";
    const icon = Object.assign(document.createElement("span"), { className: "lesson-icon", textContent: subject.icon });
    const titleBox = document.createElement("div");
    const label = Object.assign(document.createElement("span"), { className: "lesson-label", textContent: subject.label });
    const title = document.createElement("h2");
    title.dataset.i18n = subject.key;
    title.textContent = subject.key;
    titleBox.append(label, title);
    heading.append(icon, titleBox);

    const lead = Object.assign(document.createElement("p"), { className: "lesson-lead", textContent: subject.lead });
    const topics = document.createElement("div");
    topics.className = "lesson-topics";
    gradeBands.forEach((band) => {
      const section = document.createElement("section");
      const h3 = Object.assign(document.createElement("h3"), { textContent: `${band.id.replace("-", "–")} kl.` });
      const p = Object.assign(document.createElement("p"), { textContent: subject.topics[band.id].join(" · ") });
      section.append(h3, p);
      topics.append(section);
    });

    const bottom = document.createElement("div");
    bottom.className = "lesson-card-bottom";
    const link = Object.assign(document.createElement("a"), {
      className: "lesson-practice",
      href: `praktika.html?dalykas=${subject.id}#atsiskaitymui`,
      textContent: "Praktikuotis ↗",
    });
    bottom.append(Object.assign(document.createElement("span"), { textContent: "Testai pagal tavo klasę ir lygį" }), link);

    article.append(heading, lead, topics, bottom);
    list.append(article);
  });
  window.testavimai?.refresh?.();
  title_fallback();
}

function title_fallback() {
  list?.querySelectorAll("h2[data-i18n]").forEach((h2) => {
    const value = tr(h2.dataset.i18n);
    if (value !== h2.dataset.i18n) h2.textContent = value;
  });
}
