const questionTypes = [
  ["multiple_choice", "task_type_multiple_choice", "Pasirinkimas", false],
  ["true_false", "task_type_true_false", "Tiesa / netiesa · Premium", true],
  ["short_answer", "task_type_short_answer", "Trumpas atsakymas · Premium", true],
  ["fill_blank", "task_type_fill_blank", "Užpildyti tarpą · Premium", true],
];

const status = document.querySelector("#workspace-status");
const taskStatus = document.querySelector("#task-create-status");
const taskForm = document.querySelector("#learning-task-form");
const questionBuilders = document.querySelector("#question-builders");
const classField = document.querySelector("#task-classroom-field");
const taskCreationLimits = document.querySelector("#task-creation-limits");
const questionLimitLabel = document.querySelector("#question-limit-label");
const addQuestionButton = document.querySelector("#add-task-question");
const taskPreviewButton = document.querySelector("#preview-learning-task");
const taskPreview = document.querySelector("#task-preview");
const taskDraftStatus = document.querySelector("#task-draft-status");
const taskReminders = document.querySelector("#task-reminders");
const taskSubmitButton = taskForm.querySelector('[type="submit"]');
const classSelect = taskForm.elements.classroom_id;
const visibilitySelect = taskForm.elements.visibility;
visibilitySelect.addEventListener("change", updateVisibilityFields);
let progress = { is_premium: false };
let workspace;
let creationUsage = { created_projects: 0, is_premium: false };
let questionEditorId = 0;
let creatingTask = false;
let draftOwnerId = null;
let draftSaveTimer = null;
let restoringDraft = false;
let teacherAnalytics = new Map();
let studentFeedback = new Map();
const attemptLayouts = new Map();

const translate = (key, fallback, values = {}) => {
  const translated = window.testavimai?.t?.(key, values);
  return translated && translated !== key
    ? translated
    : fallback.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
};

function setStatus(element, message, isError = false) {
  element.textContent = message;
  element.classList.toggle("is-error", isError);
  element.classList.toggle("is-success", !isError && Boolean(message));
  element.setAttribute("role", isError ? "alert" : "status");
  element.setAttribute("aria-live", isError ? "assertive" : "polite");
}

function createField(labelText, control) {
  const label = document.createElement("label");
  label.append(document.createTextNode(labelText), control);
  return label;
}

function createInput({ type = "text", name, placeholder = "", required = true, maxlength = 240 } = {}) {
  const input = document.createElement("input");
  input.type = type;
  if (name) input.name = name;
  input.placeholder = placeholder;
  input.required = required;
  input.maxLength = maxlength;
  return input;
}

function shuffledIndices(length) {
  const indices = Array.from({ length }, (_, index) => index);
  for (let index = indices.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(Math.random() * (index + 1));
    [indices[index], indices[swap]] = [indices[swap], indices[index]];
  }
  return indices;
}

function isAnswerCorrect(question, answer) {
  if (question.type === "multiple_choice" || question.type === "true_false") {
    return answer === question.correct;
  }
  return (question.acceptable_answers || []).some((expected) =>
    expected.trim().toLocaleLowerCase() === String(answer).trim().toLocaleLowerCase(),
  );
}

function createQuestionEditor() {
  const editor = document.createElement("fieldset");
  editor.className = "question-editor";
  editor.dataset.questionEditor = String(questionEditorId++);

  const heading = document.createElement("div");
  heading.className = "question-editor-heading";
  const title = document.createElement("strong");
  title.textContent = translate("task_question_number", "Klausimas {n}", { n: questionBuilders.children.length + 1 });
  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "question-remove-button";
  remove.textContent = translate("task_remove", "Pašalinti");
  remove.setAttribute("aria-label", translate("task_remove_question", "Pašalinti klausimą {n}", { n: questionBuilders.children.length + 1 }));
  remove.addEventListener("click", () => {
    editor.remove();
    renumberQuestionEditors();
  });
  heading.append(title, remove);

  const type = document.createElement("select");
  type.dataset.questionType = "";
  questionTypes.forEach(([value, key, fallback, premium]) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = translate(key, fallback);
    option.dataset.premium = String(premium);
    option.disabled = premium && !progress.is_premium;
    type.append(option);
  });
  const prompt = document.createElement("textarea");
  prompt.dataset.questionPrompt = "";
  prompt.required = true;
  prompt.maxLength = 500;
  prompt.rows = 2;
  prompt.minLength = 3;
  prompt.placeholder = translate("task_enter_question", "Įrašyk klausimą");
  const specificFields = document.createElement("div");
  specificFields.className = "question-specific-fields";
  const body = document.createElement("div");
  body.className = "question-editor-fields";
  body.append(
    createField(translate("task_question_type", "Klausimo tipas"), type),
    createField(translate("task_question_label", "Klausimas"), prompt),
    specificFields,
  );
  heading.querySelector(".question-remove-button").disabled = questionBuilders.children.length < 1;
  type.addEventListener("change", () => renderQuestionFields(editor, type.value));
  editor.append(heading, body);
  renderQuestionFields(editor, type.value);
  return editor;
}

function renderQuestionFields(editor, type) {
  const fields = editor.querySelector(".question-specific-fields");
  fields.replaceChildren();

  if (type === "multiple_choice") {
    const answerFields = document.createElement("div");
    answerFields.className = "question-answer-fields";
    const correct = document.createElement("select");
    correct.dataset.questionCorrect = "";
    correct.setAttribute("aria-label", translate("task_correct_answer", "Teisingas atsakymas"));
    ["1", "2", "3", "4"].forEach((number, index) => {
      const option = document.createElement("option");
      option.value = String(index);
      option.textContent = translate("task_correct_option", "Teisingas atsakymas: {n} variantas", { n: number });
      correct.append(option);
    });
    for (let index = 0; index < 4; index += 1) {
      const answer = createInput({ placeholder: translate("task_answer_option", "Atsakymo variantas {n}", { n: index + 1 }) });
      answer.dataset.questionAnswer = "";
      answerFields.append(answer);
    }
    fields.append(answerFields, createField(translate("task_correct_answer", "Teisingas atsakymas"), correct));
  } else if (type === "true_false") {
    const correct = document.createElement("select");
    correct.dataset.questionCorrect = "";
    [["true", translate("task_true", "Tiesa")], ["false", translate("task_false", "Netiesa")]].forEach(([value, label]) => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = label;
      correct.append(option);
    });
    fields.append(createField(translate("task_correct_answer", "Teisingas atsakymas"), correct));
  } else {
    const prompt = editor.querySelector("[data-question-prompt]");
    prompt.placeholder = type === "fill_blank"
      ? translate("task_fill_prompt", "Naudok ___ vietai, kurią mokinys turi užpildyti")
      : translate("task_enter_question", "Įrašyk klausimą");
    const answers = document.createElement("textarea");
    answers.dataset.acceptableAnswers = "";
    answers.required = true;
    answers.maxLength = 1200;
    answers.rows = 2;
    answers.placeholder = translate("task_acceptable_placeholder", "Priimtini atsakymai (po vieną eilutėje)");
    fields.append(createField(translate("task_acceptable_answers", "Priimtini atsakymai"), answers));
  }
}

function renumberQuestionEditors() {
  [...questionBuilders.children].forEach((editor, index) => {
    editor.querySelector(".question-editor-heading strong").textContent = translate("task_question_number", "Klausimas {n}", { n: index + 1 });
    const remove = editor.querySelector(".question-remove-button");
    remove.disabled = questionBuilders.children.length === 1;
    remove.setAttribute("aria-label", translate("task_remove_question", "Pašalinti klausimą {n}", { n: index + 1 }));
  });
}

function readQuestionEditors() {
  return [...questionBuilders.children].map((editor) => {
    const type = editor.querySelector("[data-question-type]").value;
    const prompt = editor.querySelector("[data-question-prompt]").value.trim();
    if (type === "multiple_choice") {
      return {
        type,
        prompt,
        answers: [...editor.querySelectorAll("[data-question-answer]")].map((answer) => answer.value.trim()),
        correct: Number(editor.querySelector("[data-question-correct]").value),
      };
    }
    if (type === "true_false") {
      return { type, prompt, correct: editor.querySelector("[data-question-correct]").value === "true" };
    }
    if (type === "fill_blank" && !prompt.includes("___")) {
      throw new Error(translate("task_fill_marker_error", "Užpildymo klausime pažymėk vietą simboliais ___ ."));
    }
    const acceptableAnswers = editor.querySelector("[data-acceptable-answers]").value
      .split(/\r?\n/)
      .map((answer) => answer.trim())
      .filter(Boolean);
    return { type, prompt, acceptable_answers: acceptableAnswers };
  });
}

function renderClassroomOptions() {
  const selectedClassId = classSelect.value;
  classSelect.replaceChildren(new Option(translate("task_choose_class", "Pasirink klasę"), ""));
  (workspace.classes || []).forEach((classroom) => {
    classSelect.append(new Option(`${classroom.name} · ${classroom.subject}`, classroom.id));
  });
  if (workspace.role === "teacher" && !visibilitySelect.querySelector('option[value="class"]')) {
    visibilitySelect.append(new Option(translate("task_visibility_class", "Mano klasei"), "class"));
  }
  if ([...classSelect.options].some((option) => option.value === selectedClassId)) classSelect.value = selectedClassId;
  updateVisibilityFields();
}

function updateVisibilityFields() {
  const isClass = visibilitySelect.value === "class";
  classField.hidden = !isClass;
  classSelect.required = isClass;
}

function renderClassrooms() {
  const list = document.querySelector("#teacher-class-list");
  list.replaceChildren();
  (workspace.classes || []).forEach((classroom) => {
    const card = document.createElement("article");
    card.className = "workspace-card";
    const heading = document.createElement("h3");
    heading.textContent = `${classroom.name} · ${classroom.subject}`;
    const members = document.createElement("p");
    const accepted = classroom.students.filter((student) => student.status === "accepted");
    const invited = classroom.students.filter((student) => student.status === "invited");
    members.textContent = translate("task_class_member_count", "{students} mokinių · {invited} laukia kvietimo", {
      students: accepted.length,
      invited: invited.length,
    });

    const form = document.createElement("form");
    form.className = "workspace-inline-form";
    const usernames = document.createElement("textarea");
    usernames.name = "usernames";
    usernames.required = true;
    usernames.rows = 2;
    usernames.placeholder = "@mokinys1, @mokinys2";
    const field = createField(translate("task_invite_usernames", "Mokinių @username (atskirk kableliais arba eilutėmis)"), usernames);
    const submit = document.createElement("button");
    submit.type = "submit";
    submit.className = "workspace-secondary-button";
    submit.textContent = translate("task_invite_button", "Siųsti kvietimus");
    const message = document.createElement("p");
    message.className = "workspace-status";
    message.setAttribute("role", "status");
    form.append(field, submit, message);
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      submit.disabled = true;
      try {
        const { inviteStudentsToTeacherClass } = await import("./progress.js");
        const names = usernames.value.split(/[,\s]+/).map((value) => value.trim()).filter(Boolean);
        const results = await inviteStudentsToTeacherClass(classroom.id, names);
        const statusKeys = {
          invited: ["task_invite_sent", "išsiųstas kvietimas"],
          already_invited: ["task_invite_already_sent", "kvietimas jau išsiųstas"],
          already_member: ["task_invite_member", "jau prisijungęs"],
          not_found: ["task_invite_not_found", "mokinys nerastas"],
          invalid: ["task_invalid_username", "netinkamas @username"],
        };
        const summary = results.map((item) => {
          const [key, fallback] = statusKeys[item.status] || ["task_action_failed", "nepavyko"];
          return `${item.username}: ${translate(key, fallback)}`;
        }).join(" · ");
        setStatus(message, summary || translate("task_invites_sent", "Kvietimų išsiųsta."));
        await loadWorkspace();
      } catch (error) {
        console.error("Nepavyko pakviesti mokinių į klasę.", error);
        setStatus(message, error.message, true);
      } finally {
        submit.disabled = false;
      }
    });

    const roster = document.createElement("ul");
    roster.className = "workspace-roster";
    classroom.students.forEach((student) => {
      const item = document.createElement("li");
      const state = student.status === "accepted"
        ? translate("task_member_joined", "prisijungė")
        : student.status === "invited"
          ? translate("task_invite_waiting", "laukiama atsakymo")
          : translate("task_invite_declined", "atsisakė");
      item.textContent = `@${student.username} · ${student.display_name} · ${state}`;
      roster.append(item);
    });

    const assignments = document.createElement("div");
    assignments.className = "workspace-class-assignments";
    const assignmentsHeading = document.createElement("strong");
    assignmentsHeading.textContent = translate("task_class_assignments", "Klasės užduotys ({n})", { n: classroom.assignments.length });
    assignments.append(assignmentsHeading);
    if (classroom.assignments.length) {
      const assignmentList = document.createElement("ul");
      assignmentList.className = "workspace-roster";
      classroom.assignments.forEach((assignment) => {
        const item = document.createElement("li");
        const submissions = assignment.submissions || [];
        const submittedNames = new Set(submissions.map((submission) => submission.username));
        const acceptedStudents = classroom.students.filter((student) => student.status === "accepted");
        const pendingNames = acceptedStudents
          .filter((student) => !submittedNames.has(student.username))
          .map((student) => `@${student.username}`);
        const dueDate = assignment.due_date
          ? ` · ${translate("task_due_date", "Atlikti iki {date}", {
            date: new Intl.DateTimeFormat(document.documentElement.lang || "lt").format(new Date(`${assignment.due_date}T00:00:00`)),
          })}`
          : "";
        const scores = submissions
          .map((submission) => `@${submission.username} ${submission.score}/${submission.total}`)
          .join(", ");
        item.textContent = `${assignment.title} · ${translate("task_class_submitted_count", "{submitted}/{total} pateikė", {
          submitted: submissions.length,
          total: acceptedStudents.length,
        })}${dueDate}${scores ? ` · ${translate("task_class_scores", "Įvertinimai")}: ${scores}` : ""}${pendingNames.length ? ` · ${translate("task_class_pending", "Laukia")}: ${pendingNames.join(", ")}` : ""}`;
        assignmentList.append(item);
        const analytics = teacherAnalytics.get(assignment.id);
        if (analytics) item.append(renderTeacherAnalytics(assignment, analytics));
      });
      assignments.append(assignmentList);
    }
    card.append(heading, members, form, roster, assignments);
    list.append(card);
  });
  if (!workspace.classes?.length) {
    const empty = document.createElement("p");
    empty.className = "workspace-empty";
    empty.append(
      document.createTextNode(`${translate("task_no_classes", "Dar neturi klasės. Sukurk pirmąją aukščiau.")} `),
      createActionLink("#create-class-form", translate("task_create_class_link", "Sukurti klasę →")),
    );
    list.append(empty);
  }
}

function renderTeacherAnalytics(assignment, analytics) {
  const details = document.createElement("details");
  details.className = "workspace-task-analytics";
  const summary = document.createElement("summary");
  summary.textContent = translate("task_analytics_heading", "Pažangos suvestinė");
  details.append(summary);
  if (analytics.submitted_count) {
    const average = document.createElement("p");
    average.textContent = translate("task_average_score", "Klasės vidurkis: {score}%", {
      score: analytics.average_percent ?? 0,
    });
    details.append(average);
    const questionsTitle = document.createElement("strong");
    questionsTitle.textContent = translate("task_hardest_questions", "Sunkiausi klausimai pagal klasės atsakymus");
    details.append(questionsTitle);
    const questions = document.createElement("ol");
    (analytics.question_stats || []).filter((question) => question.response_count > 0).slice(0, 3).forEach((question) => {
      const item = document.createElement("li");
      item.className = "workspace-task-analytics-question";
      item.textContent = `${question.prompt} · ${translate("task_question_correct_rate", "Teisingai atsakė {correct}/{total} ({percent}%)", {
        correct: question.correct_count,
        total: question.response_count,
        percent: question.correct_percent ?? 0,
      })}`;
      questions.append(item);
    });
    details.append(questions);
  } else {
    const empty = document.createElement("p");
    empty.textContent = translate("task_no_scores", "Dar nėra pateiktų atsakymų.");
    details.append(empty);
  }
  (analytics.students || []).filter((student) => student.submitted_at).forEach((student) => {
    details.append(createTeacherFeedbackForm(assignment.id, student));
  });
  return details;
}

function createTeacherFeedbackForm(assignmentId, student) {
  const form = document.createElement("form");
  form.className = "workspace-task-feedback-form";
  const label = document.createElement("label");
  label.textContent = `${translate("task_feedback_label", "Asmeninė pastaba mokiniui")} · @${student.username}`;
  const textarea = document.createElement("textarea");
  textarea.maxLength = 1000;
  textarea.value = student.feedback || "";
  textarea.placeholder = translate("task_feedback_placeholder", "Trumpas patarimas apie šią užduotį");
  label.append(textarea);
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = "workspace-secondary-button";
  submit.textContent = translate("task_feedback_save", "Išsaugoti pastabą");
  const message = document.createElement("p");
  message.className = "workspace-status";
  message.setAttribute("role", "status");
  form.append(label, submit, message);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    submit.disabled = true;
    try {
      const { saveTeacherAssignmentFeedback } = await import("./progress.js");
      await saveTeacherAssignmentFeedback(assignmentId, student.student_id, textarea.value);
      student.feedback = textarea.value.trim();
      setStatus(message, translate(textarea.value.trim() ? "task_feedback_saved" : "task_feedback_clear", textarea.value.trim() ? "Pastaba išsaugota." : "Pastaba pašalinta."));
    } catch (error) {
      console.error("Mokytojo pastabos išsaugoti nepavyko.", error);
      setStatus(message, error.message, true);
    } finally {
      submit.disabled = false;
    }
  });
  return form;
}

function renderInvitations() {
  const list = document.querySelector("#student-invitation-list");
  list.replaceChildren();
  (workspace.invitations || []).forEach((invitation) => {
    const card = document.createElement("article");
    card.className = "workspace-card workspace-invitation";
    const heading = document.createElement("h3");
    heading.textContent = `${invitation.name} · ${invitation.subject}`;
    const detail = document.createElement("p");
    detail.textContent = translate("task_invited_by", "Mokytojas: {name} (@{username})", {
      name: invitation.teacher_name,
      username: invitation.teacher_username,
    });
    const message = document.createElement("p");
    message.className = "workspace-status";
    const accept = document.createElement("button");
    accept.type = "button";
    accept.className = "lesson-practice";
    accept.textContent = translate("task_class_sign_in", "Priimti kvietimą");
    const decline = document.createElement("button");
    decline.type = "button";
    decline.className = "workspace-secondary-button";
    decline.textContent = translate("task_decline_invitation", "Atsisakyti");
    const respond = async (choice) => {
      accept.disabled = true;
      decline.disabled = true;
      try {
        const { respondToTeacherClassInvitation } = await import("./progress.js");
        await respondToTeacherClassInvitation(invitation.classroom_id, choice);
        setStatus(message, choice
          ? translate("task_joined_class", "Prisijungei prie klasės.")
          : translate("task_declined_invitation", "Kvietimo atsisakei."));
        await loadWorkspace();
      } catch (error) {
        console.error("Nepavyko atsakyti į klasės kvietimą.", error);
        setStatus(message, error.message, true);
        accept.disabled = false;
        decline.disabled = false;
      }
    };
    accept.addEventListener("click", () => respond(true));
    decline.addEventListener("click", () => respond(false));
    card.append(heading, detail, accept, decline, message);
    list.append(card);
  });
  if (!(workspace.invitations || []).length) {
    const empty = document.createElement("p");
    empty.className = "workspace-empty";
    empty.textContent = translate("task_no_invitations", "Naujų klasės kvietimų nėra.");
    list.append(empty);
  }
}

function createTaskAttempt(task, { showAnswers = false } = {}) {
  const card = document.createElement("article");
  card.className = "workspace-card workspace-task-card";
  const heading = document.createElement("h3");
  heading.textContent = task.title;
  const instructions = document.createElement("p");
  instructions.textContent = task.instructions || translate("task_question_count", "{n} klausimai", { n: task.questions.length });
  const state = document.createElement("p");
  state.className = `workspace-task-state${task.submitted_at ? " is-submitted" : ""}`;
  state.setAttribute("role", "status");
  state.textContent = taskStateLabel(task, showAnswers);
  card.append(heading, instructions, state);
  const form = document.createElement("form");
  form.className = "workspace-task-attempt";
  const answerControls = Array(task.questions.length);
  const completionLabel = document.createElement("p");
  completionLabel.className = "workspace-task-completion-label";
  completionLabel.setAttribute("aria-live", "polite");
  const completion = document.createElement("progress");
  completion.className = "workspace-task-completion";
  completion.max = task.questions.length;
  const updateCompletion = () => {
    const answeredCount = answerControls.filter((control) =>
      control?.querySelector?.("input:checked") || (control instanceof HTMLInputElement && control.value.trim()),
    ).length;
    completion.value = task.submitted_at ? task.questions.length : answeredCount;
    completionLabel.textContent = task.submitted_at
      ? `Pateikta: ${task.score ?? 0}/${task.total ?? task.questions.length} · atsakyta ${task.questions.length}/${task.questions.length}`
      : `Atsakyta ${answeredCount}/${task.questions.length} klausimų`;
    completion.setAttribute("aria-label", completionLabel.textContent);
  };
  let attemptLayout = attemptLayouts.get(task.id);
  if (!attemptLayout || attemptLayout.questionOrder.length !== task.questions.length) {
    attemptLayout = {
      questionOrder: task.shuffle_questions && !showAnswers
        ? shuffledIndices(task.questions.length)
        : Array.from({ length: task.questions.length }, (_, index) => index),
      answerOrders: task.questions.map((question) => task.shuffle_questions && !showAnswers && question.type === "multiple_choice"
        ? shuffledIndices((question.answers || []).length)
        : Array.from({ length: (question.answers || []).length }, (_, index) => index)),
    };
    attemptLayouts.set(task.id, attemptLayout);
  }
  const questionOrder = attemptLayout.questionOrder;

  questionOrder.forEach((questionIndex) => {
    const question = task.questions[questionIndex];
    const fieldset = document.createElement("fieldset");
    fieldset.className = "workspace-task-question";
    const legend = document.createElement("legend");
    legend.textContent = `${questionIndex + 1}. ${question.prompt}`;
    fieldset.append(legend);
    let control;
    if (question.type === "multiple_choice") {
      control = document.createElement("div");
      control.className = "workspace-task-options";
      const answerOrder = attemptLayout.answerOrders[questionIndex];
      answerOrder.forEach((answerIndex) => {
        const answer = question.answers[answerIndex];
        const label = document.createElement("label");
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = `task-${task.id}-question-${questionIndex}`;
        radio.value = String(answerIndex);
        radio.required = true;
        label.append(radio, document.createTextNode(answer));
        control.append(label);
      });
    } else if (question.type === "true_false") {
      control = document.createElement("div");
      control.className = "workspace-task-options";
      [["true", translate("task_true", "Tiesa")], ["false", translate("task_false", "Netiesa")]].forEach(([value, labelText]) => {
        const label = document.createElement("label");
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = `task-${task.id}-question-${questionIndex}`;
        radio.value = value;
        radio.required = true;
        label.append(radio, document.createTextNode(labelText));
        control.append(label);
      });
    } else {
      control = createInput({
        placeholder: question.type === "fill_blank"
          ? translate("task_fill_answer", "Įrašyk trūkstamą žodį ar skaičių")
          : translate("task_your_answer", "Tavo atsakymas"),
        maxlength: 240,
      });
      control.required = true;
    }
    answerControls[questionIndex] = control;
    fieldset.append(control);
    form.append(fieldset);
  });
  form.addEventListener("input", updateCompletion);
  form.addEventListener("change", updateCompletion);

  const result = document.createElement("p");
  result.className = "workspace-status";
  result.setAttribute("role", "status");
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = "lesson-practice";
  submit.textContent = showAnswers
    ? translate("task_check_answers", "Patikrinti savo atsakymus →")
    : task.submitted_at
      ? translate("task_update_answer", "Atnaujinti atsakymą →")
      : translate("task_submit", "Pateikti užduotį →");
  form.append(submit, result);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    submit.disabled = true;
    try {
      if (showAnswers) {
        const score = answerControls.reduce((total, control, index) => {
          const question = task.questions[index];
          let answer;
          if (question.type === "multiple_choice") answer = Number(control.querySelector("input:checked").value);
          else if (question.type === "true_false") answer = control.querySelector("input:checked").value === "true";
          else answer = control.value.trim();
          return total + Number(isAnswerCorrect(question, answer));
        }, 0);
        setStatus(result, translate("task_your_score", "Tavo rezultatas: {score} iš {total}.", { score, total: task.questions.length }));
        submit.textContent = translate("task_checked", "Patikrinta ✓");
        return;
      }
      const answers = answerControls.map((control, index) => {
        const type = task.questions[index].type;
        if (type === "multiple_choice") return Number(control.querySelector("input:checked").value);
        if (type === "true_false") return control.querySelector("input:checked").value === "true";
        return control.value.trim();
      });
      const { submitTeacherAssignment } = await import("./progress.js");
      const score = await submitTeacherAssignment(task.id, answers);
      task.submitted_at = new Date().toISOString();
      task.score = score.score;
      task.total = score.total;
      updateCompletion();
      state.classList.add("is-submitted");
      state.textContent = taskStateLabel(task, false);
      setStatus(result, translate("task_submitted_score", "Užduotis pateikta ir automatiškai įvertinta: {score} iš {total}.", score));
      submit.textContent = translate("task_submitted", "Pateikta ✓");
      submit.disabled = true;
      if (!showAnswers && !card.querySelector(".workspace-task-review")) {
        card.append(createWrongAnswerReview(task));
      }
      await loadWorkspace();
    } catch (error) {
      console.error("Nepavyko pateikti užduoties.", error);
      setStatus(result, error.message, true);
      submit.disabled = false;
    }
  });
  updateCompletion();
  card.append(completionLabel, completion, form);
  if (!showAnswers && task.submitted_at) card.append(createWrongAnswerReview(task));
  return card;
}

function formatTaskAnswer(question, answer) {
  if (question.type === "multiple_choice") return question.answers?.[Number(answer)] || "—";
  if (question.type === "true_false") return translate(answer ? "task_true" : "task_false", answer ? "Tiesa" : "Netiesa");
  return String(answer ?? "—");
}

function createWrongAnswerReview(task) {
  const section = document.createElement("section");
  section.className = "workspace-task-review";
  const button = document.createElement("button");
  button.type = "button";
  button.className = "workspace-secondary-button";
  button.textContent = translate("task_review_mistakes", "Pakartoti klaidingus atsakymus");
  const result = document.createElement("div");
  result.className = "workspace-status";
  result.setAttribute("role", "status");
  section.append(button, result);
  button.addEventListener("click", async () => {
    button.disabled = true;
    setStatus(result, translate("task_review_loading", "Įkeliu klaidingus atsakymus…"));
    try {
      const { getMyAssignmentReview } = await import("./progress.js");
      const mistakes = await getMyAssignmentReview(task.id);
      if (!mistakes.length) {
        section.querySelector(".workspace-task-review-attempt")?.remove();
        setStatus(result, translate("task_review_empty", "Puikiai! Šioje užduotyje klaidų nėra."));
        return;
      }

      const form = document.createElement("form");
      form.className = "workspace-task-review-attempt";
      mistakes.forEach((mistake, index) => {
        const { question, answer } = mistake;
        const item = document.createElement("article");
        item.className = "workspace-task-review-item";
        const heading = document.createElement("strong");
        heading.textContent = `${translate("task_review_item", "Klausimas {n}", { n: mistake.index + 1 })}: ${question.prompt}`;
        const previous = document.createElement("p");
        previous.textContent = `${translate("task_review_your_answer", "Tavo atsakymas")}: ${formatTaskAnswer(question, answer)}`;
        const correct = document.createElement("p");
        const correctAnswer = question.type === "multiple_choice"
          ? question.answers?.[Number(question.correct)]
          : question.type === "true_false"
            ? translate(question.correct ? "task_true" : "task_false", question.correct ? "Tiesa" : "Netiesa")
            : (question.acceptable_answers || []).join(" / ");
        correct.textContent = `${translate("task_review_correct_answer", "Teisingas atsakymas")}: ${correctAnswer || "—"}`;
        item.append(heading, previous, correct);

        if (question.type === "multiple_choice") {
          const options = document.createElement("div");
          options.className = "workspace-task-options";
          question.answers.forEach((choice, choiceIndex) => {
            const label = document.createElement("label");
            const radio = document.createElement("input");
            radio.type = "radio";
            radio.name = `review-${index}`;
            radio.value = String(choiceIndex);
            radio.required = true;
            label.append(radio, document.createTextNode(choice));
            options.append(label);
          });
          item.append(options);
        } else if (question.type === "true_false") {
          const options = document.createElement("div");
          options.className = "workspace-task-options";
          [["true", translate("task_true", "Tiesa")], ["false", translate("task_false", "Netiesa")]].forEach(([value, labelText]) => {
            const label = document.createElement("label");
            const radio = document.createElement("input");
            radio.type = "radio";
            radio.name = `review-${index}`;
            radio.value = value;
            radio.required = true;
            label.append(radio, document.createTextNode(labelText));
            options.append(label);
          });
          item.append(options);
        } else {
          const input = createInput({ name: `review-${index}`, placeholder: translate("task_your_answer", "Tavo atsakymas") });
          input.required = true;
          item.append(input);
        }
        form.append(item);
      });

      const check = document.createElement("button");
      check.type = "submit";
      check.className = "workspace-secondary-button";
      check.textContent = translate("task_review_start", "Pradėti kartojimą");
      form.append(check);
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const score = mistakes.reduce((total, mistake, index) => {
          const question = mistake.question;
          let answer;
          if (question.type === "multiple_choice") answer = Number(form.querySelector(`[name="review-${index}"]:checked`).value);
          else if (question.type === "true_false") answer = form.querySelector(`[name="review-${index}"]:checked`).value === "true";
          else answer = form.elements[`review-${index}`].value.trim();
          return total + Number(isAnswerCorrect(question, answer));
        }, 0);
        setStatus(result, translate("task_review_done", "Kartojimas baigtas. Rezultatas: {score}/{total}.", {
          score,
          total: mistakes.length,
        }));
        check.textContent = translate("task_review_retry", "Dar kartą peržiūrėti klaidas");
      });
      section.querySelector(".workspace-task-review-attempt")?.remove();
      section.append(form);
      setStatus(result, "");
    } catch (error) {
      console.error("Klaidingų atsakymų įkelti nepavyko.", error);
      setStatus(result, error.message, true);
    } finally {
      button.disabled = false;
    }
  });
  return section;
}

function createActionLink(href, label) {
  const link = document.createElement("a");
  link.href = href;
  link.className = "workspace-action-link";
  link.textContent = label;
  return link;
}

function taskStateLabel(task, isOwned) {
  if (isOwned) return translate("task_preview_status", "Tavo peržiūros rinkinys · atsakymai tikrinami šiame puslapyje.");
  const dueDate = task.due_date ? new Date(`${task.due_date}T00:00:00`) : null;
  const dueLabel = dueDate
    ? translate("task_due_date", "Atlikti iki {date}", {
      date: new Intl.DateTimeFormat(document.documentElement.lang || "lt").format(dueDate),
    })
    : "";
  if (task.submitted_at) {
    const submittedDate = new Intl.DateTimeFormat(document.documentElement.lang || "lt").format(new Date(task.submitted_at));
    const result = Number.isFinite(Number(task.score)) && Number.isFinite(Number(task.total))
      ? translate("task_score_short", "Rezultatas: {score}/{total}", { score: task.score, total: task.total })
      : "";
    return [
      translate("task_submitted_status", "Pateikta · automatiškai įvertinta"),
      result,
      translate("task_submitted_at", "Pateikta {date}", { date: submittedDate }),
      translate("task_resubmit_note", "Gali pateikti dar kartą – naujas rezultatas pakeis ankstesnį."),
      dueLabel,
    ].filter(Boolean).join(" · ");
  }
  if (dueDate && dueDate < new Date(new Date().toDateString())) {
    return [translate("task_overdue_status", "Terminas praėjęs · vis tiek gali pateikti"), dueLabel].filter(Boolean).join(" · ");
  }
  return [translate("task_not_submitted", "Nepateikta"), dueLabel].filter(Boolean).join(" · ");
}

function createShareForm(task) {
  const form = document.createElement("form");
  form.className = "workspace-inline-form workspace-share-form";
  const usernames = document.createElement("input");
  usernames.type = "text";
  usernames.required = true;
  usernames.maxLength = 300;
  usernames.placeholder = "@mokytojas, @draugas";
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = "workspace-secondary-button";
  submit.textContent = translate("task_share_button", "Atsiųsti užduotį");
  const message = document.createElement("p");
  message.className = "workspace-status";
  message.setAttribute("role", "status");
  form.append(createField(translate("task_share_by_username", "Atsiųsti pagal @username"), usernames), submit, message);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    submit.disabled = true;
    try {
      const { shareLearningTask } = await import("./progress.js");
      const names = usernames.value.split(/[,\s]+/).map((value) => value.trim()).filter(Boolean);
      const results = await shareLearningTask(task.id, names);
      const statusKeys = {
        shared: ["task_shared", "atsiųsta"],
        already_shared: ["task_already_shared", "jau atsiųsta"],
        not_found: ["task_share_not_found", "vartotojas nerastas arba profilis privatus"],
        invalid: ["task_invalid_username", "netinkamas @username"],
      };
      setStatus(message, results.map((item) => {
        const [key, fallback] = statusKeys[item.status] || ["task_action_failed", "nepavyko"];
        return `@${item.username}: ${translate(key, fallback)}`;
      }).join(" · "));
      usernames.value = "";
      await loadMyTasks();
    } catch (error) {
      console.error("Nepavyko atsiųsti užduoties.", error);
      setStatus(message, error.message, true);
    } finally {
      submit.disabled = false;
    }
  });
  return form;
}

const visibilityLabels = { private: "Tik man", public: "Vieša" };

function renderTaskReminders(assignments) {
  taskReminders.replaceChildren();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() + 3);
  const dueTasks = assignments.filter((task) => {
    if (task.submitted_at || !task.due_date) return false;
    return new Date(`${task.due_date}T00:00:00`) <= cutoff;
  });
  if (!dueTasks.length) {
    taskReminders.hidden = true;
    return;
  }
  const heading = document.createElement("h3");
  heading.textContent = translate("task_reminder_title", "Artėjantys ir pradelsti darbai");
  const list = document.createElement("ul");
  dueTasks.forEach((task) => {
    const item = document.createElement("li");
    const dueDate = new Date(`${task.due_date}T00:00:00`);
    const date = new Intl.DateTimeFormat(document.documentElement.lang || "lt").format(dueDate);
    const isOverdue = dueDate < today;
    item.textContent = translate(isOverdue ? "task_reminder_overdue" : "task_reminder_due", isOverdue
      ? "„{title}“ – terminas praėjo ({date}), bet vis dar gali pateikti"
      : "„{title}“ – terminas {date}", { title: task.title, date });
    list.append(item);
  });
  taskReminders.append(heading, list);
  taskReminders.hidden = false;
}

function applyTaskFilters() {
  [
    ["mine", document.querySelector("#my-task-list")],
    ["available", document.querySelector("#available-task-list")],
    ["assigned", document.querySelector("#assigned-task-list")],
  ].forEach(([name, list]) => {
    if (!list) return;
    list.querySelector(".workspace-filter-empty")?.remove();
    const search = document.querySelector(`[data-task-search="${name}"]`)?.value.trim().toLocaleLowerCase() || "";
    const state = document.querySelector(`[data-task-state-filter="${name}"]`)?.value || "all";
    const className = document.querySelector(`[data-task-class-filter="${name}"]`)?.value || "all";
    const subject = document.querySelector(`[data-task-subject-filter="${name}"]`)?.value || "all";
    const cards = [...list.querySelectorAll(".workspace-task-card")];
    let visibleCount = 0;
    cards.forEach((card) => {
      const matchesSearch = !search || card.dataset.searchText.includes(search);
      const matchesState = state === "all"
        || (state === "pending" && card.dataset.submitted !== "true")
        || (state === "submitted" && card.dataset.submitted === "true");
      const matchesClass = className === "all" || card.dataset.className === className;
      const matchesSubject = subject === "all" || card.dataset.subject === subject;
      card.hidden = !matchesSearch || !matchesState || !matchesClass || !matchesSubject;
      if (!card.hidden) visibleCount += 1;
    });
    if (cards.length && !visibleCount) {
      const empty = document.createElement("p");
      empty.className = "workspace-empty workspace-filter-empty";
      empty.textContent = translate("task_search_empty", "Pagal šiuos filtrus užduočių nerasta.");
      list.append(empty);
    }
  });
}

function renderTasks() {
  renderTaskReminders(workspace.assignments || []);
  const ownList = document.querySelector("#my-task-list");
  ownList.replaceChildren();
  const myTasks = workspace.my_tasks || [];
  myTasks.forEach((task) => {
    const card = createTaskAttempt(task, { showAnswers: true });
    card.dataset.searchText = [task.title, task.instructions].filter(Boolean).join(" ").toLocaleLowerCase();
    card.dataset.submitted = String(Boolean(task.submitted_at));
    const detail = document.createElement("p");
    detail.className = "workspace-task-meta";
    const shared = task.shared_with?.length ? ` · atsiųsta: ${task.shared_with.map((name) => `@${name}`).join(", ")}` : "";
    const results = task.submissions?.length
      ? ` · ${translate("task_results_label", "rezultatai")}: ${task.submissions.map((item) => `@${item.username} ${item.score}/${item.total}`).join(", ")}`
      : "";
    detail.textContent = `${translate(task.visibility === "public" ? "task_visibility_public_short" : "task_visibility_private_short", visibilityLabels[task.visibility] || visibilityLabels.private)}${shared}${results}`;
    card.insertBefore(detail, card.querySelector("form"));
    const copy = document.createElement("button");
    copy.type = "button";
    copy.className = "workspace-secondary-button";
    copy.textContent = translate("task_copy_button", "Kopijuoti į redaktorių");
    copy.addEventListener("click", () => copyTaskToEditor(task));
    card.insertBefore(copy, card.querySelector("form"));
    card.append(createShareForm(task));
    ownList.append(card);
  });
  if (!myTasks.length) {
    const empty = document.createElement("p");
    empty.className = "workspace-empty";
    if (workspace.my_tasks?.length) empty.textContent = translate("task_search_empty", "Pagal šiuos filtrus užduočių nerasta.");
    else empty.append(
        document.createTextNode(`${translate("task_no_own_tasks", "Dar nesukūrei savo užduočių rinkinio.")} `),
        createActionLink("#learning-task-form", translate("task_create_first", "Sukurti pirmą užduotį →")),
      );
    ownList.append(empty);
  }

  const availableList = document.querySelector("#available-task-list");
  availableList.replaceChildren();
  const availableTasks = progress.account_type === "teacher"
    ? (workspace.available_tasks || []).filter((task) => task.source === "shared")
    : workspace.available_tasks || [];
  availableTasks.forEach((task) => {
    const card = createTaskAttempt(task);
    card.dataset.searchText = [task.title, task.instructions, task.author_name].filter(Boolean).join(" ").toLocaleLowerCase();
    card.dataset.submitted = String(Boolean(task.submitted_at));
    const detail = document.createElement("p");
    detail.className = "workspace-task-meta";
    detail.textContent = `${translate(task.source === "shared" ? "task_source_shared" : "task_source_public", task.source === "shared" ? "Atsiųsta tau" : "Vieša užduotis")} · ${task.author_name} (@${task.author_username})${task.submitted_at ? ` · ${translate("task_previous_score", "ankstesnis rezultatas")} ${task.score}/${task.total}` : ""}`;
    card.insertBefore(detail, card.querySelector("form"));
    availableList.append(card);
  });
  if (!availableTasks.length) {
    const empty = document.createElement("p");
    empty.className = "workspace-empty";
    empty.textContent = progress.account_type === "teacher"
      ? translate("task_no_student_shares", "Mokiniai tau dar neatsiuntė užduočių.")
      : translate("task_no_available", "Viešų ar tau atsiųstų užduočių kol kas nėra.");
    if (progress.account_type === "student") {
      empty.append(" ", createActionLink("#learning-task-form", translate("task_create_first", "Sukurti pirmą užduotį →")));
    }
    availableList.append(empty);
  }

  const assignedList = document.querySelector("#assigned-task-list");
  assignedList.replaceChildren();
  const assignments = workspace.assignments || [];
  const classFilter = document.querySelector('[data-task-class-filter="assigned"]');
  const subjectFilter = document.querySelector('[data-task-subject-filter="assigned"]');
  const restoreFilter = (select, values, label) => {
    const selected = select.value;
    select.replaceChildren(new Option(label, "all"));
    [...new Set(values.filter(Boolean))].sort().forEach((value) => select.add(new Option(value, value)));
    if ([...select.options].some((option) => option.value === selected)) select.value = selected;
  };
  restoreFilter(classFilter, assignments.map((task) => task.class_name), "Visos klasės");
  restoreFilter(subjectFilter, assignments.map((task) => task.subject), "Visi dalykai");
  assignments.forEach((task) => {
    const card = createTaskAttempt(task);
    card.dataset.searchText = [task.title, task.instructions, task.class_name, task.subject, task.teacher_name].filter(Boolean).join(" ").toLocaleLowerCase();
    card.dataset.submitted = String(Boolean(task.submitted_at));
    card.dataset.className = task.class_name || "";
    card.dataset.subject = task.subject || "";
    const detail = document.createElement("p");
    detail.className = "workspace-task-meta";
    detail.textContent = `${task.class_name} · ${task.subject} · ${task.teacher_name}${task.submitted_at ? ` · ${translate("task_previous_score", "ankstesnis rezultatas")} ${task.score}/${task.total}` : ""}`;
    card.insertBefore(detail, card.querySelector("form"));
    const feedback = studentFeedback.get(task.id);
    const feedbackMessage = document.createElement("p");
    feedbackMessage.className = "workspace-task-feedback";
    feedbackMessage.textContent = feedback
      ? `${translate("task_feedback_note", "Mokytojo pastaba")}: ${feedback.feedback}`
      : translate("task_feedback_empty", "Mokytojas dar nepaliko asmeninės pastabos.");
    if (task.submitted_at) card.append(feedbackMessage);
    assignedList.append(card);
  });
  if (!(workspace.assignments || []).length) {
    const empty = document.createElement("p");
    empty.className = "workspace-empty";
    empty.textContent = translate("task_no_assigned", "Šiuo metu tau nepaskirta užduočių.");
    assignedList.append(empty);
  }
  applyTaskFilters();
}

function copyTaskToEditor(task) {
  restoringDraft = true;
  taskForm.elements.title.value = `${task.title.slice(0, 112)} (kopija)`;
  taskForm.elements.instructions.value = task.instructions || "";
  visibilitySelect.value = ["private", "public"].includes(task.visibility) ? task.visibility : "private";
  classSelect.value = "";
  taskForm.elements.due_date.value = "";
  taskForm.elements.shuffle_questions.checked = Boolean(task.shuffle_questions);
  populateQuestionEditors(task.questions || []);
  updateVisibilityFields();
  restoringDraft = false;
  taskPreview.replaceChildren();
  taskPreview.hidden = true;
  setStatus(taskStatus, translate("task_copy_loaded", "Užduoties kopija įkelta į redaktorių. Išsaugok kaip naują projektą."));
  saveTaskDraft();
  taskForm.scrollIntoView({ behavior: document.documentElement.dataset.reducedMotion === "true" ? "auto" : "smooth", block: "start" });
  taskForm.elements.title.focus({ preventScroll: true });
}

function captureFormValues(container) {
  return [...container.querySelectorAll("form")].map((form) =>
    [...form.elements].map((control) => ({
      value: control.value,
      checked: control.type === "radio" || control.type === "checkbox" ? control.checked : undefined,
    })),
  );
}

function serializeQuestionEditors() {
  return [...questionBuilders.children].map((editor) => ({
    type: editor.querySelector("[data-question-type]").value,
    prompt: editor.querySelector("[data-question-prompt]").value,
    answers: [...editor.querySelectorAll("[data-question-answer]")].map((answer) => answer.value),
    correct: editor.querySelector("[data-question-correct]")?.value,
    acceptable_answers: editor.querySelector("[data-acceptable-answers]")?.value,
  }));
}

function populateQuestionEditors(questions) {
  questionBuilders.replaceChildren();
  questions.forEach((question) => {
    const type = questionTypes.some(([value]) => value === question.type) ? question.type : "multiple_choice";
    const editor = createQuestionEditor();
    const typeControl = editor.querySelector("[data-question-type]");
    typeControl.value = type;
    typeControl.dispatchEvent(new Event("change"));
    editor.querySelector("[data-question-prompt]").value = String(question.prompt || "");
    editor.querySelectorAll("[data-question-answer]").forEach((answer, index) => {
      answer.value = String(question.answers?.[index] || "");
    });
    const correct = editor.querySelector("[data-question-correct]");
    if (correct && question.correct !== undefined) correct.value = String(question.correct);
    const acceptableAnswers = editor.querySelector("[data-acceptable-answers]");
    if (acceptableAnswers) {
      acceptableAnswers.value = Array.isArray(question.acceptable_answers)
        ? question.acceptable_answers.join("\n")
        : String(question.acceptable_answers || "");
    }
    questionBuilders.append(editor);
  });
  if (!questionBuilders.children.length) questionBuilders.append(createQuestionEditor());
  renumberQuestionEditors();
}

function taskDraftStorageKey() {
  return draftOwnerId ? `testavimai-task-draft-${draftOwnerId}` : "";
}

function saveTaskDraft() {
  const key = taskDraftStorageKey();
  if (!key || restoringDraft) return;
  const draft = {
    title: taskForm.elements.title.value,
    instructions: taskForm.elements.instructions.value,
    visibility: visibilitySelect.value,
    classroom_id: classSelect.value,
    due_date: taskForm.elements.due_date.value,
    shuffle_questions: taskForm.elements.shuffle_questions.checked,
    questions: serializeQuestionEditors(),
    saved_at: new Date().toISOString(),
  };
  try {
    localStorage.setItem(key, JSON.stringify(draft));
    setStatus(taskDraftStatus, translate("task_draft_saved", "Juodraštis automatiškai išsaugotas šiame įrenginyje."));
  } catch (error) {
    console.error("Užduoties juodraščio išsaugoti nepavyko.", error);
    setStatus(taskDraftStatus, translate("task_draft_save_failed", "Juodraščio išsaugoti nepavyko. Patikrink naršyklės saugyklą."), true);
  }
}

function scheduleTaskDraftSave() {
  if (restoringDraft) return;
  window.clearTimeout(draftSaveTimer);
  draftSaveTimer = window.setTimeout(saveTaskDraft, 350);
}

function restoreTaskDraft() {
  const key = taskDraftStorageKey();
  if (!key) return;
  let saved;
  try {
    const value = localStorage.getItem(key);
    if (!value) return;
    saved = JSON.parse(value);
    if (!saved || typeof saved !== "object" || !Array.isArray(saved.questions)) {
      throw new Error("Juodraščio duomenų formatas netinkamas.");
    }
  } catch (error) {
    console.error("Užduoties juodraščio atkurti nepavyko.", error);
    setStatus(taskDraftStatus, translate("task_draft_restore_failed", "Nepavyko atkurti užduoties juodraščio. Sukurk naują užduotį arba patikrink naršyklės saugyklą."), true);
    return;
  }
  restoringDraft = true;
  taskForm.elements.title.value = String(saved.title || "");
  taskForm.elements.instructions.value = String(saved.instructions || "");
  visibilitySelect.value = ["private", "public", "class"].includes(saved.visibility) ? saved.visibility : "private";
  classSelect.value = String(saved.classroom_id || "");
  taskForm.elements.due_date.value = String(saved.due_date || "");
  taskForm.elements.shuffle_questions.checked = Boolean(saved.shuffle_questions);
  populateQuestionEditors(saved.questions);
  updateVisibilityFields();
  restoringDraft = false;
  setStatus(taskDraftStatus, translate("task_draft_restored", "Atkūriau šiame įrenginyje išsaugotą juodraštį."));
  updateTaskCreationLimits();
}

function clearTaskDraft() {
  const key = taskDraftStorageKey();
  if (!key) return;
  try {
    localStorage.removeItem(key);
    setStatus(taskDraftStatus, "");
  } catch (error) {
    console.error("Išsaugoto užduoties juodraščio pašalinti nepavyko.", error);
    setStatus(taskDraftStatus, translate("task_draft_clear_failed", "Juodraščio pašalinti nepavyko."), true);
  }
}

function restoreFormValues(container, savedForms) {
  [...container.querySelectorAll("form")].forEach((form, formIndex) => {
    const savedControls = savedForms[formIndex];
    if (!savedControls) return;
    [...form.elements].forEach((control, controlIndex) => {
      const saved = savedControls[controlIndex];
      if (!saved) return;
      if (saved.checked !== undefined) control.checked = saved.checked;
      else if (control.type !== "submit" && control.type !== "button") control.value = saved.value;
    });
  });
}

function refreshQuestionEditors() {
  populateQuestionEditors(serializeQuestionEditors());
}

async function loadWorkspace() {
  const {
    getMyTeacherWorkspace,
    getMyLearningTasks,
    getAvailableLearningTasks,
    getMyTaskCreationUsage,
    getMyTaskDeliverySettings,
    getMyTeacherAssignmentAnalytics,
    getMyAssignmentFeedback,
  } = await import("./progress.js");
  const insightsPromise = progress.account_type === "teacher"
    ? getMyTeacherAssignmentAnalytics().then((items) => ({ analytics: items, feedback: [] }))
    : getMyAssignmentFeedback().then((items) => ({ analytics: [], feedback: items }));
  const [base, myTasks, availableTasks, usage, deliverySettings, insights] = await Promise.all([
    getMyTeacherWorkspace(),
    getMyLearningTasks(),
    getAvailableLearningTasks(),
    getMyTaskCreationUsage(),
    getMyTaskDeliverySettings(),
    insightsPromise,
  ]);
  creationUsage = usage;
  const deliverySettingsById = new Map(deliverySettings.map((item) => [item.id, Boolean(item.shuffle_questions)]));
  teacherAnalytics = new Map(insights.analytics.map((item) => [item.id, item]));
  studentFeedback = new Map(insights.feedback.map((item) => [item.assignment_id, item]));
  myTasks.forEach((task) => { task.shuffle_questions = deliverySettingsById.get(task.id) || false; });
  availableTasks.forEach((task) => { task.shuffle_questions = deliverySettingsById.get(task.id) || false; });
  (base.assignments || []).forEach((task) => {
    task.shuffle_questions = deliverySettingsById.get(task.id) || false;
  });
  (base.classes || []).forEach((classroom) => {
    (classroom.assignments || []).forEach((assignment) => {
      assignment.analytics = teacherAnalytics.get(assignment.id);
    });
  });
  workspace = { ...base, my_tasks: myTasks, available_tasks: availableTasks };
  renderClassroomOptions();
  renderClassrooms();
  renderInvitations();
  renderTasks();
  updateTaskCreationLimits();
}

async function loadMyTasks() {
  const { getMyLearningTasks } = await import("./progress.js");
  workspace.my_tasks = await getMyLearningTasks();
  renderTasks();
}

function updateTaskCreationLimits() {
  const isPremium = Boolean(creationUsage.is_premium);
  const projectCount = Number(creationUsage.created_projects) || 0;
  const questionCount = questionBuilders.children.length;
  const projectLimitReached = !isPremium && projectCount >= 10;
  const questionLimitReached = !isPremium && questionCount >= 30;
  if (taskCreationLimits) {
    taskCreationLimits.replaceChildren();
    const summary = document.createElement("span");
    summary.textContent = isPremium
      ? translate("task_premium_limits", "Premium · sukurta {projects} projektų · projektų ir klausimų skaičius neribojamas.", { projects: projectCount })
      : translate("task_free_limits", "Nemokamai · sukurta {projects}/10 projektų (liko {remaining}) · {questions}/30 klausimų šiame projekte. Galimi pasirinkimo klausimai.", {
        projects: projectCount,
        remaining: Math.max(0, 10 - projectCount),
        questions: questionCount,
      });
    taskCreationLimits.append(summary);
    if (!isPremium) {
      taskCreationLimits.append(" ", createActionLink("profilis.html#profile-subscriptions", translate("task_premium_link", "Peržiūrėti Premium →")));
    }
  }
  if (questionLimitLabel) {
    questionLimitLabel.textContent = isPremium
      ? translate("task_premium_question_count", "{n} klausimų · neribotai su Premium", { n: questionCount })
      : `${questionCount}/30 klausimų`;
  }
  addQuestionButton.disabled = questionLimitReached || creatingTask;
  taskSubmitButton.disabled = projectLimitReached || creatingTask;
  if (projectLimitReached && taskCreationLimits) {
    taskCreationLimits.querySelector("span").textContent = translate("task_project_limit_reached", "Nemokamas 10 projektų limitas pasiektas.");
  }
}

const aiGenerateButton = document.querySelector("#ai-task-generate");
aiGenerateButton?.addEventListener("click", async () => {
  const status = document.querySelector("#ai-task-status");
  const topic = document.querySelector("#ai-task-topic").value.trim();
  const grade = Number(document.querySelector("#ai-task-grade").value);
  const level = document.querySelector("#ai-task-level").value;
  let count = Number(document.querySelector("#ai-task-count").value);
  if (topic.length < 2) {
    setStatus(status, "Įrašyk temą (bent 2 simboliai).", true);
    return;
  }
  if (!Number.isInteger(count) || count < 1 || count > 50) {
    setStatus(status, "Pasirink nuo 1 iki 50 klausimų.", true);
    return;
  }
  const existing = questionBuilders.children.length && readQuestionEditorsSafe().length;
  if (!creationUsage.is_premium && existing + count > 30) count = Math.max(0, 30 - existing);
  if (!count) {
    setStatus(status, "Nemokamas 30 klausimų limitas pasiektas.", true);
    return;
  }
  aiGenerateButton.disabled = true;
  setStatus(status, "AI kuria klausimus…");
  try {
    const { generateAssessmentQuestions } = await import("./progress.js");
    const generated = await generateAssessmentQuestions({ grade, subject: "kita", topic, count, level });
    const kept = existing ? readQuestionEditorsSafe() : [];
    populateQuestionEditors([...kept, ...generated]);
    if (!taskForm.elements.title.value.trim()) taskForm.elements.title.value = topic.slice(0, 120);
    updateTaskCreationLimits();
    scheduleTaskDraftSave();
    setStatus(status, `Pridėta klausimų: ${generated.length}. Peržiūrėk ir išsaugok užduotį.`);
  } catch (error) {
    console.error("AI klausimų sukurti nepavyko.", error);
    setStatus(status, error.message || "Nepavyko sukurti klausimų.", true);
  } finally {
    aiGenerateButton.disabled = false;
  }
});

function readQuestionEditorsSafe() {
  try {
    return serializeQuestionEditors().filter((question) => String(question.prompt || "").trim());
  } catch {
    return [];
  }
}

addQuestionButton.addEventListener("click", () => {
  if (!creationUsage.is_premium && questionBuilders.children.length >= 30) {
    updateTaskCreationLimits();
    return;
  }
  questionBuilders.append(createQuestionEditor());
  renumberQuestionEditors();
  updateTaskCreationLimits();
  scheduleTaskDraftSave();
});

function handleTaskFormEdit(event) {
  if (taskPreview.contains(event.target)) return;
  taskPreview.replaceChildren();
  taskPreview.hidden = true;
  scheduleTaskDraftSave();
}

taskForm.addEventListener("input", handleTaskFormEdit);
taskForm.addEventListener("change", handleTaskFormEdit);

taskPreviewButton.addEventListener("click", () => {
  if (!taskForm.reportValidity()) return;
  try {
    const questions = readQuestionEditors();
    const task = {
      id: "local-preview",
      title: taskForm.elements.title.value.trim(),
      instructions: taskForm.elements.instructions.value.trim(),
      questions,
      shuffle_questions: false,
    };
    const heading = document.createElement("h3");
    heading.textContent = translate("task_preview_heading", "Užduoties peržiūra");
    taskPreview.replaceChildren(heading, createTaskAttempt(task, { showAnswers: true }));
    taskPreview.hidden = false;
    taskPreview.scrollIntoView({
      behavior: document.documentElement.dataset.reducedMotion === "true" ? "auto" : "smooth",
      block: "nearest",
    });
  } catch (error) {
    console.error("Užduoties peržiūros paruošti nepavyko.", error);
    setStatus(taskStatus, error.message, true);
  }
});

document.querySelector("#discard-task-draft").addEventListener("click", () => {
  window.clearTimeout(draftSaveTimer);
  clearTaskDraft();
  taskForm.reset();
  questionBuilders.replaceChildren(createQuestionEditor());
  taskPreview.replaceChildren();
  taskPreview.hidden = true;
  updateVisibilityFields();
  setStatus(taskDraftStatus, translate("task_draft_cleared", "Išsaugotas juodraštis pašalintas."));
  updateTaskCreationLimits();
});

document.querySelectorAll("[data-task-search], [data-task-state-filter], [data-task-class-filter], [data-task-subject-filter]").forEach((control) => {
  control.addEventListener("input", applyTaskFilters);
  control.addEventListener("change", applyTaskFilters);
});

document.querySelector("#create-class-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = form.querySelector('[type="submit"]');
  submit.disabled = true;
  try {
    const { createTeacherClass } = await import("./progress.js");
    await createTeacherClass({ name: form.elements.name.value, subject: form.elements.subject.value });
    form.reset();
    setStatus(status, translate("task_class_created", "Klasė sukurta. Dabar gali pakviesti mokinius pagal jų @username."));
    await loadWorkspace();
  } catch (error) {
    console.error("Nepavyko sukurti klasės.", error);
    setStatus(status, error.message, true);
  } finally {
    submit.disabled = false;
  }
});

taskForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const questions = readQuestionEditors();
    const projectCount = creationUsage.created_projects;
    if (!creationUsage.is_premium && projectCount >= 10) {
      throw new Error(translate("task_project_limit_error", "Nemokamai galima sukurti iki 10 projektų. Pasirink Premium, kad projektų skaičius būtų neribojamas."));
    }
    if (!creationUsage.is_premium && questions.length > 30) {
      throw new Error(translate("task_question_limit_error", "Nemokamame projekte gali būti iki 30 pasirinkimo klausimų."));
    }
    creatingTask = true;
    updateTaskCreationLimits();
    const { createLearningTask } = await import("./progress.js");
    await createLearningTask({
      classroomId: visibilitySelect.value === "class" ? classSelect.value || null : null,
      visibility: visibilitySelect.value,
      shuffleQuestions: taskForm.elements.shuffle_questions.checked,
      title: taskForm.elements.title.value.trim(),
      instructions: taskForm.elements.instructions.value.trim(),
      dueDate: taskForm.elements.due_date.value || null,
      questions,
    });
    window.clearTimeout(draftSaveTimer);
    taskForm.reset();
    updateVisibilityFields();
    questionBuilders.replaceChildren(createQuestionEditor());
    renumberQuestionEditors();
    clearTaskDraft();
    taskPreview.replaceChildren();
    taskPreview.hidden = true;
    setStatus(taskStatus, translate("task_created_success", "Užduotis išsaugota."));
    await loadWorkspace();
  } catch (error) {
    console.error("Nepavyko sukurti užduoties.", error);
    setStatus(taskStatus, error.message, true);
  } finally {
    creatingTask = false;
    updateTaskCreationLimits();
  }
});

questionBuilders.append(createQuestionEditor());
document.addEventListener("testavimai:language-changed", () => {
  const searchValues = [...document.querySelectorAll("[data-task-search], [data-task-state-filter], [data-task-class-filter], [data-task-subject-filter]")]
    .map((control) => control.value);
  refreshQuestionEditors();
  if (workspace) {
    renderClassroomOptions();
    const formContainers = [
      "#teacher-class-list",
      "#student-invitation-list",
      "#my-task-list",
      "#available-task-list",
      "#assigned-task-list",
    ].map((selector) => document.querySelector(selector));
    const savedForms = formContainers.map(captureFormValues);
    renderClassrooms();
    renderInvitations();
    renderTasks();
    formContainers.forEach((container, index) => restoreFormValues(container, savedForms[index]));
    document.querySelectorAll("[data-task-search], [data-task-state-filter], [data-task-class-filter], [data-task-subject-filter]").forEach((control, index) => {
      control.value = searchValues[index] || control.value;
    });
  }
  taskPreviewButton.textContent = translate("task_preview_button", "Peržiūrėti kaip mokiniui");
  updateTaskCreationLimits();
});

import("./progress.js")
  .then(async (api) => {
    progress = await api.getMyProgress();
    questionBuilders.querySelectorAll("[data-question-type] option").forEach((option) => {
      if (option.dataset.premium === "true") option.disabled = !progress.is_premium;
    });
    if (progress.is_guest) throw new Error(translate("task_sign_in_required", "Užduotims ir klasėms reikia prisijungti prie mokinio arba mokytojo paskyros."));
    if (progress.account_type === "school_admin") {
      throw new Error(translate("task_role_not_allowed", "Užduotis gali kurti tik mokinio arba mokytojo paskyra."));
    }
    if (!["teacher", "student"].includes(progress.account_type)) {
      throw new Error(translate("task_role_unknown", "Profilio tipas nenustatytas. Patikrink paskyros nustatymus."));
    }
    document.querySelector("#teacher-classroom-panel").hidden = progress.account_type !== "teacher";
    document.querySelector("#create-class-form").hidden = progress.account_type !== "teacher";
    draftOwnerId = await api.getCurrentUserId();
    await loadWorkspace();
    restoreTaskDraft();
    const accountLabel = translate(progress.account_type === "teacher" ? "task_teacher_role" : "task_student_role", progress.account_type === "teacher" ? "Mokytojo" : "Mokinio");
    setStatus(status, translate("task_account_connected", "{role} paskyra prijungta{premium}.", {
      role: accountLabel,
      premium: progress.is_premium ? " · Premium" : "",
    }));
    updateTaskCreationLimits();
  })
  .catch((error) => {
    console.error("Nepavyko įkelti užduočių erdvės.", error);
    setStatus(status, error.message, true);
    if (/prisijunk|paskyros/i.test(error.message)) {
      const signIn = document.createElement("a");
      signIn.href = `prisijungimas.html?redirect=${encodeURIComponent("uzduotys.html")}`;
      signIn.className = "tutor-sign-in-link";
      signIn.textContent = translate("task_sign_in_link", "Prisijungti →");
      status.append(" ", signIn);
    }
  });

questionBuilders.addEventListener("click", (event) => {
  if (event.target.closest(".question-remove-button")) scheduleTaskDraftSave();
});
