const blockedProfileTerms = [
  "fuck", "fucking", "shit", "bitch", "bastard", "cunt", "whore", "slut",
  "nigger", "nigga", "retard", "faggot", "kike", "spic", "wetback",
  "pizda", "kurva", "kurwa", "debile", "gaidys", "pyderas", "siknius",
  "sex", "sexy", "seksas", "porno", "porn", "nazi", "nazis", "hitler",
  "isis", "daesh", "alqaeda", "alqaida", "taliban", "hamas",
];

function normalizedProfileText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function hasBlockedProfileContent(value) {
  const normalized = normalizedProfileText(value);
  const compact = normalized.replaceAll(" ", "");
  return blockedProfileTerms.some((term) =>
    normalized.split(" ").includes(term) || (term.length >= 4 && compact.includes(term))
  );
}

export function validateProfileName(value) {
  const name = String(value || "").trim();
  if (!name || name.length > 120) return "Vardas turi būti nuo 1 iki 120 simbolių.";
  if (hasBlockedProfileContent(name)) return "Šis vardas netinkamas viešam profiliui. Pasirink kitą vardą.";
  return "";
}

export function validateProfileBio(value) {
  const bio = String(value || "").trim();
  if (bio.length > 2000) return "Aprašymas negali būti ilgesnis nei 2 000 simbolių.";
  const wordCount = bio ? bio.split(/\s+/).length : 0;
  if (wordCount > 200) return "Aprašymas gali būti iki 200 žodžių.";
  if (hasBlockedProfileContent(bio)) return "Aprašyme yra netinkamo turinio. Jį pataisyk ir bandyk dar kartą.";
  return "";
}
