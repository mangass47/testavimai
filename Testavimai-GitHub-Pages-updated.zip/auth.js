import { SUPABASE_ANON_KEY, SUPABASE_URL } from "./supabase-config.js";
import { validateProfileBio, validateProfileName } from "./profile-policy.js";

const configurationMissing =
  SUPABASE_URL.includes("YOUR-PROJECT") ||
  SUPABASE_ANON_KEY.includes("YOUR_SUPABASE") ||
  !SUPABASE_URL.startsWith("https://") ||
  SUPABASE_ANON_KEY.length < 20;
const authPage = document.body.dataset.page === "auth";
const authStatus = document.querySelector("#auth-status");
const signInForm = document.querySelector("#sign-in-form");
const signUpForm = document.querySelector("#sign-up-form");
const authTabs = [...document.querySelectorAll("[data-auth-tab]")];
const signOutButton = document.querySelector("#sign-out-button");
const profileLink = document.querySelector("#profile-link");
const demoLoginButton = document.querySelector("#demo-login-button");
const passwordInput = document.querySelector("#sign-up-password");
const passwordHint = document.querySelector("#password-hint");
const demoSessionKey = "testavimai-demo-guest";
const signupTrialNoticeKey = "testavimai-signup-trial-notice";
const localDemoMode = ["localhost", "testavimai.localhost", "testavimai.com", "www.testavimai.com", "127.0.0.1", "[::1]"].includes(window.location.hostname);
let supabase;
let returnTo = "index.html";

function safeReturnTo(value) {
  if (!value) return "index.html";
  const url = new URL(value, window.location.href);
  if (url.origin !== window.location.origin) return "index.html";
  if (url.pathname === "/index.html") return `${url.pathname}${url.hash}`;
  if (url.pathname === "/pamokos.html") {
    const subject = url.searchParams.get("dalykas");
    const allowedSubjects = ["matematika", "lietuvių kalba", "biologija", "istorija", "fizika"];
    const search = allowedSubjects.includes(subject) ? `?dalykas=${encodeURIComponent(subject)}` : "";
    const hash = url.hash === "#praktika" ? url.hash : "";
    return `${url.pathname}${search}${hash}`;
  }
  if (url.pathname === "/profilis.html") return `${url.pathname}${url.hash === "#profile-preferences" ? url.hash : ""}`;
  if (url.pathname === "/praktika.html") {
    const subject = url.searchParams.get("dalykas");
    const allowedSubjects = ["matematika", "lietuvių kalba", "biologija", "istorija", "fizika"];
    const practiceViews = ["ai", "assessment", "entrance", "rewards", "achievements", "tips", "weekly", "quick", "daily", "review", "flashcards", "timed"];
    const searchParams = new URLSearchParams();
    if (allowedSubjects.includes(subject)) searchParams.set("dalykas", subject);
    const practiceView = url.searchParams.get("veikla");
    if (practiceViews.includes(practiceView)) searchParams.set("veikla", practiceView);
    const difficulty = url.searchParams.get("sudetingumas");
    if (["easy", "medium", "hard"].includes(difficulty)) searchParams.set("sudetingumas", difficulty);
    const type = url.searchParams.get("tipas");
    if (type === "Pasirinkimas") searchParams.set("tipas", type);
    const search = searchParams.size ? `?${searchParams}` : "";
    const hash = ["#daily-challenge", "#weekly-plan", "#tips", "#dalykai"].includes(url.hash) ? url.hash : "";
    return `${url.pathname}${search}${hash}`;
  }
  if (url.pathname === "/lyderiai.html") return url.pathname;
  if (url.pathname === "/friends.html") return url.pathname;
  if (url.pathname === "/public-profile.html") {
    const profileId = url.searchParams.get("id");
    return profileId && /^[0-9a-f-]{36}$/i.test(profileId)
      ? `${url.pathname}?id=${encodeURIComponent(profileId)}`
      : "index.html";
  }
  if (url.pathname === "/uzduotys.html") return url.pathname;
  if (url.pathname === "/testas.html" && url.searchParams.get("testas") === "1") {
    const subjects = ["lietuvių kalba", "matematika", "istorija", "biologija"];
    const difficulties = ["easy", "medium", "hard"];
    const subject = url.searchParams.get("dalykas");
    const difficulty = url.searchParams.get("difficulty");
    if (difficulties.includes(difficulty) && subjects.includes(subject)) {
      return `${url.pathname}?testas=1&difficulty=${encodeURIComponent(difficulty)}&dalykas=${encodeURIComponent(subject)}#praktika`;
    }
  }
  return "index.html";
}

function setStatus(message, kind = "info") {
  if (!authStatus) return;
  authStatus.textContent = message;
  authStatus.className = `auth-status ${kind}`;
}

function showSignupTrialNotice() {
  if (sessionStorage.getItem(signupTrialNoticeKey) !== "true") return;
  sessionStorage.removeItem(signupTrialNoticeKey);
  const notice = document.createElement("div");
  notice.className = "trial-welcome-notice";
  notice.setAttribute("role", "status");
  notice.setAttribute("aria-live", "polite");
  notice.textContent = "Sveikiname prisijungus! Tavo naujai paskyrai suteiktas 7 dienų nemokamas Premium laikotarpis.";
  document.body.append(notice);
  window.setTimeout(() => notice.remove(), 9000);
}

function passwordIsStrong(password) {
  return password.length >= 12 &&
    /[a-z]/.test(password) &&
    /[A-Z]/.test(password) &&
    /\d/.test(password) &&
    /[^A-Za-z0-9]/.test(password);
}

function showAuthTab(tab) {
  const showSignUp = tab === "signup";
  signInForm.hidden = showSignUp;
  signUpForm.hidden = !showSignUp;
  authTabs.forEach((button) => {
    const active = button.dataset.authTab === tab;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", String(active));
  });
  setStatus("");
}

async function goToReturnTo() {
  window.location.replace(returnTo);
}

function resetGuestLocalData() {
  try {
    localStorage.removeItem("testavimai-demo-profile");
    localStorage.removeItem("testavimai-demo-progress");
    localStorage.removeItem("testavimai-owned-themes");
    localStorage.setItem("testavimai-theme", "forest");
  } catch (error) {
    console.error("Nepavyko paruošti švaraus svečio režimo.", error);
  }
}

function enterGuestMode() {
  resetGuestLocalData();
  sessionStorage.setItem(demoSessionKey, "true");
  goToReturnTo();
}

function initializePasswordToggles() {
  document.querySelectorAll("[data-password-toggle]").forEach((toggle) => {
    toggle.addEventListener("click", () => {
      const input = document.getElementById(toggle.getAttribute("aria-controls"));
      if (!(input instanceof HTMLInputElement)) return;
      const showPassword = input.type === "password";
      input.type = showPassword ? "text" : "password";
      toggle.textContent = showPassword ? "Slėpti" : "Rodyti";
      toggle.setAttribute("aria-label", showPassword ? "Slėpti slaptažodį" : "Rodyti slaptažodį");
      toggle.setAttribute("aria-pressed", String(showPassword));
    });
  });
}

function showGuestSession() {
  resetGuestLocalData();
  document.body.classList.add("guest-mode");
  const userNameElement = document.querySelector("#auth-user-name");
  if (userNameElement) userNameElement.textContent = "Svečias";
  if (profileLink) profileLink.hidden = false;
  if (signOutButton) {
    signOutButton.hidden = false;
    signOutButton.addEventListener("click", () => {
      if (!window.confirm("Ar tikrai norite atsijungti?")) return;
      const currentPage = `${window.location.pathname}${window.location.search}${window.location.hash}`;
      sessionStorage.removeItem(demoSessionKey);
      window.location.replace(`prisijungimas.html?redirect=${encodeURIComponent(currentPage)}`);
    });
  }
  if (document.body.dataset.page === "profile") initializeProfile(null);
  document.documentElement.classList.remove("auth-pending");
}

function setProfileStatus(element, message, kind = "info") {
  element.textContent = message;
  element.className = `profile-status ${kind}`;
}

function initializeProfile(user) {
  const accountForm = document.querySelector("#profile-account-form");
  const passwordForm = document.querySelector("#profile-password-form");
  const accountStatus = document.querySelector("#profile-account-status");
  const passwordStatus = document.querySelector("#profile-password-status");
  const metadata = user?.user_metadata || {};
  const profile = user ? metadata : {};
  const accountContent = document.querySelector("#account-profile-content");
  const guestAccountNotice = document.querySelector("#guest-account-notice");
  const subscriptionContent = document.querySelector("#subscription-content");
  const guestSubscriptionsNotice = document.querySelector("#guest-subscriptions-notice");
  if (accountContent) accountContent.hidden = !user;
  if (guestAccountNotice) guestAccountNotice.hidden = Boolean(user);
  if (subscriptionContent) subscriptionContent.hidden = !user;
  if (guestSubscriptionsNotice) guestSubscriptionsNotice.hidden = Boolean(user);
  if (!user) document.querySelector("#profile-avatar").hidden = true;
  accountForm.elements.first_name.value = profile.first_name || "";
  accountForm.elements.last_name.value = profile.last_name || "";
  accountForm.elements.school.value = profile.school || "";
  accountForm.elements.grade.value = profile.grade || "";
  if (profile.account_type === "teacher") accountForm.elements.grade.closest("label").hidden = true;
  accountForm.elements.email.value = user?.email || "Svečio režimas";
  accountForm.elements.username.value = profile.username ? `@${profile.username}` : "";
  const firstName = profile.first_name || profile.full_name?.split(/\s+/)[0] || (user ? "Mokinys" : "Svečias");
  document.querySelector("#profile-avatar").textContent = firstName.slice(0, 1).toLocaleUpperCase("lt");
  if (!user) {
    accountForm.elements.first_name.value = "Svečias";
    accountForm.elements.last_name.value = "";
    accountForm.querySelectorAll("input, select, textarea, button").forEach((element) => { element.disabled = true; });
    setProfileStatus(accountStatus, "Svečio profilis yra tik laikinas. Susikurk paskyrą, jei nori išsaugoti vardą ir pažangą.");
  }
  document.querySelector("#profile-bio-count")?.replaceChildren(`${accountForm.elements.bio?.value.trim().split(/\s+/).filter(Boolean).length || 0} / 200 žodžių`);

  document.querySelectorAll("[data-profile-tab]").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll("[data-profile-tab]").forEach((item) => {
        const active = item === tab;
        item.classList.toggle("is-active", active);
        item.setAttribute("aria-selected", String(active));
      });
      document.querySelectorAll("[data-profile-panel]").forEach((panel) => {
        panel.hidden = panel.dataset.profilePanel !== tab.dataset.profileTab;
      });
    });
    if (window.location.hash === "#profile-preferences") {
      document.querySelector('[data-profile-tab="preferences"]')?.click();
    }
  });

  accountForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!user) {
      setProfileStatus(accountStatus, "Svečiai negali keisti profilio. Susikurk paskyrą, kad išsaugotum savo informaciją.", "error");
      return;
    }
    const form = new FormData(accountForm);
    const first = String(form.get("first_name")).trim();
    const last = String(form.get("last_name")).trim();
    const school = String(form.get("school")).trim();
    const grade = String(form.get("grade"));
    const username = String(form.get("username")).trim().replace(/^@/, "").toLowerCase();
    const bio = String(form.get("bio") || "").trim();
    const featuredBadgeId = String(form.get("featured_badge_id") || "");
    if (!/^[a-z0-9_]{3,24}$/.test(username) || validateProfileName(username)) {
      setProfileStatus(accountStatus, "Vartotojo vardas turi būti tinkamas, 3–24 simbolių ir sudarytas iš raidžių, skaičių arba pabraukimo.", "error");
      accountForm.elements.username.focus();
      return;
    }
    const updates = {
      first_name: first,
      last_name: last,
      full_name: `${first} ${last}`.trim(),
      school,
      grade,
    };
    const nameError = validateProfileName(updates.full_name);
    const bioError = validateProfileBio(bio);
    if (nameError || bioError) {
      setProfileStatus(accountStatus, nameError || bioError, "error");
      return;
    }
    const button = accountForm.querySelector("[type=submit]");
    button.disabled = true;
    try {
      if (user) {
        const { error: publicProfileError } = await supabase.rpc("update_my_public_profile", {
          p_display_name: updates.full_name || "Mokinys",
          p_avatar_url: document.querySelector("#profile-avatar img")?.src || null,
          p_is_private: document.querySelector("#profile-private-account")?.checked || false,
          p_bio: bio,
          p_featured_badge_id: featuredBadgeId || null,
        });
        if (publicProfileError) throw publicProfileError;
        const { data: savedUsername, error: usernameError } = await supabase.rpc("update_my_username", {
          p_username: username,
        });
        if (usernameError) {
          if (usernameError.code === "23505" || usernameError.message?.includes("Šis vartotojo vardas jau užimtas")) {
            throw new Error("Šis vartotojo vardas jau užimtas. Pasirink kitą.");
          }
          throw usernameError;
        }
        const usernameDisplay = document.querySelector("#profile-username");
        if (usernameDisplay && typeof savedUsername === "string") {
          usernameDisplay.textContent = `@${savedUsername}`;
          usernameDisplay.hidden = false;
        }
        accountForm.elements.username.value = `@${savedUsername}`;
        const { error } = await supabase.auth.updateUser({ data: { ...metadata, ...updates } });
        if (error) throw error;
      }
      const avatar = document.querySelector("#profile-avatar");
      if (!avatar.querySelector("img")) avatar.textContent = first.slice(0, 1).toLocaleUpperCase("lt");
      const profileName = document.querySelector("#auth-user-name");
      if (profileName) profileName.textContent = updates.full_name;
      setProfileStatus(accountStatus, "Paskyros informacija išsaugota.", "success");
    } catch (error) {
      console.error("Nepavyko išsaugoti profilio informacijos.", error);
      setProfileStatus(accountStatus, `Nepavyko išsaugoti: ${error.message}`, "error");
    } finally {
      button.disabled = false;
    }
  });

  passwordForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!user) {
      setProfileStatus(passwordStatus, "Svečio režime slaptažodžio keisti negalima. Susikurk paskyrą arba prisijunk.", "error");
      return;
    }
    const form = new FormData(passwordForm);
    const password = String(form.get("password"));
    if (password !== String(form.get("password_confirmation"))) {
      setProfileStatus(passwordStatus, "Slaptažodžiai nesutampa.", "error");
      return;
    }
    if (!passwordIsStrong(password)) {
      setProfileStatus(passwordStatus, "Slaptažodis neatitinka sudėtingumo reikalavimų.", "error");
      return;
    }
    const button = passwordForm.querySelector("[type=submit]");
    button.disabled = true;
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      passwordForm.reset();
      setProfileStatus(passwordStatus, "Slaptažodis atnaujintas.", "success");
    } catch (error) {
      console.error("Nepavyko atnaujinti slaptažodžio.", error);
      setProfileStatus(passwordStatus, `Nepavyko atnaujinti slaptažodžio: ${error.message}`, "error");
    } finally {
      button.disabled = false;
    }
  });
}

async function configure() {
  showSignupTrialNotice();
  initializePasswordToggles();
  returnTo = safeReturnTo(new URLSearchParams(window.location.search).get("redirect"));

  if (authPage) {
    demoLoginButton.hidden = false;
    demoLoginButton.addEventListener("click", enterGuestMode);
  }

  if (sessionStorage.getItem(demoSessionKey) === "true") {
    if (authPage) {
      await goToReturnTo();
    } else {
      showGuestSession();
    }
    return;
  }

  if (configurationMissing) {
    if (localDemoMode) {
      if (authPage) {
        document.querySelector(".auth-shell").hidden = false;
        document.querySelector(".auth-tabs").hidden = true;
        signInForm.hidden = true;
        signUpForm.hidden = true;
        document.querySelector(".auth-privacy").hidden = true;
        document.querySelector(".auth-back-link").hidden = true;
        document.querySelector("#auth-heading").textContent = "Prisijunk arba tęsk kaip svečias.";
        document.querySelector(".auth-intro > p").textContent = "Prisijungimui el. paštu prijunk Supabase. Kol kas gali išbandyti svetainę kaip svečias.";
        setStatus("Svečių režimas veikia tik šiame kompiuteryje. Tikram prisijungimui reikalinga Supabase konfigūracija.", "info");
        demoLoginButton.textContent = "Tęsti kaip svečiui →";
      } else {
        const currentPage = `${window.location.pathname}${window.location.search}${window.location.hash}`;
        window.location.replace(`prisijungimas.html?setup=1&redirect=${encodeURIComponent(currentPage)}`);
      }
      return;
    }

    if (authPage) {
      document.querySelector(".auth-shell").hidden = false;
      setStatus("Prisijungimas dar nesukonfigūruotas. Įrašyk Supabase projekto URL ir viešą publishable / anon raktą į supabase-config.js, tada atnaujink puslapį.", "error");
      document.querySelectorAll(".auth-shell input, .auth-shell button").forEach((element) => { element.disabled = true; });
    } else {
      window.location.replace(`prisijungimas.html?setup=1&redirect=${encodeURIComponent(`${window.location.pathname}${window.location.search}${window.location.hash}`)}`);
    }
    return;
  }

  let createClient;
  try {
    ({ createClient } = await import("https://esm.sh/@supabase/supabase-js@2"));
  } catch (error) {
    if (authPage) {
      document.querySelector(".auth-shell").hidden = false;
      setStatus("Prisijungimo paslaugos bibliotekos įkėlimas nepavyko. Patikrink interneto ryšį ir atnaujink puslapį.", "error");
    } else {
      window.location.replace(`prisijungimas.html?error=connection&redirect=${encodeURIComponent(`${window.location.pathname}${window.location.search}${window.location.hash}`)}`);
    }
    console.error("Nepavyko įkelti Supabase kliento bibliotekos.", error);
    return;
  }

  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true },
  });

  const { data, error } = await supabase.auth.getSession();
  if (error) {
    if (authPage) {
      document.querySelector(".auth-shell").hidden = false;
      setStatus(`Nepavyko patikrinti prisijungimo: ${error.message}`, "error");
    }
    else window.location.replace(`prisijungimas.html?error=session&redirect=${encodeURIComponent(`${window.location.pathname}${window.location.search}${window.location.hash}`)}`);
    return;
  }

  if (authPage) {
    if (data.session) {
      if (new URLSearchParams(window.location.search).has("signup")) {
        sessionStorage.setItem(signupTrialNoticeKey, "true");
      }
      await goToReturnTo();
      return;
    }
    document.querySelector(".auth-shell").hidden = false;
    if (new URLSearchParams(window.location.search).has("setup")) {
      setStatus("Paskyros kūrimui būtina pirmiausia prijungti Supabase. Žingsniai pateikti README.md faile.", "error");
    } else if (new URLSearchParams(window.location.search).has("error")) {
      setStatus("Nepavyko patikrinti prisijungimo. Patikrink interneto ryšį ir bandyk dar kartą.", "error");
    }
    showAuthTab(new URLSearchParams(window.location.search).get("mode") === "signup" ? "signup" : "signin");
    const accountTypeInput = signUpForm.querySelector('[name="account_type"]');
    const gradeInput = signUpForm.querySelector("#sign-up-grade");
    const gradeLabel = signUpForm.querySelector("#sign-up-grade-label");
    const updateSignupFields = () => {
      const isTeacher = accountTypeInput.value === "teacher";
      gradeInput.required = !isTeacher;
      gradeInput.hidden = isTeacher;
      gradeLabel.hidden = isTeacher;
      if (isTeacher) gradeInput.value = "";
    };
    accountTypeInput.addEventListener("change", updateSignupFields);
    updateSignupFields();

    authTabs.forEach((button) => {
      button.addEventListener("click", () => showAuthTab(button.dataset.authTab));
    });

    passwordInput.addEventListener("input", () => {
      const strong = passwordIsStrong(passwordInput.value);
      passwordHint.classList.toggle("is-valid", strong);
      passwordHint.querySelector("strong").textContent = strong
        ? "Slaptažodis atitinka sudėtingumo reikalavimus."
        : "Reikalavimai: bent 12 simbolių, didžioji ir mažoji raidė, skaičius ir specialusis simbolis.";
    });

    signInForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const submitButton = signInForm.querySelector("[type=submit]");
      submitButton.disabled = true;
      setStatus("Jungiamasi…");
      const form = new FormData(signInForm);
      try {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: String(form.get("email")).trim(),
          password: String(form.get("password")),
        });
        if (signInError) {
          setStatus(`Prisijungti nepavyko: ${signInError.message}`, "error");
          return;
        }
      } catch (signInError) {
        setStatus(`Nepavyko susisiekti su prisijungimo paslauga: ${signInError.message}`, "error");
        return;
      } finally {
        submitButton.disabled = false;
      }
      await goToReturnTo();
    });

    signUpForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = new FormData(signUpForm);
      const password = String(form.get("password"));
      const username = String(form.get("username")).trim().replace(/^@/, "").toLowerCase();
      const accountType = String(form.get("account_type"));
      const firstName = String(form.get("first_name")).trim();
      const lastName = String(form.get("last_name")).trim();
      const school = String(form.get("school")).trim();
      const grade = String(form.get("grade"));
      if (!/^[a-z0-9_]{3,24}$/.test(username) || validateProfileName(username)) {
        setStatus("Vartotojo vardas turi būti tinkamas, 3–24 simbolių ir sudarytas iš raidžių, skaičių arba pabraukimo.", "error");
        document.querySelector("#sign-up-username").focus();
        return;
      }
      const isTeacher = accountType === "teacher";
      if (!["student", "teacher"].includes(accountType)) {
        setStatus("Pasirink paskyros tipą: mokinys arba mokytojas / mokyklos vadovas.", "error");
        return;
      }
      if (!form.get("policy_consent")) {
        setStatus("Prieš kurdamas paskyrą sutik su Naudojimo sąlygomis ir Privatumo politika.", "error");
        return;
      }
      if (!firstName || !lastName || !school ||       (!isTeacher && !["5", "6", "7", "8", "9", "10", "11", "12"].includes(grade))) {
              setStatus(isTeacher ? "Įrašyk vardą, pavardę ir mokyklą." : "Įrašyk vardą, pavardę, dabartinę mokyklą ir pasirink klasę.", "error");
        return;
      }
      const nameError = validateProfileName(`${firstName} ${lastName}`);
      if (nameError) {
        setStatus(nameError, "error");
        return;
      }
      if (!passwordIsStrong(password)) {
        setStatus("Pasirink stipresnį slaptažodį pagal nurodytus reikalavimus.", "error");
        passwordInput.focus();
        return;
      }
      const submitButton = signUpForm.querySelector("[type=submit]");
      submitButton.disabled = true;
      setStatus("Kuriama paskyra…");
      let signUpData;
      let signUpError;
      try {
        ({ data: signUpData, error: signUpError } = await supabase.auth.signUp({
          email: String(form.get("email")).trim(),
          password,
          options: {
            data: {
              first_name: firstName,
              last_name: lastName,
              full_name: `${firstName} ${lastName}`,
              username,
              account_type: accountType,
              school,
              grade,
              terms_version: "2026-10-28",
              privacy_version: "2026-10-28",
            },
            emailRedirectTo: `${window.location.origin}/prisijungimas.html?signup=1&redirect=${encodeURIComponent(returnTo)}`,
          },
        }));
      } catch (error) {
        setStatus(`Nepavyko susisiekti su prisijungimo paslauga: ${error.message}`, "error");
        return;
      } finally {
        submitButton.disabled = false;
      }
      if (signUpError) {
        if (signUpError.code === "23505" || signUpError.message?.includes("public_profiles_username_unique")) {
          setStatus("Šis vartotojo vardas jau užimtas. Pasirink kitą.", "error");
          document.querySelector("#sign-up-username").focus();
          return;
        }
        setStatus(`Paskyros sukurti nepavyko: ${signUpError.message}`, "error");
        return;
      }
      if (signUpData.session) {
        sessionStorage.setItem(signupTrialNoticeKey, "true");
        await goToReturnTo();
        return;
      }
      signUpForm.reset();
      passwordHint.classList.remove("is-valid");
      passwordHint.querySelector("strong").textContent = "Reikalavimai: bent 12 simbolių, didžioji ir mažoji raidė, skaičius ir specialusis simbolis.";
      setStatus("Paskyra sukurta! Patvirtink el. paštą — naujoms paskyroms suteikiamas 7 dienų nemokamas Premium laikotarpis.", "success");
    });
    return;
  }

  if (!data.session) {
    window.location.replace(`prisijungimas.html?redirect=${encodeURIComponent(`${window.location.pathname}${window.location.search}${window.location.hash}`)}`);
    return;
  }

  if (document.body.dataset.page === "profile") initializeProfile(data.session.user);
  const metadata = data.session.user.user_metadata || {};
  const userName = [metadata.first_name, metadata.last_name].filter(Boolean).join(" ") ||
    metadata.full_name ||
    data.session.user.email;
  const userNameElement = document.querySelector("#auth-user-name");
  if (userNameElement) userNameElement.textContent = userName;
  if (profileLink) profileLink.hidden = false;
  if (signOutButton) {
    signOutButton.hidden = false;
    signOutButton.addEventListener("click", async () => {
      if (!window.confirm("Ar tikrai norite atsijungti?")) return;
      signOutButton.disabled = true;
      try {
        const { error: signOutError } = await supabase.auth.signOut();
        if (signOutError) throw signOutError;
        window.location.replace("prisijungimas.html");
      } catch (signOutError) {
        signOutButton.disabled = false;
        console.error("Nepavyko atsijungti.", signOutError);
        window.alert(`Atsijungti nepavyko: ${signOutError.message}`);
      }
    });
  }
  document.documentElement.classList.remove("auth-pending");
}

configure().catch((error) => {
  console.error("Autentifikavimo inicializacija nepavyko.", error);
  if (authPage) {
    document.querySelector(".auth-shell").hidden = false;
    setStatus("Įvyko netikėta prisijungimo klaida. Patikrink konfigūraciją ir atnaujink puslapį.", "error");
  } else {
    window.location.replace(`prisijungimas.html?error=session&redirect=${encodeURIComponent(`${window.location.pathname}${window.location.search}${window.location.hash}`)}`);
  }
});
