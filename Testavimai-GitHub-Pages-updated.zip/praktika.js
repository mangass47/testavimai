import { practiceQuestions, localizeQuestion } from "./praktika-question-data.js";
import { getLearningCaseOdds } from "./progress.js";
import { getSubjectSummary, recordSubjectAttempt } from "./learning-summary.js";
const studyQuestions = practiceQuestions;
const tr = (key, values) => window.testavimai?.t?.(key, values) ?? key;
const currentLang = () => document.documentElement.lang || "lt";
const localized = (item) => localizeQuestion(item, currentLang());
const showExplanations = () => window.testavimai?.showExplanations?.() !== false;
const initialPracticeParams = new URLSearchParams(window.location.search);
let hasUserSelectedTopicFilter = initialPracticeParams.has("dalykas");
let hasUserSelectedDifficultyFilter = initialPracticeParams.has("sudetingumas");
let hasUserSelectedTypeFilter = initialPracticeParams.has("tipas");
function readLocalSetting(key, fallback = "") {
  try {
    return localStorage.getItem(key) ?? fallback;
  } catch (error) {
    console.error(`Nepavyko nuskaityti nuostatos ${key}.`, error);
    return fallback;
  }
}
let sessionTitleKey = "";
let lastQuizOptions = {};
let lastRecordHitLimit = false;

const session = document.querySelector("#practice-session");
const sessionTitle = document.querySelector("#practice-session-title");
const sessionBody = document.querySelector("#practice-session-body");
const topicPicker = document.querySelector("#practice-topic");
const reviewKey = "testavimai-practice-review";
const cardProgressKey = "testavimai-flashcard-progress";
const currentWeekStart = new Date();
currentWeekStart.setHours(0, 0, 0, 0);
currentWeekStart.setDate(currentWeekStart.getDate() - (currentWeekStart.getDay() + 6) % 7);
const weeklyPlanKey = `testavimai-weekly-plan-${currentWeekStart.getFullYear()}-${String(currentWeekStart.getMonth() + 1).padStart(2, "0")}-${String(currentWeekStart.getDate()).padStart(2, "0")}`;
const subjectKeys = new Map([
  ["matematika", "subj_math"],
  ["lietuvių kalba", "subj_lt"],
  ["biologija", "subj_bio"],
  ["istorija", "subj_hist"],
  ["fizika", "subj_phys"],
  ["chemija", "subj_chem"],
  ["lietuviu", "subj_litlit"],
  ["rusu", "subj_ru"],
  ["prancuzu", "subj_fr"],
  ["ispanu", "subj_es"],
  ["vokieciu", "subj_de"],
  ["geografija", "subj_geo"],
  ["informatika", "subj_it"],
  ["muzika", "subj_music"],
  ["anglu", "subj_en"],
]);
const subjectNames = { get: (subject) => (subjectKeys.has(subject) ? tr(subjectKeys.get(subject)) : subject) };
let activeQuestions = [];
let activeIndex = 0;
let correctCount = 0;
let answered = false;
let isGeneratedPractice = false;
let quizTimeout;
let remainingSeconds = 0;
let progressSnapshot = {};
let hasProgressBaseline = false;
const buddyNameKey = "testavimai-buddy-name";
const buddyMoodKey = "testavimai-buddy-mood";
const buddyStyleKey = "testavimai-buddy-style";
const learningSubjectKey = "testavimai-learning-default-subject";
const learningGradeKey = "testavimai-learning-grade";
const learningFavoritesKey = "testavimai-learning-favorite-subjects";
const learningDifficultyKey = "testavimai-learning-default-difficulty";
const rewardItems = [
  { id: "theme_nocturne", name: "Nocturne Gold", detail: "Tamsi nakties tema su aukso akcentais", cost: 100, icon: "☾" },
  { id: "theme_aurum", name: "Aurum Navy", detail: "Tamsiai mėlyna tema su aukso akcentais", cost: 100, icon: "✦" },
  { id: "theme_velvet", name: "Velvet Orchid", detail: "Tamsi violetinė tema su aksominiais akcentais", cost: 100, icon: "✧" },
  { id: "theme_sapphire", name: "Sapphire Dusk", detail: "Naktinis mėlis su lediniu safyro švytėjimu", cost: 100, icon: "◇" },
  { id: "theme_obsidian", name: "Obsidian Silver", detail: "Grafito juoduma su sidabriniais akcentais", cost: 100, icon: "◈" },
  { id: "theme_amethyst", name: "Amethyst Aura", detail: "Gili naktis ir švytintis ametistas", cost: 100, icon: "✧" },
  { id: "theme_emerald", name: "Emerald Atelier", detail: "Tamsus smaragdas su gaiviu žalsvu švytėjimu", cost: 100, icon: "✳" },
  { id: "theme_crimson", name: "Crimson Velvet", detail: "Aksominė tamsa su sodriais rubino akcentais", cost: 100, icon: "♦" },
  { id: "theme_arctic", name: "Arctic Halo", detail: "Poliarinė naktis su ledo žydrumo detalėmis", cost: 100, icon: "❄" },
  { id: "theme_rose_noir", name: "Rose Noir", detail: "Naktinis slyvų atspalvis su rožiniu auksu", cost: 100, icon: "✿" },
  { id: "theme_lavender", name: "Lavender Atelier", detail: "Šviesi levandų erdvė su sodriu alyviniu akcentu", cost: 100, icon: "✿" },
  { id: "theme_peach", name: "Peach Sorbet", detail: "Šiltas persikinis fonas ir terakotos detalės", cost: 100, icon: "◒" },
  { id: "theme_lagoon", name: "Lagoon Glass", detail: "Gaivi žalsvai žydra platformos spalvų paletė", cost: 100, icon: "◉" },
  { id: "theme_blossom", name: "Blossom Silk", detail: "Švelnus rožinis paviršius su uogų akcentais", cost: 100, icon: "✿" },
  { id: "theme_sky", name: "Sky Atelier", detail: "Šviesi dangaus mėlio mokymosi erdvė", cost: 100, icon: "☁" },
  { id: "theme_buttercream", name: "Buttercream", detail: "Kreminis sviesto geltonumo fonas ir medaus akcentai", cost: 100, icon: "✦" },
  { id: "theme_mint", name: "Mint Garden", detail: "Šviesi mėtų žaluma su miško akcentais", cost: 100, icon: "❋" },
  { id: "theme_pearl", name: "Pearl Mist", detail: "Šviesi perlų ir migloto žydrumo tema", cost: 100, icon: "◈" },
  { id: "theme_rosewater", name: "Rosewater", detail: "Švelni rožinė paletė su uogų akcentais", cost: 100, icon: "✿" },
  { id: "theme_lemon", name: "Lemon Cream", detail: "Šviesi citrinų kremiškumo tema su medaus akcentais", cost: 100, icon: "✦" },
  { id: "premium_30_days", name: "Premium · 30 dienų", detail: "30 dienų Premium prieigos; likęs laikas pridedamas", cost: 10000, icon: "♛" },
];

function renderLearningSummary(summary = getSubjectSummary()) {
  const list = document.querySelector("#learning-summary-list");
  const empty = document.querySelector("#learning-summary-empty");
  if (!list || !empty) return;
  const entries = Object.entries(summary).filter(([, stats]) => Number(stats?.total) > 0);
  list.replaceChildren();
  empty.hidden = entries.length > 0;
  entries.sort(([, left], [, right]) => right.total - left.total);
  for (const [subject, stats] of entries) {
    const total = Number(stats.total);
    const correct = Number(stats.correct);
    const row = document.createElement("div");
    row.className = "learning-summary-row";
    const title = document.createElement("strong");
    title.textContent = subjectNames.get(subject);
    const result = document.createElement("span");
    result.textContent = tr("learning_summary_count", {
      correct,
      total,
      percent: Math.round((correct / total) * 100),
    });
    const mastery = document.createElement("progress");
    mastery.className = "learning-mastery-meter";
    mastery.max = 100;
    mastery.value = Math.round((correct / total) * 100);
    mastery.setAttribute("aria-label", `${subjectNames.get(subject)}: ${Math.round((correct / total) * 100)} % teisingų atsakymų`);
    row.append(title, result, mastery);
    const topics = Object.entries(stats.topics || {}).filter(([, topicStats]) => Number(topicStats?.total) > 0);
    if (topics.length) {
      const topicList = document.createElement("ul");
      topicList.className = "learning-topic-list";
      topics.sort(([, left], [, right]) => (left.correct / left.total) - (right.correct / right.total));
      topics.forEach(([topic, topicStats]) => {
        const item = document.createElement("li");
        const percent = Math.round((topicStats.correct / topicStats.total) * 100);
        item.textContent = `${topic} · ${topicStats.correct}/${topicStats.total} (${percent} %)`;
        topicList.append(item);
      });
      row.append(topicList);
    }
    list.append(row);
  }

}

function readList(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(value) ? value : [];
  } catch (error) {
    console.error(`Nepavyko nuskaityti mokymosi duomenų ${key}.`, error);
    return [];
  }
}

function storeList(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Nepavyko išsaugoti mokymosi duomenų ${key}.`, error);
    showMessage("Nepavyko išsaugoti pažangos. Patikrink naršyklės saugyklos leidimus.", true);
  }
}

function showMessage(message, isError = false) {
  let status = sessionBody.querySelector(".practice-session-status");
  if (!status) {
    status = document.createElement("p");
    status.className = "practice-session-status";
    status.setAttribute("role", "status");
    sessionBody.append(status);
  }
  status.textContent = message;
  status.classList.toggle("is-error", isError);
}

function updateProgressDisplay(progress) {
  const previous = progressSnapshot;
  progressSnapshot = progress || {};
  if (Array.isArray(progressSnapshot.owned_themes)) renderCaseOdds(progressSnapshot.owned_themes);
  if (progress.is_guest) document.body.classList.add("guest-mode");
  const xp = document.querySelector("#practice-xp-value");
  const streak = document.querySelector("#practice-streak-value");
  const correct = document.querySelector("#practice-correct-value");
  const coins = document.querySelector("#practice-coins-value");
  const shopCoins = document.querySelector("#shop-coins-value");
  const imageCount = document.querySelector("#tutor-image-count");
  if (xp) xp.textContent = `${progress.xp || 0} XP`;
  if (streak) streak.textContent = String(progress.current_streak ?? progress.currentStreak ?? 0);
  if (correct) correct.textContent = `${Math.min(progress.correct_today ?? progress.correctToday ?? 0, 5)}/5`;
  if (coins) coins.textContent = String(progress.reward_coins || 0);
  document.querySelectorAll("[data-wallet]").forEach((el) => { el.textContent = String(progress.reward_coins || 0); });
  if (shopCoins) shopCoins.textContent = String(progress.reward_coins || 0);
  if (imageCount) imageCount.textContent = progress.is_premium
    ? "Neribotos nuotraukos šiandien"
    : `${progress.daily_images_used || 0} / 5 nuotraukų šiandien`;
  renderAchievements(progress.achievements || []);
  if (progress.is_guest) return;
  const earnedBadges = (progress.achievements || []).filter((item) => item.earned);
  const newlyEarned = hasProgressBaseline
    ? earnedBadges.filter((item) => !(previous.achievements || []).some((old) => old.id === item.id && old.earned))
    : [];
  newlyEarned.forEach((badge) => showRewardsNotification(`Naujas ženklelis: „${badge.title}“. Rewards skiltyje atsiimk jo atlygį.`));
  if (!hasProgressBaseline) {
    const pendingRewards = earnedBadges.filter((item) => !item.reward_claimed).length;
    if (pendingRewards) showRewardsNotification(`Turi ${pendingRewards} neatsiimtų ženklelių atlygių. Užsuk į Rewards skiltį.`);
  }
  const previousCoins = Number(previous.reward_coins || 0);
  const currentCoins = Number(progress.reward_coins || 0);
  if (hasProgressBaseline && previousCoins < 250 && currentCoins >= 250) {
    showRewardsNotification("Surinkai 250 mokymosi taškų — gali atverti Prizų dėžutę!");
  }
  hasProgressBaseline = true;
}

function showRewardsNotification(message) {
  const notice = document.createElement("div");
  notice.className = "rewards-notification";
  notice.setAttribute("role", "status");
  notice.textContent = message;
  document.body.append(notice);
  window.setTimeout(() => notice.remove(), 6500);
}

async function recordAnswer(questionId, answerIndex, subject, topic) {
  lastRecordHitLimit = false;
  try {
    const { recordPracticeAnswer } = await import("./progress.js");
    const result = await recordPracticeAnswer(questionId, answerIndex);
    updateProgressDisplay(result);
    if (subject && typeof result.is_correct === "boolean") {
      try {
        renderLearningSummary(recordSubjectAttempt(subject, result.is_correct, topic));
      } catch (error) {
        console.error("Nepavyko atnaujinti dalykų pažangos suvestinės.", error);
      }
    }
    const note = document.querySelector("#practice-progress-note");
    if (note) {
      if (result.is_guest) {
        note.textContent = tr("pq_rec_guest");
        return result;
      }
      const points = result.points_delta || 0;
      const pointLabel = points > 0 ? `+${points}` : String(points);
      note.textContent = `${result.is_correct ? tr("pq_rec_ok") : tr("pq_rec_bad")} · ${pointLabel} XP${result.streak_bonus ? tr("pq_rec_streak") : ""}`;
    }
    return result;
  } catch (error) {
    console.error("Nepavyko išsaugoti atsakymo ir XP taškų.", error);
    lastRecordHitLimit = /15/.test(error.message || "");
    const note = document.querySelector("#practice-progress-note");
    if (note) note.textContent = tr("pq_rec_fail", { m: error.message });
    return null;
  }
}

function renderAchievements(achievements) {
  const grid = document.querySelector("#achievement-grid");
  const counter = document.querySelector("#achievement-counter");
  if (!grid) return;
  const visibleAchievements = achievements.filter((item) => item.id !== "creator" || item.earned);
  grid.replaceChildren();
  const unlockedCount = visibleAchievements.filter((item) => item.earned).length;
  if (counter) counter.textContent = `${unlockedCount} / ${visibleAchievements.length}`;
  visibleAchievements.forEach((achievement) => {
    const card = document.createElement("article");
    card.className = `achievement-card${achievement.earned ? " is-earned" : ""}`;
    const icon = document.createElement("span");
    icon.className = "achievement-icon";
    icon.textContent = achievement.icon || "✦";
    const title = document.createElement("strong");
    title.textContent = achievement.title;
    const description = document.createElement("span");
    description.textContent = achievement.description;
    card.append(icon, title, description);
    if (achievement.earned) {
      const reward = document.createElement("span");
      reward.className = "achievement-reward";
      reward.textContent = `Atlygis: ${achievement.reward_coins || 10} mokymosi taškų`;
      card.append(reward);
      const claimButton = document.createElement("button");
      claimButton.type = "button";
      claimButton.className = "achievement-claim-button";
      claimButton.textContent = achievement.reward_claimed ? "Atlygis atsiimtas ✓" : "Atsiimti atlygį";
      claimButton.disabled = Boolean(achievement.reward_claimed);
      claimButton.addEventListener("click", async () => {
        claimButton.disabled = true;
        try {
          const { claimAchievementReward, getMyProgress } = await import("./progress.js");
          const result = await claimAchievementReward(achievement.id);
          updateProgressDisplay(await getMyProgress());
          showRewardsNotification(`Atsiėmei „${result.title}“ ženklelio atlygį: +${result.reward_coins} taškų.`);
        } catch (error) {
          console.error("Ženklelio atlygio atsiimti nepavyko.", error);
          showRewardsNotification(error.message);
          claimButton.disabled = false;
        }
      });
      card.append(claimButton);
    }
    grid.append(card);
  });
}

function renderRewards() {
  const grid = document.querySelector("#reward-grid");
  if (!grid) return;
  grid.replaceChildren();
  rewardItems.forEach((reward) => {
    const card = document.createElement("article");
    card.className = "reward-card";
    const icon = document.createElement("span");
    icon.className = "reward-icon";
    icon.textContent = reward.icon;
    const title = document.createElement("strong");
    title.textContent = reward.name;
    const description = document.createElement("p");
    description.textContent = reward.detail;
    const cost = document.createElement("span");
    cost.className = "reward-cost";
    cost.textContent = `${reward.cost.toLocaleString("lt-LT")} taškų`;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "reward-buy-button";
    button.textContent = "Atrakinti atlygį";
    button.addEventListener("click", async () => {
      button.disabled = true;
      const status = document.querySelector("#reward-status");
      try {
        const { redeemReward, getMyProgress } = await import("./progress.js");
        await redeemReward(reward.id);
        const updated = await getMyProgress();
        updateProgressDisplay(updated);
        if (reward.id.startsWith("theme_")) {
          const theme = reward.id.slice("theme_".length);
          document.dispatchEvent(new CustomEvent("testavimai:select-theme", { detail: theme }));
        }
        status.textContent = `Atlygis „${reward.name}“ sėkmingai atrakintas.`;
        status.className = "reward-status is-success";
      } catch (error) {
        console.error("Nepavyko atsiimti mokymosi atlygio.", error);
        status.textContent = error.message;
        status.className = "reward-status is-error";
      } finally {
        button.disabled = false;
      }
    });
    card.append(icon, title, description, cost, button);
    grid.append(card);
  });
}

const rarityOrder = ["common", "rare", "epic", "legendary"];

const rarityLabels = { common: "Įprastas", rare: "Retas", epic: "Epinis", legendary: "Legendinis" };

function formatChance(chance) {
  return `${chance.toLocaleString(document.documentElement.lang || "lt", { maximumFractionDigits: 4 })}%`;
}

function caseOddsPrizeInfo(prize) {
  if (prize.kind === "theme") {
    const item = rewardItems.find((reward) => reward.id === `theme_${prize.theme_id}`);
    return { name: item?.name || prize.theme_id, icon: item?.icon || "◇" };
  }
  return { name: prize.name, icon: prize.icon };
}

function renderCaseOdds(ownedThemes = []) {
  const cases = getLearningCaseOdds(ownedThemes);
  for (const caseId of ["standard"]) {
    const panel = document.querySelector(`#case-odds-${caseId}`);
    if (!panel) continue;
    panel.replaceChildren();
    const prizes = [...cases[caseId]].sort((left, right) => (
      rarityOrder.indexOf(left.rarity) - rarityOrder.indexOf(right.rarity)
      || left.prize_id.localeCompare(right.prize_id)
    ));

    const list = document.createElement("ul");
    list.className = "case-odds-list";
    prizes.forEach((prize) => {
      const item = caseOddsPrizeInfo(prize);
      const row = document.createElement("li");
      row.className = `case-odds-item case-rarity-${prize.rarity}`;
      const icon = document.createElement("span");
      icon.className = "case-odds-icon";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = item.icon;
      const details = document.createElement("span");
      details.className = "case-odds-details";
      const name = document.createElement("strong");
      name.textContent = item.name;
      const rarity = document.createElement("small");
      rarity.textContent = rarityLabels[prize.rarity] || prize.rarity;
      const chance = document.createElement("strong");
      chance.className = "case-odds-chance";
      chance.textContent = formatChance(prize.chance);
      details.append(name, rarity);
      row.append(icon, details, chance);
      list.append(row);
    });
    panel.append(list);
  }
}

document.querySelectorAll("[data-case-odds-toggle]").forEach((button) => {
  button.addEventListener("click", () => {
    const panel = document.querySelector(`#case-odds-${button.dataset.caseOddsToggle}`);
    if (!panel) return;
    const expanded = button.getAttribute("aria-expanded") === "true";
    button.setAttribute("aria-expanded", String(!expanded));
    panel.hidden = expanded;
    const icon = button.querySelector("span");
    if (icon) icon.textContent = expanded ? "⌄" : "⌃";
  });
});

function pickCasePrize(prizes) {
  const totalChance = prizes.reduce((total, prize) => total + prize.chance, 0);
  let roll = Math.random() * totalChance;
  return prizes.find((prize) => (roll -= prize.chance) < 0) || prizes[prizes.length - 1];
}

function celebrateCaseWin(roulette, rarity) {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const count = rarity === "legendary" ? 36 : rarity === "epic" ? 24 : rarity === "rare" ? 12 : 0;
  for (let index = 0; index < count; index += 1) {
    const piece = document.createElement("span");
    piece.className = "case-confetti-piece";
    piece.style.setProperty("--confetti-x", `${Math.round((Math.random() - 0.5) * 680)}px`);
    piece.style.setProperty("--confetti-y", `${Math.round(-80 - Math.random() * 260)}px`);
    piece.style.setProperty("--confetti-turn", `${Math.round(Math.random() * 720 - 360)}deg`);
    piece.style.setProperty("--confetti-delay", `${Math.random() * 180}ms`);
    piece.addEventListener("animationend", () => piece.remove(), { once: true });
    roulette.append(piece);
  }
}

function playCaseRoulette(container, result, rewardName, prizes) {
  const itemWidth = 140;
  const winnerIndex = 48;
  const total = 56;
  const roulette = document.createElement("div");
  roulette.className = "case-roulette";
  roulette.dataset.rarity = result.rarity;
  roulette.setAttribute("aria-label", "Dėžutės prizų ritinys");
  const marker = document.createElement("div");
  marker.className = "case-roulette-marker";
  const track = document.createElement("div");
  track.className = "case-roulette-track";
  for (let i = 0; i < total; i += 1) {
    const isWinner = i === winnerIndex;
    const prize = isWinner
      ? { ...(prizes.find((entry) => entry.prize_id === result.prize_id) || {}), prize_id: result.prize_id, rarity: result.rarity }
      : pickCasePrize(prizes);
    const info = caseOddsPrizeInfo(prize);
    const nameText = isWinner ? rewardName : info.name;
    const cell = document.createElement("div");
    cell.className = `case-roulette-item case-rarity-${prize.rarity}`;
    if (isWinner) cell.classList.add("case-roulette-item-target");
    const icon = Object.assign(document.createElement("span"), { textContent: info.icon || "◇" });
    const name = Object.assign(document.createElement("small"), { textContent: nameText });
    cell.append(icon, name);
    track.append(cell);
  }
  roulette.append(marker, track);
  container.className = "case-opening-status";
  container.replaceChildren(roulette);

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const duration = reduceMotion ? 0 : 7600;
  const offset = winnerIndex * itemWidth + 65 - roulette.clientWidth / 2;

  return new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      track.style.transition = duration ? `transform ${duration}ms cubic-bezier(.07,.76,.08,1)` : "none";
      track.style.transform = `translateX(${-offset}px)`;
    }));
    window.setTimeout(() => {
      track.children[winnerIndex].classList.add("is-winner");
      roulette.classList.add("is-stopped");
      celebrateCaseWin(roulette, result.rarity);
      window.setTimeout(resolve, duration ? 1100 : 0);
    }, duration + 50);
  });
}

document.querySelectorAll("[data-case-id]").forEach((button) => {
  button.addEventListener("click", async () => {
    const status = document.querySelector("#case-opening-status");
    const panel = document.querySelector(".case-opening-panel");
    const caseButtons = [...document.querySelectorAll("[data-case-id]")];
    const previousDisabledStates = caseButtons.map((caseButton) => caseButton.disabled);
    caseButtons.forEach((caseButton) => { caseButton.disabled = true; });
    button.classList.add("is-opening");
    panel.classList.add("is-opening");
    status.className = "case-opening-status";
    status.textContent = "Dėžutė atidaroma…";
    try {
      const { openLearningCase, getMyProgress } = await import("./progress.js");
      const result = await openLearningCase(button.dataset.caseId);
      const ownedBeforeOpen = Array.isArray(result.owned_themes)
        ? result.owned_themes.filter((theme) => theme !== result.theme_id)
        : progressSnapshot.owned_themes || [];
      const prizes = getLearningCaseOdds(ownedBeforeOpen).standard;
      const wonPrize = prizes.find((entry) => entry.prize_id === result.prize_id) || { prize_id: result.prize_id, kind: result.kind, theme_id: result.theme_id };
      const rewardName = caseOddsPrizeInfo(wonPrize).name;
      await playCaseRoulette(status, result, rewardName, prizes);
      updateProgressDisplay(await getMyProgress());
      const resultCard = document.createElement("div");
      resultCard.className = `case-result-card case-rarity-${result.rarity}`;
      const prize = document.createElement("strong");
      prize.textContent = `${(rarityLabels[result.rarity] || result.rarity).toLocaleUpperCase("lt")} prizas: ${rewardName}`;
      resultCard.append(prize);
      if (result.kind === "theme") {
        const applyTheme = document.createElement("button");
        applyTheme.type = "button";
        applyTheme.className = "case-apply-theme";
        applyTheme.textContent = "Pritaikyti temą";
        applyTheme.addEventListener("click", () => {
          document.dispatchEvent(new CustomEvent("testavimai:select-theme", { detail: result.theme_id }));
          applyTheme.textContent = "Tema pritaikyta ✓";
          applyTheme.disabled = true;
        });
        resultCard.append(applyTheme);
      } else if (result.kind === "premium") {
        const note = document.createElement("small");
        note.textContent = "Premium prieiga pridėta prie tavo paskyros.";
        resultCard.append(note);
      } else {
        const note = document.createElement("small");
        note.textContent = `Į tavo sąskaitą įskaityta ${result.coins_won} taškų.`;
        resultCard.append(note);
      }
      status.replaceChildren(resultCard);
      status.classList.add("is-success");
    } catch (error) {
      console.error("Nepavyko atidaryti mokymosi dėžutės.", error);
      status.textContent = error.message;
      status.classList.add("is-error");
    } finally {
      button.classList.remove("is-opening");
      panel.classList.remove("is-opening");
      caseButtons.forEach((caseButton, index) => {
        caseButton.disabled = previousDisabledStates[index];
      });
    }
  });
});

function showSession(title, titleKey = "") {
  window.clearInterval(quizTimeout);
  session.hidden = false;
  sessionTitleKey = titleKey;
  sessionTitle.textContent = titleKey ? tr(titleKey) : title;
  sessionBody.replaceChildren();
  session.scrollIntoView({ behavior: "smooth", block: "start" });
}

function filteredQuestions() {
  const topic = topicPicker.value;
  const difficulty = document.querySelector("#practice-difficulty-filter")?.value || "all";
  const type = document.querySelector("#practice-type-filter")?.value || "all";
  return studyQuestions.filter((item) => (topic === "all" || item.subject === topic)
    && (difficulty === "all" || item.difficulty === difficulty)
    && (type === "all" || item.type === type));
}

function questionCountLabel(count) {
  const lastTwoDigits = count % 100;
  if ((lastTwoDigits >= 11 && lastTwoDigits <= 19) || count % 10 === 0) return `${count} klausimų`;
  return count % 10 === 1 ? `${count} klausimas` : `${count} klausimai`;
}

const questionFilters = [
  document.querySelector("#practice-difficulty-filter"),
  document.querySelector("#practice-type-filter"),
];
const filterSummary = document.querySelector("#practice-filter-summary");
function updateQuestionFilterSummary() {
  if (!filterSummary) return;
  const eligible = filteredQuestions().length;
  const active = questionFilters.filter((filter) => filter && filter.value !== "all").length
    + Number(topicPicker.value !== "all");
  filterSummary.textContent = active
    ? `Pagal filtrus rasta ${questionCountLabel(eligible)} iš ${studyQuestions.length} klausimų.`
    : `${studyQuestions.length} klausimų · pasirink dalyką, sudėtingumą ar tipą.`;
}
[topicPicker, ...questionFilters].filter(Boolean).forEach((filter) => filter.addEventListener("change", updateQuestionFilterSummary));
updateQuestionFilterSummary();

function shuffled(items) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

async function startQuiz(options) {
  lastQuizOptions = options;
  const { count, titleKey, timed = false, daily = false, review = false, useAllQuestions = false } = options;
  try {
    const { getMyProgress } = await import("./progress.js");
    updateProgressDisplay(await getMyProgress());
  } catch (error) {
    console.error("Nepavyko patikrinti klausimų dienos limito.", error);
    showSession("", titleKey);
    showMessage(tr("pq_limit_err", { m: error.message }), true);
    return;
  }
  const available = daily || useAllQuestions ? studyQuestions : filteredQuestions();
  const reviewIds = new Set(readList(reviewKey));
  const eligible = review ? available.filter((item) => reviewIds.has(item.id)) : available;
  if (eligible.length === 0) {
    showSession("", titleKey);
    showMessage(review
      ? tr("pq_no_review")
      : "Pagal pasirinktus dalyką, sudėtingumą ir klausimo tipą klausimų nerasta. Pakeisk filtrus ir bandyk dar kartą.");
    if (!review) {
      const clearFilters = document.createElement("button");
      clearFilters.type = "button";
      clearFilters.className = "question-page-button";
      clearFilters.textContent = "Išvalyti filtrus";
      clearFilters.addEventListener("click", () => {
        topicPicker.value = "all";
        document.querySelector("#practice-difficulty-filter").value = "all";
        document.querySelector("#practice-type-filter").value = "all";
        hasUserSelectedTopicFilter = false;
        hasUserSelectedDifficultyFilter = false;
        hasUserSelectedTypeFilter = false;
        updatePracticeLinks();
        updateQuestionFilterSummary();
        if (document.body.dataset.practiceView) {
          void startQuiz(lastQuizOptions);
        } else {
          session.hidden = true;
          topicPicker.focus();
        }
      });
      sessionBody.append(clearFilters);
    }
    return;
  }
  const requestedCount = daily && progressSnapshot.is_premium ? studyQuestions.length : count;
  const remaining = progressSnapshot.is_premium ? requestedCount : Math.min(requestedCount, Number(progressSnapshot.daily_questions_remaining || 0));
  if (remaining <= 0) {
    showSession("", titleKey);
    showMessage(tr("pq_daily_done"));
    return;
  }
  isGeneratedPractice = false;
  activeQuestions = shuffled(eligible).slice(0, Math.min(remaining, eligible.length));
  activeIndex = 0;
  correctCount = 0;
  answered = false;
  showSession("", titleKey);
  renderQuizQuestion();
  if (timed) {
    remainingSeconds = activeQuestions.length * 45;
    const timer = document.createElement("p");
    timer.className = "practice-quiz-timer";
    timer.id = "practice-quiz-timer";
    sessionBody.prepend(timer);
    updateQuizTimer();
    quizTimeout = window.setInterval(updateQuizTimer, 1000);
  }
}

function updateQuizTimer() {
  const timer = document.querySelector("#practice-quiz-timer");
  if (!timer) {
    window.clearInterval(quizTimeout);
    return;
  }
  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  timer.textContent = tr("pq_timer", { t: `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}` });
  if (remainingSeconds <= 0) {
    window.clearInterval(quizTimeout);
    finishQuiz();
    return;
  }
  remainingSeconds -= 1;
}

function renderQuizQuestion() {
  sessionBody.querySelector(".practice-quiz-question")?.remove();
  sessionBody.querySelector(".practice-session-status")?.remove();
  if (activeIndex >= activeQuestions.length) {
    finishQuiz();
    return;
  }
  answered = false;
  const item = localized(activeQuestions[activeIndex]);
  const card = document.createElement("div");
  card.className = "practice-quiz-question";
  const progress = document.createElement("p");
  progress.className = "practice-quiz-progress";
  const difficultyLabel = { easy: "Lengvas", medium: "Vidutinis", hard: "Sunkus" }[item.difficulty] || "Nenurodytas";
  progress.textContent = `${tr("pq_progress", { s: subjectNames.get(item.subject), i: activeIndex + 1, n: activeQuestions.length })} · ${item.topic || "Bendra tema"} · ${difficultyLabel}`;
  const question = document.createElement("h3");
  question.tabIndex = -1;
  question.textContent = item.prompt;
  const options = document.createElement("div");
  options.className = "practice-quiz-options";
  item.answers.forEach((answer, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "practice-quiz-option";
    button.textContent = answer;
    button.addEventListener("click", () => answerQuizQuestion(button, index));
    options.append(button);
  });
  const feedback = document.createElement("p");
  feedback.className = "practice-quiz-feedback";
  feedback.setAttribute("aria-live", "polite");
  const explanationSteps = document.createElement("ol");
  explanationSteps.className = "practice-explanation-steps";
  explanationSteps.hidden = true;
  if (currentLang() === "lt") {
    (item.steps || []).forEach((step) => {
      const stepItem = document.createElement("li");
      stepItem.textContent = step;
      explanationSteps.append(stepItem);
    });
  }
  const next = document.createElement("button");
  next.type = "button";
  next.className = "lesson-practice practice-quiz-next";
  next.hidden = true;
  next.textContent = activeIndex === activeQuestions.length - 1 ? tr("pq_result") : tr("pq_next");
  next.addEventListener("click", () => {
    activeIndex += 1;
    renderQuizQuestion();
    sessionBody.querySelector(".practice-quiz-question h3")?.focus();
  });
  const report = createQuestionReportLink(item);
  card.append(progress, question, options, feedback, explanationSteps, report, next);
  sessionBody.append(card);
  question.focus({ preventScroll: true });
}

function createQuestionReportLink(item) {
  const link = document.createElement("a");
  link.className = "practice-question-report";
  link.href = `mailto:pagalba@testavimai.lt?subject=${encodeURIComponent(`Klaida klausime: ${item.id}`)}&body=${encodeURIComponent(`Klausimo ID: ${item.id}\nDalykas: ${item.subject}\nKlausimas: ${item.prompt}\n\nAprašyk pastebėtą netikslumą:`)}`;
  link.textContent = "Pranešti apie klausimo netikslumą";
  link.setAttribute("aria-label", `Pranešti apie netikslumą klausime: ${item.prompt}`);
  return link;
}

function startGeneratedPractice(questions, subject, topic) {
  activeQuestions = questions.map((item, index) => ({
    id: `ai-${Date.now()}-${index}`,
    subject,
    prompt: item.prompt,
    answers: item.answers,
    correct: item.correct,
    explanation: item.explanation,
  }));
  activeIndex = 0;
  correctCount = 0;
  answered = false;
  isGeneratedPractice = true;
  showSession(`${subjectNames.get(subject)} · ${topic}`);
  renderQuizQuestion();
}

async function answerQuizQuestion(selectedButton, answerIndex) {
  if (answered) return;
  answered = true;
  const item = localized(activeQuestions[activeIndex]);
  const correct = answerIndex === item.correct;
  if (correct) correctCount += 1;
  if (!isGeneratedPractice) {
    const reviewIds = new Set(readList(reviewKey));
    if (correct) reviewIds.delete(item.id);
    else reviewIds.add(item.id);
    storeList(reviewKey, [...reviewIds]);
  }
  sessionBody.querySelectorAll(".practice-quiz-option").forEach((button, index) => {
    button.disabled = true;
    if (index === item.correct) button.classList.add("is-correct");
  });
  if (!correct) selectedButton.classList.add("is-incorrect");
  const feedback = sessionBody.querySelector(".practice-quiz-feedback");
  feedback.textContent = `${correct ? tr("pq_right") : tr("pq_wrong")}${showExplanations() ? ` ${item.explanation}` : ""}`;
  feedback.classList.toggle("is-correct", correct);
  const steps = sessionBody.querySelector(".practice-explanation-steps");
  if (steps && steps.children.length && showExplanations()) steps.hidden = false;
  if (isGeneratedPractice) {
    sessionBody.querySelector(".practice-quiz-next").hidden = false;
    return;
  }
  const progressResult = await recordAnswer(item.id, answerIndex, item.subject, item.topic);
  if (progressResult?.streak_bonus) feedback.textContent += tr("pq_streak_bonus");
  const next = sessionBody.querySelector(".practice-quiz-next");
  if (!progressResult && lastRecordHitLimit) {
    feedback.textContent += ` ${tr("pq_limit_reached")}`;
    next.textContent = tr("pq_result");
    next.addEventListener("click", finishQuiz, { once: true });
    next.hidden = false;
  } else {
    next.hidden = false;
  }
}

function finishQuiz() {
  window.clearInterval(quizTimeout);
  sessionBody.replaceChildren();
  const percentage = Math.round((correctCount / activeQuestions.length) * 100);
  if (!isGeneratedPractice) {
    import("./learning-summary.js").then(({ recordTestResult }) => {
      const titleText = sessionTitle.textContent || "Praktikos testas";
      return recordTestResult({ title: titleText, correct: correctCount, total: activeQuestions.length });
    }).then(renderTestHistory).catch((error) => {
      console.error("Testo rezultato išsaugoti nepavyko.", error);
    });
  }
  const result = document.createElement("div");
  result.className = "practice-quiz-result";
  const title = document.createElement("h3");
  title.tabIndex = -1;
  title.textContent = percentage >= 80 ? tr("pq_great") : tr("pq_good");
  const score = document.createElement("p");
  score.textContent = tr("pq_score", { c: correctCount, n: activeQuestions.length, p: percentage });
  const repeat = document.createElement("button");
  repeat.type = "button";
  repeat.className = "lesson-practice";
  repeat.textContent = tr("pq_retry");
  repeat.addEventListener("click", () => {
    if (isGeneratedPractice) {
      sessionBody.replaceChildren();
      activeIndex = 0;
      correctCount = 0;
      renderQuizQuestion();
      return;
    }

    startQuiz({ ...lastQuizOptions, count: activeQuestions.length });
  });
  result.append(title, score, repeat);
  sessionBody.append(result);
  title.focus();
}

function renderTestHistory(history) {
  const list = document.querySelector("#test-result-history");
  const empty = document.querySelector("#test-result-history-empty");
  if (!list || !empty) return;
  list.replaceChildren();
  empty.hidden = history.length > 0;
  history.slice(0, 10).forEach((entry) => {
    const row = document.createElement("li");
    const date = new Intl.DateTimeFormat(document.documentElement.lang || "lt", { dateStyle: "medium" }).format(new Date(entry.completedAt));
    row.textContent = `${date} · ${entry.title} · ${entry.correct}/${entry.total} (${Math.round(entry.correct / entry.total * 100)} %)`;
    list.append(row);
  });
}

let activeFlashcards = [];

function startFlashcards() {
  const loadCards = async () => {
    try {
      const { getMyProgress } = await import("./progress.js");
      updateProgressDisplay(await getMyProgress());
      const limit = progressSnapshot.is_premium
        ? filteredQuestions().length
        : Math.min(filteredQuestions().length, Number(progressSnapshot.daily_questions_remaining || 0));
      activeFlashcards = shuffled(filteredQuestions()).slice(0, limit);
      renderFlashcards();
    } catch (error) {
      console.error("Nepavyko patikrinti kortelių dienos limito.", error);
      showMessage(tr("pq_limit_err", { m: error.message }), true);
    }
  };
  showSession("", "c5_t");
  void loadCards();
  return;
}

function renderFlashcards() {
  if (activeFlashcards.length === 0) {
    showMessage(progressSnapshot.daily_questions_remaining === 0 ? tr("pq_daily_done") : tr("pq_no_cards"));
    return;
  }
  let index = 0;
  const renderCard = () => {
    sessionBody.replaceChildren();
    const item = localized(activeFlashcards[index]);
    const card = document.createElement("button");
    card.className = "flashcard";
    card.type = "button";
    card.setAttribute("aria-label", tr("pq_card_flip"));
    let flipped = false;
    const face = document.createElement("span");
    face.className = "flashcard-face";
    face.textContent = item.prompt;
    const hint = document.createElement("span");
    hint.className = "flashcard-hint";
    hint.textContent = tr("pq_card_hint");
    card.append(face, hint);
    card.addEventListener("click", () => {
      flipped = !flipped;
      face.textContent = flipped ? item.answers[item.correct] : item.prompt;
      hint.textContent = flipped && showExplanations() ? item.explanation : tr("pq_card_hint");
      card.classList.toggle("is-flipped", flipped);
      controls.hidden = !flipped;
    });
    const progress = document.createElement("p");
    progress.className = "practice-quiz-progress";
    progress.textContent = tr("pq_progress", { s: subjectNames.get(item.subject), i: index + 1, n: activeFlashcards.length });
    const controls = document.createElement("div");
    controls.className = "flashcard-controls";
    controls.hidden = true;
    for (const [label, known] of [[tr("pq_again"), false], [tr("pq_know"), true]]) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = known ? "lesson-practice" : "question-page-button";
      button.textContent = label;
      button.addEventListener("click", async () => {
        controls.querySelectorAll("button").forEach((control) => { control.disabled = true; });
        const progressResult = await recordAnswer(item.id, known ? item.correct : (item.correct + 1) % item.answers.length, item.subject, item.topic);
        const progressList = new Set(readList(cardProgressKey));
        if (known) progressList.add(item.id);
        else progressList.delete(item.id);
        storeList(cardProgressKey, [...progressList]);
        if (progressResult?.streak_bonus) showMessage(tr("pq_streak_bonus").trim());
        index += 1;
        if (index >= activeFlashcards.length) {
          showSession("", "c5_t");
          showMessage(tr("pq_cards_done", { n: activeFlashcards.length }));
        } else renderCard();
      });
      controls.append(button);
    }
    sessionBody.append(progress, card, controls);
  };
  renderCard();
}

document.querySelectorAll("[data-mode]").forEach((button) => {
  button.addEventListener("click", () => {
    switch (button.dataset.mode) {
      case "quick":
        startQuiz({ count: 10, titleKey: "c2_t", useAllQuestions: !hasExplicitPracticeFilters });
        break;
      case "daily":
        startQuiz({ count: 10, titleKey: "pq_daily", daily: true });
        break;
      case "review":
        startQuiz({ count: practiceQuestions.length, titleKey: "c10_t", review: true });
        break;
      case "flashcards":
        startFlashcards();
        break;
      case "entrance": {
        const panel = document.querySelector("#entrance-test-panel");
        panel.hidden = false;
        panel.scrollIntoView({ behavior: "smooth", block: "center" });
        break;
      }
      default:
        break;
    }
  });
});

topicPicker.addEventListener("change", () => {
  hasUserSelectedTopicFilter = true;
  const link = document.querySelector("#practice-exercises-link");
  link.href = topicPicker.value === "all"
    ? "pamokos.html#praktika"
    : `pamokos.html?dalykas=${encodeURIComponent(topicPicker.value)}#praktika`;
  updatePracticeLinks();
});

function updatePracticeLinks() {
  const filters = {
    dalykas: topicPicker.value,
    sudetingumas: document.querySelector("#practice-difficulty-filter").value,
    tipas: document.querySelector("#practice-type-filter").value,
  };
  document.querySelectorAll('.practice-mode-card[href*="veikla="]').forEach((card) => {
    const url = new URL(card.href);
    Object.entries(filters).forEach(([key, value]) => {
      const selectedByUser = {
        dalykas: hasUserSelectedTopicFilter,
        sudetingumas: hasUserSelectedDifficultyFilter,
        tipas: hasUserSelectedTypeFilter,
      }[key];
      if (value === "all" || !selectedByUser) url.searchParams.delete(key);
      else url.searchParams.set(key, value);
    });
    card.href = url.href;
  });
  const backUrl = new URL("praktika.html", window.location.href);
  Object.entries(filters).forEach(([key, value]) => {
    const selectedByUser = {
      dalykas: hasUserSelectedTopicFilter,
      sudetingumas: hasUserSelectedDifficultyFilter,
      tipas: hasUserSelectedTypeFilter,
    }[key];
    if (value !== "all" && selectedByUser) backUrl.searchParams.set(key, value);
  });
  backUrl.hash = "dalykai";
  document.querySelector(".practice-focused-back").href = backUrl.href;
}

document.querySelectorAll("#practice-difficulty-filter, #practice-type-filter").forEach((filter) => {
  filter.addEventListener("change", () => {
    if (filter.id === "practice-difficulty-filter") hasUserSelectedDifficultyFilter = true;
    if (filter.id === "practice-type-filter") hasUserSelectedTypeFilter = true;
    updatePracticeLinks();
  });
});

document.querySelectorAll('[data-mode="timed"]').forEach((button) => {
  button.addEventListener("click", () => startQuiz({
    count: 5,
    titleKey: "c9_t",
    timed: true,
    useAllQuestions: !hasExplicitPracticeFilters,
  }));
});

document.querySelector("#practice-close").addEventListener("click", () => {
  window.clearInterval(quizTimeout);
  if (document.body.dataset.practiceView) {
    window.location.href = document.querySelector(".practice-focused-back").href;
    return;
  }
  session.hidden = true;
});

document.querySelector("#entrance-test-panel .tool-close").addEventListener("click", () => {
  document.querySelector("#entrance-test-panel").hidden = true;
});

document.querySelector("#entrance-test-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const difficulty = document.querySelector("#entrance-difficulty").value;
  const subject = document.querySelector("#entrance-subject").value;
  const url = new URL("testas.html", window.location.href);
  url.searchParams.set("testas", "1");
  url.searchParams.set("difficulty", difficulty);
  url.searchParams.set("dalykas", subject);
  url.hash = "praktika";
  window.location.href = url.href;
});

const assessmentCatalog = import("./subjects.js").then(({ subjectCatalog, grades, topicsFor }) => {
  const params = new URLSearchParams(window.location.search);
  const requestedSubject = params.get("dalykas") || readLocalSetting(learningSubjectKey, "");
  const wantedSubject = subjectCatalog.some((subject) => subject.id === requestedSubject)
    ? requestedSubject
    : requestedSubject === "lietuvių kalba" && subjectCatalog.some((subject) => subject.id === "lietuviu")
      ? "lietuviu"
      : "matematika";
  const assessmentGrades = grades.filter((grade) => grade >= 7 && grade <= 10);
  const requestedGrade = Number(params.get("klase") || readLocalSetting(learningGradeKey, "7"));
  const wantedGrade = assessmentGrades.includes(requestedGrade) ? requestedGrade : 7;
  const gradeBox = document.querySelector("#assessment-grades");
  const subjectBox = document.querySelector("#assessment-subjects");
  const datalist = document.querySelector("#assessment-topic-list");
  const makeChip = (name, value, checked, extraClass) => {
    const label = document.createElement("label");
    label.className = `gen-chip ${extraClass}`.trim();
    const input = Object.assign(document.createElement("input"), { type: "radio", name, value, checked });
    label.append(input);
    return { label, input };
  };
  assessmentGrades.forEach((grade) => {
    const { label } = makeChip("assessment-grade", String(grade), grade === wantedGrade, "");
    const text = document.createElement("span");
    text.dataset.grade = String(grade);
    label.append(text);
    gradeBox.append(label);
  });
  subjectCatalog.forEach((subject) => {
    const { label } = makeChip("assessment-subject", subject.id, subject.id === wantedSubject, "gen-subject");
    const icon = Object.assign(document.createElement("span"), { className: "gen-subject-icon", textContent: subject.icon });
    const text = document.createElement("span");
    text.dataset.subjectKey = subject.key;
    label.append(icon, text);
    subjectBox.append(label);
  });
  const defaultDifficulty = readLocalSetting(learningDifficultyKey, "hard");
  if (["easy", "medium", "hard"].includes(defaultDifficulty)) {
    const level = document.querySelector(`input[name="assessment-level"][value="${defaultDifficulty}"]`);
    if (level) level.checked = true;
  }
  const refresh = () => {
    gradeBox.querySelectorAll("[data-grade]").forEach((el) => { el.textContent = `${el.dataset.grade}${tr("pq_grade_suffix")}`; });
    subjectBox.querySelectorAll("[data-subject-key]").forEach((el) => { el.textContent = tr(el.dataset.subjectKey); });
    const grade = Number(document.querySelector('input[name="assessment-grade"]:checked')?.value);
    const subject = document.querySelector('input[name="assessment-subject"]:checked')?.value;
    datalist.replaceChildren(...topicsFor(subject, grade).map((topic) => Object.assign(document.createElement("option"), { value: topic })));
  };
  document.querySelector("#assessment-form").addEventListener("change", refresh);
  document.addEventListener("testavimai:language-changed", refresh);
  refresh();
});

document.querySelector("#assessment-form").addEventListener("click", (event) => {
  const countInput = document.querySelector("#assessment-count");
  const stepButton = event.target.closest("[data-count-step]");
  const presetButton = event.target.closest("[data-count-preset]");
  if (!stepButton && !presetButton) return;
  const current = Number(countInput.value) || 1;
  const next = presetButton ? Number(presetButton.dataset.countPreset) : current + Number(stepButton.dataset.countStep);
  countInput.value = String(Math.min(50, Math.max(1, next)));
});

function assessmentHistoryKey(grade, subject, topic) {
  const normalizedTopic = topic.trim().toLocaleLowerCase();
  return `testavimai-assessment-history-${grade}-${subject}-${encodeURIComponent(normalizedTopic)}`;
}

function readAssessmentHistory(key) {
  try {
    const stored = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(stored)
      ? stored.filter((prompt) => typeof prompt === "string" && prompt.length <= 600).slice(-8)
      : [];
  } catch (error) {
    console.error("Nepavyko nuskaityti ankstesnių AI užduočių.", error);
    return [];
  }
}

function saveAssessmentHistory(key, questions) {
  const history = [...readAssessmentHistory(key), ...questions.map((question) => question.prompt)]
    .filter((prompt) => typeof prompt === "string" && prompt.length <= 600)
    .slice(-8);
  try {
    localStorage.setItem(key, JSON.stringify(history));
  } catch (error) {
    console.error("Nepavyko išsaugoti ankstesnių AI užduočių.", error);
  }
}

document.querySelector("#assessment-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = document.querySelector("#assessment-status");
  const submit = form.querySelector('[type="submit"]');
  const grade = Number(form.querySelector('input[name="assessment-grade"]:checked')?.value);
  const subject = form.querySelector('input[name="assessment-subject"]:checked')?.value || "";
  const topic = document.querySelector("#assessment-topic").value.trim();
  const level = form.querySelector('input[name="assessment-level"]:checked')?.value || "hard";
  const count = Number(document.querySelector("#assessment-count").value);
  const historyKey = assessmentHistoryKey(grade, subject, topic);
  const previousQuestions = readAssessmentHistory(historyKey);
  submit.disabled = true;
  status.hidden = false;
  status.className = "tutor-response assessment-status is-loading";
  status.replaceChildren(Object.assign(document.createElement("p"), {
    textContent: tr("pq_as_loading", { n: count, topic }),
  }));
  try {
    const { generateAssessmentQuestions } = await import("./progress.js");
    const questions = await generateAssessmentQuestions({ grade, subject, topic, count, level, previousQuestions });
    saveAssessmentHistory(historyKey, questions);
    status.className = "tutor-response assessment-status";
    status.replaceChildren(Object.assign(document.createElement("p"), {
      textContent: tr("pq_as_found", { n: questions.length }),
    }));
    startGeneratedPractice(questions, subject, topic);
  } catch (error) {
    console.error("Nepavyko sukurti atsiskaitymo praktikos užduočių.", error);
    status.className = "tutor-response assessment-status is-error";
    status.replaceChildren(Object.assign(document.createElement("p"), { textContent: error.message }));
    if (/prisijung/i.test(error.message)) {
      const signIn = document.createElement("a");
      signIn.href = `prisijungimas.html?redirect=${encodeURIComponent("praktika.html?veikla=assessment")}`;
      signIn.textContent = "Prisijungti ir tęsti →";
      signIn.className = "tutor-sign-in-link";
      status.append(signIn);
    }
  } finally {
    submit.disabled = false;
  }
});

const buddyNameInput = document.querySelector("#buddy-name");
const buddyHeadingName = document.querySelector("#buddy-heading-name");
const buddyMoodInput = document.querySelector("#buddy-mood");
const buddyStyleInput = document.querySelector("#buddy-style");
const tutorGradeInput = document.querySelector("#tutor-grade");
try {
  const savedBuddyName = localStorage.getItem(buddyNameKey);
  if (savedBuddyName) buddyNameInput.value = savedBuddyName;
  const savedMood = localStorage.getItem(buddyMoodKey);
  if ([...buddyMoodInput.options].some((option) => option.value === savedMood)) buddyMoodInput.value = savedMood;
  const savedStyle = localStorage.getItem(buddyStyleKey);
  if ([...buddyStyleInput.options].some((option) => option.value === savedStyle)) buddyStyleInput.value = savedStyle;
  const savedGrade = localStorage.getItem(learningGradeKey);
  if ([...tutorGradeInput.options].some((option) => option.value === savedGrade)) tutorGradeInput.value = savedGrade;
} catch (error) {
  console.error("Nepavyko nuskaityti AI draugo nustatymų.", error);
}
buddyHeadingName.textContent = buddyNameInput.value.trim() || "Mokis";
buddyNameInput.addEventListener("input", () => {
  const name = buddyNameInput.value.trim().slice(0, 24) || "Mokis";
  buddyHeadingName.textContent = name;
  try {
    localStorage.setItem(buddyNameKey, name);
  } catch (error) {
    console.error("Nepavyko išsaugoti mokytojo vardo.", error);
  }
});
buddyMoodInput.addEventListener("change", () => {
  try {
    localStorage.setItem(buddyMoodKey, buddyMoodInput.value);
  } catch (error) {
    console.error("Nepavyko išsaugoti AI draugo nuotaikos.", error);
  }
});
buddyStyleInput.addEventListener("change", () => {
  try {
    localStorage.setItem(buddyStyleKey, buddyStyleInput.value);
  } catch (error) {
    console.error("Nepavyko išsaugoti AI draugo mokymo stiliaus.", error);
  }
});
tutorGradeInput.addEventListener("change", () => {
  try {
    localStorage.setItem(learningGradeKey, tutorGradeInput.value);
  } catch (error) {
    console.error("Nepavyko išsaugoti mokymosi klasės.", error);
  }
});
window.addEventListener("storage", (event) => {
  if (event.key === buddyNameKey && event.newValue) {
    buddyNameInput.value = event.newValue;
    buddyHeadingName.textContent = event.newValue;
  }
  if (event.key === buddyMoodKey && event.newValue && [...buddyMoodInput.options].some((option) => option.value === event.newValue)) {
    buddyMoodInput.value = event.newValue;
  }
  if (event.key === buddyStyleKey && event.newValue && [...buddyStyleInput.options].some((option) => option.value === event.newValue)) {
    buddyStyleInput.value = event.newValue;
  }
  if (event.key === learningGradeKey && event.newValue && [...tutorGradeInput.options].some((option) => option.value === event.newValue)) {
    tutorGradeInput.value = event.newValue;
  }
});

document.querySelector("#tutor-images").addEventListener("change", (event) => {
  const files = [...event.target.files];
  const imageLimit = progressSnapshot.is_premium ? 10 : Math.max(0, Number(progressSnapshot.daily_images_remaining ?? 5));
  const count = document.querySelector("#tutor-image-count");
  count.textContent = progressSnapshot.is_premium
    ? `${files.length} nuotraukų pasirinkta · neribota dienos riba`
    : `${files.length} pasirinkta · šiandien liko ${imageLimit} iš 5`;
  count.classList.toggle("is-error", files.length > imageLimit);
});

function appendTutorInline(parent, text) {
  text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).forEach((part) => {
    if (!part) return;
    if (part.length > 4 && part.startsWith("**") && part.endsWith("**")) {
      const strong = document.createElement("strong");
      strong.textContent = part.slice(2, -2);
      parent.append(strong);
    } else if (part.length > 2 && part.startsWith("`") && part.endsWith("`")) {
      const code = document.createElement("code");
      code.textContent = part.slice(1, -1);
      parent.append(code);
    } else {
      parent.append(part.replace(/\*+/g, ""));
    }
  });
}

function renderTutorAnswer(text) {
  const root = document.createElement("div");
  root.className = "tutor-answer";
  const lines = String(text).replace(/\r/g, "").split("\n");
  const isTable = (line) => line.trim().startsWith("|");
  const isBullet = (line) => /^\s*[-*•]\s+/.test(line);
  const isOrdered = (line) => /^\s*\d+[.)]\s+/.test(line);
  const isHeading = (line) => /^\s*#{1,6}\s+/.test(line);
  const isRule = (line) => /^\s*(-{3,}|\*{3,})\s*$/.test(line);
  const splitCells = (line) => line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((cell) => cell.trim());
  let index = 0;
  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim() || isRule(line)) {
      index += 1;
    } else if (isTable(line)) {
      const rows = [];
      while (index < lines.length && isTable(lines[index])) rows.push(splitCells(lines[index++]));
      const isSeparator = (row) => row.every((cell) => /^:?-+:?$/.test(cell));
      const hasHeader = rows.length > 1 && isSeparator(rows[1]);
      const table = document.createElement("table");
      rows.filter((row) => !isSeparator(row)).forEach((row, rowIndex) => {
        const tr = document.createElement("tr");
        row.forEach((cell) => {
          const td = document.createElement(hasHeader && rowIndex === 0 ? "th" : "td");
          appendTutorInline(td, cell);
          tr.append(td);
        });
        table.append(tr);
      });
      const wrap = document.createElement("div");
      wrap.className = "tutor-table-wrap";
      wrap.append(table);
      root.append(wrap);
    } else if (isHeading(line)) {
      const heading = document.createElement("h4");
      appendTutorInline(heading, line.replace(/^\s*#{1,6}\s+/, ""));
      root.append(heading);
      index += 1;
    } else if (isBullet(line) || isOrdered(line)) {
      const ordered = isOrdered(line);
      const list = document.createElement(ordered ? "ol" : "ul");
      while (index < lines.length && (ordered ? isOrdered(lines[index]) : isBullet(lines[index]))) {
        const item = document.createElement("li");
        appendTutorInline(item, lines[index].replace(ordered ? /^\s*\d+[.)]\s+/ : /^\s*[-*•]\s+/, ""));
        list.append(item);
        index += 1;
      }
      root.append(list);
    } else {
      const paragraph = document.createElement("p");
      const parts = [];
      while (index < lines.length && lines[index].trim() && !isTable(lines[index]) && !isHeading(lines[index]) && !isBullet(lines[index]) && !isOrdered(lines[index]) && !isRule(lines[index])) {
        parts.push(lines[index].trim());
        index += 1;
      }
      appendTutorInline(paragraph, parts.join(" "));
      root.append(paragraph);
    }
  }
  return root;
}

document.querySelector("#tutor-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const response = document.querySelector("#tutor-response");
  const question = document.querySelector("#tutor-question").value.trim();
  const imageFiles = [...document.querySelector("#tutor-images").files];
  const submit = event.currentTarget.querySelector('[type="submit"]');
  submit.disabled = true;
  response.className = "tutor-response is-loading";
  response.replaceChildren(Object.assign(document.createElement("p"), { textContent: `${buddyHeadingName.textContent} ruošia trumpą paaiškinimą…` }));
  try {
    const { askStudyBuddy, getMyProgress } = await import("./progress.js");
    const result = await askStudyBuddy({
      question,
      buddyName: buddyNameInput.value,
      grade: Number(document.querySelector("#tutor-grade").value),
      mood: buddyMoodInput.value,
      teachingStyle: buddyStyleInput.value,
      imageFiles,
    });
    response.className = "tutor-response";
    const mark = document.createElement("span");
    mark.className = "tutor-response-mark";
    mark.textContent = "✦";
    const answer = renderTutorAnswer(result.answer);
    response.replaceChildren(mark, answer);
    document.querySelector("#tutor-question").value = "";
    document.querySelector("#tutor-images").value = "";
    updateProgressDisplay(await getMyProgress());
  } catch (error) {
    console.error("AI mokytojo užklausa nepavyko.", error);
    response.className = "tutor-response is-error";
    const message = document.createElement("p");
    message.textContent = error.message;
    response.replaceChildren(message);
    if (/prisijung/i.test(error.message)) {
      const signIn = document.createElement("a");
      signIn.href = `prisijungimas.html?redirect=${encodeURIComponent("praktika.html?veikla=ai")}`;
      signIn.textContent = "Prisijungti ir tęsti →";
      signIn.className = "tutor-sign-in-link";
      response.append(signIn);
    } else if (/nesukonfigūruotas|serverio nustatymus/i.test(error.message)) {
      const setupNote = document.createElement("p");
      setupNote.textContent = "AI serverio paslaugą turi įjungti svetainės administratorius.";
      response.append(setupNote);
    }
  } finally {
    submit.disabled = false;
  }
});

const requestedTopic = initialPracticeParams.get("dalykas");
const requestedPracticeParams = initialPracticeParams;
const difficultyFilter = document.querySelector("#practice-difficulty-filter");
const typeFilter = document.querySelector("#practice-type-filter");
function applyFavoriteSubjectOrder(selectedValue) {
  const allOption = topicPicker.querySelector('option[value="all"]');
  const options = [...topicPicker.options].filter((option) => option.value !== "all");
  let favorites = [];
  try {
    const saved = JSON.parse(readLocalSetting(learningFavoritesKey, "[]"));
    if (Array.isArray(saved)) favorites = saved.filter((value) => options.some((option) => option.value === value));
  } catch (error) {
    console.error("Nepavyko nuskaityti mėgstamų mokomųjų dalykų.", error);
  }
  topicPicker.replaceChildren(allOption);
  if (favorites.length) {
    const favoriteGroup = document.createElement("optgroup");
    favoriteGroup.label = "Mėgstami dalykai";
    const otherGroup = document.createElement("optgroup");
    otherGroup.label = "Kiti dalykai";
    options.forEach((option) => (favorites.includes(option.value) ? favoriteGroup : otherGroup).append(option));
    topicPicker.append(favoriteGroup, otherGroup);
  } else {
    topicPicker.append(...options);
  }
  const preferredSubject = requestedTopic || readLocalSetting(learningSubjectKey, "all");
  const selectedSubject = selectedValue || preferredSubject;
  topicPicker.value = [...topicPicker.options].some((option) => option.value === selectedSubject) ? selectedSubject : "all";
}
applyFavoriteSubjectOrder();
const savedDifficulty = requestedPracticeParams.get("sudetingumas") || readLocalSetting(learningDifficultyKey, "all");
if ([...difficultyFilter.options].some((option) => option.value === savedDifficulty)) {
  difficultyFilter.value = savedDifficulty;
}
if ([...typeFilter.options].some((option) => option.value === requestedPracticeParams.get("tipas"))) {
  typeFilter.value = requestedPracticeParams.get("tipas");
}
if ([...topicPicker.options].some((option) => option.value === requestedTopic)) {
  topicPicker.value = requestedTopic;
  topicPicker.dispatchEvent(new Event("change"));
} else {
  updatePracticeLinks();
}
const hasExplicitPracticeFilters = ["dalykas", "sudetingumas", "tipas"].some((key) => requestedPracticeParams.has(key));
window.addEventListener("storage", (event) => {
  if (event.key === learningFavoritesKey) applyFavoriteSubjectOrder(topicPicker.value);
  if (event.key === learningSubjectKey && !requestedTopic) applyFavoriteSubjectOrder(topicPicker.value === "all" ? "" : topicPicker.value);
  if (event.key === learningDifficultyKey && !requestedPracticeParams.has("sudetingumas")
    && [...difficultyFilter.options].some((option) => option.value === event.newValue)) {
    difficultyFilter.value = event.newValue;
    updateQuestionFilterSummary();
    updatePracticeLinks();
  }
});

const dailyChallenge = document.querySelector('[data-mode="daily"]');
if (dailyChallenge) dailyChallenge.id = "daily-challenge";

renderRewards();
renderLearningSummary();
document.addEventListener("testavimai:subject-progress", (event) => renderLearningSummary(event.detail));
import("./learning-summary.js").then(({ getTestHistory }) => renderTestHistory(getTestHistory()))
  .catch((error) => console.error("Testų istorijos įkelti nepavyko.", error));
import("./progress.js").then(({ getMyProgress }) => getMyProgress())
  .then(updateProgressDisplay)
  .catch((error) => {
    console.error("Nepavyko įkelti mokymosi pažangos.", error);
    const note = document.querySelector("#practice-progress-note");
    if (note) note.textContent = `Pažangos įkelti nepavyko: ${error.message}`;
  });

const weeklyGoals = [...document.querySelectorAll("[data-week-goal]")];
const weeklyQuestionTarget = document.querySelector("#weekly-question-target");
const weeklyQuestionTargetValue = document.querySelector("#weekly-question-target-value");
try {
  const savedGoals = new Set(JSON.parse(localStorage.getItem(weeklyPlanKey) || "[]"));
  weeklyGoals.forEach((goal) => { goal.checked = savedGoals.has(goal.dataset.weekGoal); });
} catch (error) {
  console.error("Nepavyko nuskaityti savaitės plano.", error);
}
if (weeklyQuestionTarget && weeklyQuestionTargetValue) {
  const savedTarget = Number(localStorage.getItem(`${weeklyPlanKey}-target`) || 20);
  weeklyQuestionTarget.value = String([5, 10, 20, 30, 50, 100].includes(savedTarget) ? savedTarget : 20);
  async function updateWeeklyQuestionProgress() {
    try {
      const { getWeeklyQuestionCount } = await import("./learning-summary.js");
      const completed = getWeeklyQuestionCount();
      const target = Number(weeklyQuestionTarget.value);
      weeklyQuestionTargetValue.max = target;
      weeklyQuestionTargetValue.value = Math.min(completed, target);
      weeklyQuestionTargetValue.textContent = `${Math.min(completed, target)} iš ${target}`;
      document.querySelector("#weekly-question-progress-label").textContent =
        completed >= target
          ? `Savaitės tikslas pasiektas: ${questionCountLabel(completed)} (tikslas – ${questionCountLabel(target)}).`
          : `Atsakyta ${completed} iš ${target} klausimų šią savaitę.`;
    } catch (error) {
      console.error("Savaitės klausimų progreso įkelti nepavyko.", error);
      document.querySelector("#weekly-question-progress-label").textContent = "Savaitės progreso įkelti nepavyko.";
    }
  }
  weeklyQuestionTarget.addEventListener("change", () => {
    try {
      localStorage.setItem(`${weeklyPlanKey}-target`, weeklyQuestionTarget.value);
      void updateWeeklyQuestionProgress();
    } catch (error) {
      console.error("Savaitės klausimų tikslo išsaugoti nepavyko.", error);
      document.querySelector("#weekly-question-progress-label").textContent = "Tikslo išsaugoti nepavyko. Patikrink naršyklės saugyklą.";
    }
  });
  void updateWeeklyQuestionProgress();
}
weeklyGoals.forEach((goal) => {
  goal.addEventListener("change", () => {
    try {
      const checked = weeklyGoals.filter((item) => item.checked).map((item) => item.dataset.weekGoal);
      localStorage.setItem(weeklyPlanKey, JSON.stringify(checked));
      document.querySelector("#weekly-plan-status").textContent = tr("pq_week_status", { n: checked.length, m: weeklyGoals.length });
    } catch (error) {
      console.error("Nepavyko išsaugoti savaitės plano.", error);
      document.querySelector("#weekly-plan-status").textContent = "Nepavyko išsaugoti plano. Patikrink naršyklės saugyklos leidimus.";
    }
  });
});

const practiceView = new URLSearchParams(window.location.search).get("veikla");
const practiceViewTargets = {
  ai: "#study-buddy",
  assessment: "#atsiskaitymui",
  entrance: "#entrance-test-panel",
  rewards: "#rewards",
  achievements: "#achievements",
  tips: "#tips",
  weekly: "#weekly-plan",
  quick: "#practice-session",
  daily: "#practice-session",
  review: "#practice-session",
  flashcards: "#practice-session",
  timed: "#practice-session",
};
const practiceViewTarget = Object.prototype.hasOwnProperty.call(practiceViewTargets, practiceView)
  ? practiceViewTargets[practiceView]
  : null;
if (practiceViewTarget) {
  const main = document.querySelector("main");
  const isGuestRewardsView = ["rewards", "achievements"].includes(practiceView)
    && document.body.classList.contains("guest-mode");
  const target = document.querySelector(isGuestRewardsView ? "#rewards-guest-notice" : practiceViewTarget);
  const backLink = document.querySelector(".practice-focused-back");
  const visibleSections = practiceView === "rewards" && !isGuestRewardsView
    ? [target, document.querySelector("#achievements")]
    : [target];
  [...main.children].forEach((section) => {
    section.hidden = !visibleSections.includes(section) && section !== backLink;
  });
  visibleSections.forEach((section) => { section.hidden = false; });
  backLink.hidden = false;
  target.classList.add("is-visible");
  document.body.dataset.practiceView = practiceView;
  const pageHeading = target.querySelector("h1, h2");
  const practiceViewTitleKeys = {
    quick: "c2_t",
    daily: "pq_daily",
    review: "c10_t",
    flashcards: "c5_t",
    timed: "c9_t",
  };
  const titleKey = practiceViewTitleKeys[practiceView];
  const headingText = pageHeading?.textContent.trim() || (titleKey ? tr(titleKey) : "");
  if (headingText) document.title = `${headingText} — Testavimai`;

  switch (practiceView) {
    case "quick":
      void startQuiz({ count: 10, titleKey: "c2_t", useAllQuestions: !hasExplicitPracticeFilters });
      break;
    case "daily":
      void startQuiz({ count: 10, titleKey: "pq_daily", daily: true });
      break;
    case "review":
      void startQuiz({ count: practiceQuestions.length, titleKey: "c10_t", review: true });
      break;
    case "flashcards":
      startFlashcards();
      break;
    case "timed":
      void startQuiz({ count: 5, titleKey: "c9_t", timed: true, useAllQuestions: !hasExplicitPracticeFilters });
      break;
    default:
      break;
  }
}

document.addEventListener("testavimai:language-changed", () => {
  if (session.hidden) return;
  if (sessionTitleKey) sessionTitle.textContent = tr(sessionTitleKey);
  if (sessionBody.querySelector(".practice-quiz-question") && !answered) renderQuizQuestion();
});

document.addEventListener("testavimai:coins-changed", (event) => {
  updateProgressDisplay({ ...progressSnapshot, reward_coins: event.detail });
});
