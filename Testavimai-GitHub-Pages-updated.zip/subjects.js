// Mokomųjų dalykų katalogas. Temos sugrupuotos pagal Lietuvos bendrojo ugdymo programų klasių koncentrus.
export const gradeBands = [
  { id: "5-6", grades: [5, 6] },
  { id: "7-8", grades: [7, 8] },
  { id: "9-10", grades: [9, 10] },
  { id: "11-12", grades: [11, 12] },
];

export const grades = [5, 6, 7, 8, 9, 10, 11, 12];

export const subjectCatalog = [
  {
    id: "lietuviu", key: "subj_litlit", icon: "Ą", label: "KALBA IR KŪRINIAI",
    lead: "Rašyba, skyryba, kalbos dalys, stilius ir literatūros kūrinių analizė.",
    topics: {
      "5-6": ["Žodžių rašyba ir kirčiavimas", "Kalbos dalys", "Sakinio dalys", "Pasakos ir padavimai"],
      "7-8": ["Skyryba sudėtiniuose sakiniuose", "Kalbos stiliai", "Poezijos priemonės", "Epas ir dramos kūriniai"],
      "9-10": ["Sintaksė ir skyryba", "Teksto kūrimas ir argumentavimas", "Baroko ir klasicizmo literatūra", "XIX a. lietuvių literatūra"],
      "11-12": ["Kalbos kultūra ir norma", "Esė ir samprotaujamasis rašinys", "XX a. lietuvių literatūra", "Šiuolaikinė literatūra"],
    },
  },
  {
    id: "matematika", key: "subj_math", icon: "∑", label: "SKAIČIAI IR LOGIKA",
    lead: "Skaičiavimai, lygtys, geometrija, funkcijos ir duomenų analizė.",
    topics: {
      "5-6": ["Natūralieji skaičiai ir veiksmai", "Trupmenos ir dešimtainės trupmenos", "Procentai", "Perimetras ir plotas"],
      "7-8": ["Veiksmai su racionaliaisiais skaičiais", "Tiesinės lygtys", "Proporcijos", "Pitagoro teorema"],
      "9-10": ["Kvadratinės lygtys", "Tiesinė ir kvadratinė funkcijos", "Trigonometrijos pradmenys", "Tikimybių pradmenys"],
      "11-12": ["Išvestinė ir jos taikymas", "Logaritmai ir rodiklinės funkcijos", "Stereometrija", "Statistika ir tikimybės"],
    },
  },
  {
    id: "fizika", key: "subj_phys", icon: "ϕ", label: "JĖGOS IR ENERGIJA",
    lead: "Judėjimas, jėgos, šiluma, elektra, šviesa ir šiuolaikinė fizika.",
    topics: {
      "5-6": ["Medžiagos savybės", "Matavimo vienetai", "Judėjimas ir greitis", "Šviesa ir šešėlis"],
      "7-8": ["Jėgos ir Niutono dėsniai", "Slėgis", "Mechaninis darbas ir energija", "Šiluminiai reiškiniai"],
      "9-10": ["Elektros grandinės ir Omo dėsnis", "Magnetiniai reiškiniai", "Mechaninės bangos ir garsas", "Optika"],
      "11-12": ["Kinematika ir dinamika", "Elektromagnetinė indukcija", "Kvantinė fizika", "Atomo ir branduolio fizika"],
    },
  },
  {
    id: "chemija", key: "subj_chem", icon: "⚗", label: "MEDŽIAGOS IR REAKCIJOS",
    lead: "Medžiagos, cheminės reakcijos, rūgštys ir bazės, organinė chemija.",
    topics: {
      "5-6": ["Medžiagų savybės", "Mišiniai ir jų skirstymas", "Vanduo ir oras", "Cheminiai ir fiziniai reiškiniai"],
      "7-8": ["Atomo sandara", "Periodinė elementų lentelė", "Cheminės formulės ir lygtys", "Oksidai, rūgštys, bazės, druskos"],
      "9-10": ["Tirpalai ir tirpumas", "Cheminės reakcijos greitis", "Metalai ir nemetalai", "Angliavandeniliai"],
      "11-12": ["Cheminė pusiausvyra", "Oksidacijos–redukcijos reakcijos", "Organinės junginių klasės", "Biomolekulės"],
    },
  },
  {
    id: "biologija", key: "subj_bio", icon: "✿", label: "GYVYBĖ IR GAMTA",
    lead: "Ląstelės, augalai, gyvūnai, žmogaus organizmas, genetika ir ekologija.",
    topics: {
      "5-6": ["Gyvieji organizmai ir jų požymiai", "Augalų sandara", "Gyvūnų įvairovė", "Ekosistemos"],
      "7-8": ["Ląstelė", "Fotosintezė ir kvėpavimas", "Žmogaus virškinimas ir kraujotaka", "Nervų sistema"],
      "9-10": ["Paveldimumas ir genetika", "Evoliucija", "Žmogaus lytinė sistema ir sveikata", "Ekologija"],
      "11-12": ["Ląstelės biochemija", "Baltymų sintezė", "Imunitetas", "Biotechnologijos"],
    },
  },
  {
    id: "geografija", key: "subj_geo", icon: "🌍", label: "ŽEMĖ IR ŽMONĖS",
    lead: "Žemėlapiai, gamtinės zonos, Lietuvos ir pasaulio regionai bei žmogaus veikla.",
    topics: {
      "5-6": ["Žemėlapis ir orientavimasis", "Žemės rutulys ir koordinatės", "Reljefas ir vandenys", "Lietuvos gamta"],
      "7-8": ["Atmosfera ir klimatas", "Gamtinės zonos", "Žemynai ir vandenynai", "Gyventojai ir ūkis"],
      "9-10": ["Europos regionai", "Lietuvos ūkis", "Pasaulio gyventojai ir urbanizacija", "Gamtos ištekliai"],
      "11-12": ["Globalizacija", "Klimato kaita", "Regioninė geografija", "Darnus vystymasis"],
    },
  },
  {
    id: "istorija", key: "subj_hist", icon: "◷", label: "LIETUVOS IR PASAULIO ISTORIJA",
    lead: "Svarbios datos, asmenybės ir įvykiai, susieti su jų priežastimis ir reikšme.",
    topics: {
      "5-6": ["Senovės civilizacijos", "Baltų gentys", "Lietuvos valstybės užuomazgos", "Mindaugas ir karalystė"],
      "7-8": ["Lietuvos Didžioji Kunigaikštystė", "Žalgirio mūšis", "Lietuvos krikštas", "Renesansas ir Reformacija"],
      "9-10": ["Abiejų Tautų Respublika", "Lietuva XIX a.", "1918 m. Nepriklausomybės aktas", "Tarpukario Lietuva"],
      "11-12": ["Antrasis pasaulinis karas", "Sovietinė okupacija", "Sąjūdis ir 1990 m. kovo 11-oji", "Lietuva Europos Sąjungoje"],
    },
  },
  {
    id: "informatika", key: "subj_it", icon: "⌨", label: "SKAITMENINĖS TECHNOLOGIJOS",
    lead: "Algoritmai, programavimas, duomenys, tinklai ir saugus elgesys internete.",
    topics: {
      "5-6": ["Kompiuterio dalys", "Saugus elgesys internete", "Tekstų rengyklė", "Paprasti algoritmai"],
      "7-8": ["Skaičiuoklė", "Pristatymų rengimas", "Programavimo pagrindai", "Duomenų paieška ir vertinimas"],
      "9-10": ["Ciklai ir sąlygos", "Duomenų struktūros", "Kompiuterių tinklai", "Informacijos saugumas"],
      "11-12": ["Algoritmų sudėtingumas", "Duomenų bazės ir SQL", "Objektinis programavimas", "Dirbtinis intelektas"],
    },
  },
  {
    id: "muzika", key: "subj_music", icon: "♪", label: "GARSAI IR KŪRYBA",
    lead: "Muzikos raštas, ritmas, instrumentai, žanrai ir kompozitoriai.",
    topics: {
      "5-6": ["Natos ir pauzės", "Ritmas ir metras", "Orkestro instrumentai", "Lietuvių liaudies dainos"],
      "7-8": ["Gamos ir intervalai", "Muzikos formos", "Čiurlionis ir lietuvių kompozitoriai", "Džiazas ir populiarioji muzika"],
      "9-10": ["Barokas ir klasicizmas", "Romantizmas muzikoje", "Akordai ir harmonija", "Muzikos žanrai"],
      "11-12": ["XX a. muzika", "Šiuolaikiniai lietuvių kūrėjai", "Muzikos analizė", "Muzika ir technologijos"],
    },
  },
  {
    id: "anglu", key: "subj_en", icon: "A", label: "ANGLŲ KALBA",
    lead: "Žodynas, gramatika, skaitymas ir rašymas pagal Europos kalbų aprašą (A1–C1).",
    topics: {
      "5-6": ["Present Simple ir Continuous", "Šeima, namai ir mokykla", "Daiktavardžių daugiskaita", "Skaičiai ir laikas"],
      "7-8": ["Past Simple ir Present Perfect", "Palyginimo laipsniai", "Keliavimas ir pirkiniai", "Modaliniai veiksmažodžiai"],
      "9-10": ["Conditionals", "Passive Voice", "Reported Speech", "Neoficialus laiškas"],
      "11-12": ["Idiomos ir frazeologiniai veiksmažodžiai", "Samprotaujamasis rašinys", "Skaitymo supratimas", "Žodžių daryba"],
    },
  },
  {
    id: "vokieciu", key: "subj_de", icon: "ß", label: "VOKIEČIŲ KALBA",
    lead: "Žodynas, linksniai, laikai ir kasdienis bendravimas (A1–B2).",
    topics: {
      "5-6": ["Pasisveikinimas ir prisistatymas", "Artikeliai ir daiktavardžių gimines", "Skaičiai ir spalvos", "Šeima ir mokykla"],
      "7-8": ["Linksniai: Nominativ ir Akkusativ", "Perfekt", "Atskiriamieji veiksmažodžiai", "Kasdienė veikla"],
      "9-10": ["Dativ ir Genitiv", "Šalutiniai sakiniai", "Būtasis laikas Präteritum", "Keliavimas ir sveikata"],
      "11-12": ["Konjunktiv II", "Pasyvas", "Santykiniai sakiniai", "Skaitymas ir rašymas B2 lygiu"],
    },
  },
  {
    id: "ispanu", key: "subj_es", icon: "Ñ", label: "ISPANŲ KALBA",
    lead: "Žodynas, veiksmažodžių asmenavimas ir kasdienis bendravimas (A1–B2).",
    topics: {
      "5-6": ["Pasisveikinimas ir prisistatymas", "Ser ir estar", "Skaičiai ir spalvos", "Šeima ir namai"],
      "7-8": ["Presente de indicativo", "Pretérito perfecto", "Reflexyviniai veiksmažodžiai", "Maistas ir pirkiniai"],
      "9-10": ["Pretérito indefinido ir imperfecto", "Futuro simple", "Gustar ir panašūs veiksmažodžiai", "Keliavimas"],
      "11-12": ["Subjuntivo", "Condicional", "Santykiniai sakiniai", "Skaitymas ir rašymas B2 lygiu"],
    },
  },
  {
    id: "rusu", key: "subj_ru", icon: "Я", label: "РУССКИЙ ЯЗЫК",
    lead: "Žodynas, linksniai, veiksmažodžių aspektai ir skaitymas (A1–B2).",
    topics: {
      "5-6": ["Rusų abėcėlė ir skaitymas", "Prisistatymas ir šeima", "Daiktavardžių gimines", "Skaičiai ir laikas"],
      "7-8": ["Linksniai (padeži)", "Veiksmažodžių asmenavimas", "Būdvardžiai", "Kasdienis bendravimas"],
      "9-10": ["Veiksmažodžių aspektai", "Judėjimo veiksmažodžiai", "Būtasis ir būsimasis laikas", "Sudėtiniai sakiniai"],
      "11-12": ["Dalyviai ir pusdalyviai", "Stiliai ir kalbos kultūra", "Skaitymo supratimas", "Rašinys B2 lygiu"],
    },
  },
  {
    id: "prancuzu", key: "subj_fr", icon: "É", label: "FRANÇAIS",
    lead: "Žodynas, gramatika ir bendravimas (A1–B2).",
    topics: {
      "5-6": ["Pasisveikinimas ir prisistatymas", "Artikeliai", "Skaičiai ir spalvos", "Šeima ir mokykla"],
      "7-8": ["Présent", "Passé composé", "Neiginys ir klausimai", "Maistas ir pirkiniai"],
      "9-10": ["Imparfait ir passé composé", "Futur simple", "Įvardžiai COD ir COI", "Keliavimas"],
      "11-12": ["Subjonctif", "Conditionnel", "Santykiniai įvardžiai", "Skaitymas ir rašymas B2 lygiu"],
    },
  },
];

export const subjectById = (id) => subjectCatalog.find((subject) => subject.id === id);
export const bandForGrade = (grade) => gradeBands.find((band) => band.grades.includes(Number(grade)))?.id || "7-8";
export const topicsFor = (subjectId, grade) => subjectById(subjectId)?.topics[bandForGrade(grade)] || [];
