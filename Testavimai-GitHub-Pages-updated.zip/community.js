import {
  getLeaderboard,
  getMyTeacherPurchases,
  getMyProgress,
  getMyTeacherPremiumUntil,
  getPublicProfile,
  createTeacherCheckoutSession,
  getTeacherPurchaseCodes,
  redeemTeacherPremiumCode,
  updateCommunityProfile,
  uploadAvatar,
} from "./progress.js";
import { validateProfileBio, validateProfileName } from "./profile-policy.js";

const status = document.querySelector("#community-status, #profile-community-status");
const guestMode = sessionStorage.getItem("testavimai-demo-guest") === "true";
const guestAvatarKey = "testavimai-guest-avatar";

function setStatus(message, kind = "info") {
  if (!status) return;
  status.textContent = message;
  status.className = `community-status ${kind}`;
}

function initials(name) {
  return String(name || "M").split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toLocaleUpperCase("lt");
}

function avatarBadgeType(profile) {
  const isCreator = profile.is_creator || (profile.achievements || []).some((badge) => badge.id === "creator" && badge.earned);
  if (isCreator) return { key: "creator", icon: "✦", title: "Kūrėjas" };
  if (profile.is_premium) return { key: "premium", icon: "◆", title: "Premium" };
  return null;
}

function avatarElement(profile, className = "community-avatar") {
  const avatar = document.createElement("span");
  avatar.className = className;
  if (profile.avatar_url) {
    const image = document.createElement("img");
    image.src = profile.avatar_url;
    image.alt = "";
    avatar.append(image);
  } else {
    avatar.textContent = initials(profile.display_name);
  }
  appendAvatarBadge(avatar, profile);
  return avatar;
}

function appendAvatarBadge(avatar, profile) {
  avatar.querySelector(".avatar-badge")?.remove();
  const type = avatarBadgeType(profile);
  if (!type) return;
  const badge = document.createElement("span");
  badge.className = `avatar-badge avatar-badge-${type.key}`;
  badge.textContent = type.icon;
  badge.title = type.title;
  badge.setAttribute("role", "img");
  badge.setAttribute("aria-label", type.title);
  avatar.append(badge);
}

function profileBadges(profile) {
  const badges = (profile.achievements || [])
    .filter((badge) => badge.earned)
    .map((badge) => ({ id: badge.id, title: badge.title, icon: badge.icon }));
  const lifetimeXp = Number(profile.lifetime_xp ?? profile.xp ?? 0);
  for (const [threshold, title, icon] of [
    [100, "100 XP", "✦"],
    [1000, "1 000 XP", "✧"],
    [5000, "5 000 XP", "♛"],
  ]) {
    if (lifetimeXp >= threshold && !badges.some((badge) => badge.id === `xp-${threshold}`)) {
      badges.push({ id: `xp-${threshold}`, title, icon });
    }
  }
  if (profile.is_premium) badges.push({ id: "premium", title: "Premium", icon: "◆", premium: true });
  return badges;
}

function renderEarnedBadges(container, badges, featuredBadgeId = null) {
  if (!container) return;
  container.replaceChildren();
  for (const badge of badges) {
    const item = document.createElement("span");
    item.className = `profile-earned-badge${badge.premium ? " is-premium" : ""}${badge.id === featuredBadgeId ? " is-featured" : ""}`;
    item.textContent = `${badge.icon} ${badge.title}${badge.id === featuredBadgeId ? " · pasirinktas" : ""}`;
    container.append(item);
  }
  container.hidden = badges.length === 0;
}

function formatDate(value) {
  if (!value) return "Nenurodyta";
  return new Intl.DateTimeFormat(document.documentElement.lang || "lt", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(value));
}

async function showLeaderboard() {
  if (guestMode) {
    const list = document.querySelector("#leaderboard-list");
    list?.replaceChildren();
    setStatus("Svečiai leaderboard nerodomi. Prisijunk arba susikurk paskyrą, kad galėtum dalyvauti.");
    return;
  }
  const members = await getLeaderboard();
  const list = document.querySelector("#leaderboard-list");
  if (!members.length) {
    setStatus("Leaderboard dar tuščias. Užsiregistruok ir atlik pirmą praktikos testą!");
    return;
  }
  list.replaceChildren();
  members.slice(0, 10).forEach((member, index) => list.append(leaderboardRow(member, index)));
  status.hidden = true;
}

function leaderboardRow(member, index, highlightId = null) {
  const row = document.createElement("li");
  row.className = `leaderboard-row${index < 3 ? ` leaderboard-top-${index + 1}` : ""}${highlightId && member.user_id === highlightId ? " is-current-profile" : ""}`;
  const rank = document.createElement("span");
  rank.className = "leaderboard-rank";
  rank.textContent = String(index + 1).padStart(2, "0");
  const link = document.createElement("a");
  link.className = "leaderboard-member";
  link.href = `public-profile.html?id=${encodeURIComponent(member.user_id)}`;
  link.append(avatarElement(member));
  const name = document.createElement("strong");
  name.textContent = member.display_name || "Mokinys";
  link.append(name);
  const streak = document.createElement("span");
  streak.className = "leaderboard-streak";
  streak.textContent = `🔥 ${member.current_streak || 0}`;
  const points = document.createElement("strong");
  points.className = "leaderboard-points";
  points.textContent = `${member.xp || 0} XP`;
  row.append(rank, link, streak, points);
  return row;
}

async function showProfileLeaderboard(profileId) {
  const section = document.querySelector("#public-profile-leaderboard");
  const list = document.querySelector("#public-profile-lb-list");
  const rankLabel = document.querySelector("#public-profile-rank");
  if (!section || !list || guestMode) return;
  const members = (await getLeaderboard()).slice(0, 10);
  if (!members.length) return;
  list.replaceChildren();
  members.forEach((member, index) => list.append(leaderboardRow(member, index, profileId)));
  const position = members.findIndex((member) => member.user_id === profileId);
  const t = window.testavimai?.t;
  rankLabel.textContent = position >= 0 ? (t ? t("pp_rank", { n: position + 1 }) : `#${position + 1}`) : (t ? t("pp_rank_out") : "");
  rankLabel.classList.toggle("is-ranked", position >= 0);
  section.hidden = false;
}

async function showPublicProfile() {
  const profileId = new URLSearchParams(window.location.search).get("id");
  const card = document.querySelector("#public-profile-card");
  if (!profileId || !/^[0-9a-f-]{36}$/i.test(profileId)) {
    setStatus("Šio profilio nuoroda netinkama.", "error");
    return;
  }
  const profile = await getPublicProfile(profileId);
  if (profile.not_found) {
    setStatus("Tokio profilio nėra arba jis buvo pašalintas.", "error");
    return;
  }
  if (profile.is_private) {
    setStatus("Šis profilis privatus. Jo mokymosi informacija kitiems nerodoma.");
    return;
  }
  card.replaceChildren();
  const identity = document.createElement("div");
  identity.className = "public-profile-identity";
  identity.append(avatarElement(profile, "community-avatar community-avatar-large"));
  const title = document.createElement("div");
  const name = document.createElement("h1");
  name.textContent = profile.display_name || "Mokinys";
  const username = document.createElement("p");
  username.className = "public-profile-username";
  username.textContent = profile.username ? `@${profile.username}` : "";
  const memberSince = document.createElement("p");
  memberSince.textContent = `Paskyra sukurta ${formatDate(profile.created_at)}`;
  title.append(name, username, memberSince);
  if (profile.featured_badge_id) {
    const featuredBadge = profileBadges(profile).find((badge) => badge.id === profile.featured_badge_id);
    if (featuredBadge) {
      const badge = document.createElement("span");
      badge.className = `profile-earned-badge profile-featured-public-badge${featuredBadge.premium ? " is-premium" : ""}`;
      badge.textContent = `${featuredBadge.icon} ${featuredBadge.title}`;
      title.append(badge);
    }
  }
  identity.append(title);
  const bio = document.createElement("p");
  bio.className = "public-profile-bio";
  if (profile.bio) {
    bio.textContent = profile.bio;
  } else {
    bio.classList.add("is-empty");
    bio.textContent = window.testavimai?.t("pp_no_bio") || "";
  }
  card.append(identity, bio);
  const stats = document.createElement("div");
  stats.className = "public-profile-stats";
  for (const [label, value] of [
    ["Patirties taškai", `${profile.xp || 0} XP`],
    ["Dabartinė serija", `${profile.current_streak || 0} d.`],
    ["Geriausia serija", `${profile.best_streak || 0} d.`],
  ]) {
    const item = document.createElement("div");
    item.className = "public-profile-stat";
    const number = document.createElement("strong");
    number.textContent = value;
    const caption = document.createElement("span");
    caption.textContent = label;
    item.append(number, caption);
    stats.append(item);
  }
  card.append(stats);
  const badges = document.createElement("div");
  badges.className = "profile-badges public-profile-badges";
  renderEarnedBadges(badges, profileBadges(profile), profile.featured_badge_id);
  if (!badges.hidden) card.append(badges);
  showProfileLeaderboard(profileId).catch((error) => console.error("Nepavyko įkelti profilio leaderboard.", error));
}

async function prepareAvatarImage(file) {
  if (!file.type.startsWith("image/") || file.size > 15 * 1024 * 1024) {
    throw new Error("Pasirink nuotrauką iki 15 MB.");
  }
  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error("Šios nuotraukos formato naršyklė neatpažįsta. Pabandyk JPG, PNG arba WEBP.");
  }
  try {
    const scale = Math.min(1, 512 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Nepavyko paruošti profilio nuotraukos.");
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const image = await new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (blob?.type === "image/webp") resolve(blob);
        else reject(new Error("Naršyklė negalėjo konvertuoti profilio nuotraukos."));
      }, "image/webp", 0.86);
    });
    return new File([image], "profile-picture.webp", { type: "image/webp" });
  } finally {
    bitmap.close();
  }
}

function showOwnAvatar(avatar, source, profile) {
  if (!avatar) return;
  if (source) {
    const image = document.createElement("img");
    image.src = source;
    image.alt = "Profilio nuotrauka";
    const badge = avatar.querySelector(".avatar-badge");
    avatar.replaceChildren(image);
    if (badge) avatar.append(badge);
  }
  if (profile) appendAvatarBadge(avatar, profile);
}

function applyOwnProgress(profile) {
  const username = document.querySelector("#profile-username");
  const usernameInput = document.querySelector("#profile-username-input");
  if (username) {
    username.textContent = profile.username ? `@${profile.username}` : "";
    username.hidden = !profile.username || guestMode;
  }
  if (usernameInput && profile.username) usernameInput.value = `@${profile.username}`;
  const avatar = document.querySelector("#profile-avatar");
  let avatarUrl = profile.avatar_url;
  if (guestMode) {
    try {
      avatarUrl = localStorage.getItem(guestAvatarKey) || avatarUrl;
    } catch (error) {
      console.error("Nepavyko nuskaityti svečio profilio nuotraukos.", error);
    }
  }
  showOwnAvatar(avatar, avatarUrl, profile);
  const created = document.querySelector("#profile-created-date");
  if (created) created.textContent = profile.created_at ? formatDate(profile.created_at) : "Svečio profilis šiame įrenginyje";
  document.querySelector("#profile-xp-value")?.replaceChildren(`${profile.xp || 0} XP`);
  document.querySelector("#profile-streak-value")?.replaceChildren(String(profile.current_streak ?? profile.currentStreak ?? 0));
  const badges = document.querySelector("#profile-badges");
  const earnedBadges = profileBadges(profile);
  renderEarnedBadges(badges, earnedBadges, profile.featured_badge_id);
  const badgePicker = document.querySelector("#profile-featured-badge");
  if (badgePicker) {
    const selectedBadgeId = profile.featured_badge_id || "";
    badgePicker.replaceChildren(new Option("Nerodyti išskirtinio ženklelio", ""));
    earnedBadges.forEach((badge) => badgePicker.add(new Option(`${badge.icon} ${badge.title}`, badge.id)));
    badgePicker.value = earnedBadges.some((badge) => badge.id === selectedBadgeId) ? selectedBadgeId : "";
  }
  const bioInput = document.querySelector("#profile-bio");
  if (bioInput && typeof profile.bio === "string") bioInput.value = profile.bio;
  updateBioWordCount();
  const planName = document.querySelector("#profile-plan-name");
  const planDescription = document.querySelector("#profile-plan-description");
  const planBadge = document.querySelector("#profile-plan-badge");
  if (planName && planDescription && planBadge) {
    if (!profile.is_premium) {
      planName.textContent = "Nemokamas planas";
      planDescription.textContent = "Nemokamai: iki 15 klausimų ir 5 AI mokytojo nuotraukų per dieną.";
      planBadge.textContent = "AKTYVUS";
    } else if (profile.is_permanent_premium) {
      planName.textContent = "Premium · nuolatinė prieiga";
      planDescription.textContent = "Tavo Premium prieiga galioja be pabaigos datos.";
      planBadge.textContent = "AKTYVUS";
    } else if (profile.teacher_premium_until && new Date(profile.teacher_premium_until) > new Date()) {
      planName.textContent = "Premium · mokyklos planas";
      planDescription.textContent = `Mokytojo suteikta Premium prieiga galioja iki ${formatDate(profile.teacher_premium_until)}.`;
      planBadge.textContent = "AKTYVUS";
    } else {
      const expiration = profile.premium_until ? formatDate(profile.premium_until) : "nenurodyta";
      planName.textContent = profile.premium_trial_started_at ? "Premium · 7 dienų bandomasis" : "Premium prieiga";
      planDescription.textContent = `Neriboti klausimai ir AI mokytojo nuotraukos. Galioja iki ${expiration}.`;
      planBadge.textContent = profile.premium_trial_started_at ? "BANDOMASIS" : "AKTYVUS";
    }
  }
  const privacy = document.querySelector("#profile-private-account");
  if (privacy) {
    privacy.checked = Boolean(profile.is_private);
    privacy.disabled = guestMode;
  }
}

async function saveCommunitySettings() {
  const firstName = document.querySelector('[name="first_name"]')?.value.trim() || "";
  const lastName = document.querySelector('[name="last_name"]')?.value.trim() || "";
  const displayName = `${firstName} ${lastName}`.trim() || "Mokinys";
  const bio = document.querySelector("#profile-bio")?.value.trim() || "";
  const featuredBadgeId = document.querySelector("#profile-featured-badge")?.value || null;
  const nameError = validateProfileName(displayName);
  const bioError = validateProfileBio(bio);
  if (nameError || bioError) throw new Error(nameError || bioError);
  const profile = await updateCommunityProfile({
    displayName,
    avatarUrl: window.currentCommunityAvatarUrl || null,
    isPrivate: document.querySelector("#profile-private-account")?.checked || false,
    bio,
    featuredBadgeId,
  });
  applyOwnProgress(profile);
  setStatus("Profilio pakeitimai išsaugoti.", "success");
}

function updateBioWordCount() {
  const bio = document.querySelector("#profile-bio");
  const counter = document.querySelector("#profile-bio-count");
  if (!bio || !counter) return;
  const wordCount = bio.value.trim().split(/\s+/).filter(Boolean).length;
  counter.textContent = `${wordCount} / 200 žodžių`;
  counter.classList.toggle("is-over-limit", wordCount > 200);
}

function setTeacherFormStatus(element, message, kind = "info") {
  if (!element) return;
  element.textContent = message;
  element.className = `profile-status ${kind}`;
}

function initializeTeacherPremium(progressPromise = getMyProgress()) {
  const teacherSection = document.querySelector(".teacher-premium-section");
  const purchaseControls = document.querySelector("#teacher-purchase-controls");
  const roleStatus = document.querySelector("#teacher-role-status");
  const translate = (key, fallback, values = {}) => {
    const translated = window.testavimai?.t?.(key, values);
    return translated && translated !== key
      ? translated
      : fallback.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
  };
  const isSchoolPlan = () => String(planPicker?.value || "").startsWith("school_");
  const updatePurchaseDescription = () => {
    const description = document.querySelector("#teacher-premium-description");
    if (!description) return;
    const schoolPlan = isSchoolPlan();
    description.textContent = schoolPlan
      ? translate("premium_school_purchase_description", "Mokyklos vadovas vienu mokėjimu gali nupirkti Premium kodus visos mokyklos mokiniams. Mažiausias užsakymas – 150 mokinių; viršutinės mokinių skaičiaus ribos nėra.")
      : translate("premium_teacher_purchase_description", "Mokytojas vienu mokėjimu gali nupirkti 15–75 mokiniams Premium kodus.");
    const countLabel = document.querySelector("#teacher-student-count-label");
    if (countLabel) countLabel.textContent = translate(
      schoolPlan ? "premium_student_count_school" : "premium_student_count_teacher",
      schoolPlan ? "Mokinių skaičius (nuo 150)" : "Mokinių skaičius (15–75)",
    );
  };
  const syncPlanLimits = () => {
    const schoolPlan = isSchoolPlan();
    if (studentCountInput) {
      studentCountInput.min = schoolPlan ? "150" : "15";
      if (schoolPlan) studentCountInput.removeAttribute("max");
      else studentCountInput.max = "75";
      const current = Number(studentCountInput.value);
      if (current < Number(studentCountInput.min) || (!schoolPlan && current > 75)) {
        studentCountInput.value = studentCountInput.min;
      }
    }
    updatePurchaseDescription();
  };
  if (teacherSection && guestMode) {
    teacherSection.hidden = true;
  } else if (teacherSection) {
    teacherSection.hidden = false;
  }
  const accountTypeReady = guestMode ? Promise.resolve("") : progressPromise.then((progress) => {
    const accountType = ["teacher", "school_admin"].includes(progress.account_type) ? "teacher" : "";
    if (purchaseControls) purchaseControls.hidden = !accountType;
    if (roleStatus) {
      roleStatus.hidden = Boolean(accountType);
      roleStatus.textContent = "Mokyklos Premium paketus gali pirkti mokytojo / mokyklos vadovo paskyra. Jei gavai aktyvavimo kodą, gali jį panaudoti žemiau.";
    }
    if (accountType) {
      if (planPicker) planPicker.value = planPicker.querySelector("option")?.value || "";
      syncPlanLimits();
      updatePackageTotal();
    }
    return accountType;
  }).catch((error) => {
    console.error("Mokytojo paskyros tipo patikrinti nepavyko.", error);
    if (purchaseControls) purchaseControls.hidden = true;
    if (roleStatus) {
      roleStatus.hidden = false;
      roleStatus.textContent = `Mokytojo paskyros patikrinti nepavyko: ${error.message}`;
    }
    return "";
  });
  const packageForm = document.querySelector("#teacher-package-form");
  const packageStatus = document.querySelector("#teacher-package-status");
  const planPicker = document.querySelector("#teacher-package-plan");
  const studentCountInput = document.querySelector("#teacher-student-count");
  const total = document.querySelector("#teacher-package-total");
  const priceByPlan = {
    one_trimester: 199,
    two_trimesters: 299,
    school_year: 399,
    school_one_trimester: 99,
    school_two_trimesters: 199,
    school_three_trimesters: 299,
  };
  const planNames = {
    one_trimester: "1 trimestro planas",
    two_trimesters: "2 trimestrų planas",
    school_year: "mokslo metų planas",
    school_one_trimester: "mokyklos 1 trimestro planas",
    school_two_trimesters: "mokyklos 2 trimestrų planas",
    school_three_trimesters: "mokyklos 3 trimestrų planas",
  };
  const planNameKeys = {
    one_trimester: "premium_plan_name_teacher_one",
    two_trimesters: "premium_plan_name_teacher_two",
    school_year: "premium_plan_name_teacher_year",
    school_one_trimester: "premium_plan_name_school_one",
    school_two_trimesters: "premium_plan_name_school_two",
    school_three_trimesters: "premium_plan_name_school_three",
  };
  const planName = (plan) => translate(planNameKeys[plan], planNames[plan] || "mokyklos Premium");
  const codesSection = document.querySelector("#teacher-order-codes");
  const codesField = document.querySelector("#teacher-order-codes-list");
  const codesHeading = document.querySelector("#teacher-order-codes-heading");

  async function getCodesAfterPayment(sessionId) {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        return await getTeacherPurchaseCodes(sessionId);
      } catch (error) {
        if (!String(error.message).includes("Mokėjimas dar nepatvirtintas") || attempt === 4) throw error;
        setTeacherFormStatus(packageStatus, "Laukiama Stripe mokėjimo patvirtinimo…");
        await new Promise((resolve) => window.setTimeout(resolve, 1500));
      }
    }
    throw new Error("Mokėjimo patvirtinimas užtruko per ilgai. Atnaujink puslapį ir bandyk dar kartą.");
  }

  async function showPurchaseCodes(sessionId, purchaseDetails = null) {
    const purchase = await getTeacherPurchaseCodes(sessionId);
    if (codesField) codesField.value = purchase.codes.join("\n");
    if (codesSection) codesSection.hidden = false;
    if (codesHeading) {
      codesHeading.textContent = `Mokėjimas patvirtintas · ${purchase.student_count} kodų · ${planName(purchase.plan)}`;
    }
    setTeacherFormStatus(packageStatus, "Mokėjimas patvirtintas. Nukopijuok ir saugiai perduok kiekvienam mokiniui po vieną kodą.", "success");
    if (purchaseDetails) setTeacherFormStatus(historyStatus, `Parodyti kodai: ${planName(purchaseDetails.plan)}.`);
    return purchase;
  }

  const historyList = document.querySelector("#teacher-order-history-list");
  const historyStatus = document.querySelector("#teacher-order-history-status");

  async function loadTeacherPurchaseHistory() {
    if (!historyList) return;
    if (guestMode) {
      setTeacherFormStatus(historyStatus, "Pirkimų istorijai peržiūrėti prisijunk prie savo paskyros.");
      return;
    }
    try {
      const purchases = await getMyTeacherPurchases();
      historyList.replaceChildren();
      if (!purchases.length) {
        setTeacherFormStatus(historyStatus, "Apmokėtų mokyklos pirkimų dar nėra.");
        return;
      }
      purchases.forEach((purchase) => {
        const row = document.createElement("article");
        row.className = "teacher-order-item";
        const details = document.createElement("p");
        details.textContent = `${purchase.student_count} mokiniai · ${planName(purchase.plan)} · apmokėta ${formatDate(purchase.paid_at)}`;
        const button = document.createElement("button");
        button.className = "profile-secondary-button";
        button.type = "button";
        button.textContent = "Rodyti kodus";
        button.addEventListener("click", async () => {
          button.disabled = true;
          try {
            await showPurchaseCodes(purchase.session_id, purchase);
          } catch (error) {
            console.error("Mokyklos pirkimo kodų parodyti nepavyko.", error);
            setTeacherFormStatus(historyStatus, `Kodų įkelti nepavyko: ${error.message}`, "error");
          } finally {
            button.disabled = false;
          }
        });
        row.append(details, button);
        historyList.append(row);
      });
      setTeacherFormStatus(historyStatus, "");
    } catch (error) {
      console.error("Mokyklos pirkimų istorijos įkelti nepavyko.", error);
      setTeacherFormStatus(historyStatus, `Pirkimų istorijos įkelti nepavyko: ${error.message}`, "error");
    }
  }

  function updatePackageTotal() {
    const count = Number(studentCountInput?.value);
    const unitPrice = priceByPlan[planPicker?.value];
    const schoolPlan = isSchoolPlan();
    const minimumCount = schoolPlan ? 150 : 15;
    const maximumCount = !schoolPlan ? 75 : Math.floor(2147483647 / (unitPrice || 1));
    if (!Number.isSafeInteger(count) || count < minimumCount || count > maximumCount || !unitPrice || count * unitPrice > 2147483647) {
      if (total) total.textContent = translate("premium_total_invalid", "Įvesk tinkamą mokinių skaičių ir pasirink planą.");
      return;
    }
    const locale = document.documentElement.lang || "lt";
    const formatCurrency = (cents) => new Intl.NumberFormat(locale, { style: "currency", currency: "EUR" }).format(cents / 100);
    const planName = planNames[planPicker.value] || "Premium";
    if (total) total.textContent = translate("premium_total_line", "Vienkartinis mokėjimas · {unit} / mokiniui × {count} mokinių · iš viso {amount} už {period}.", {
      unit: formatCurrency(unitPrice),
      count,
      amount: formatCurrency(count * unitPrice),
      period: translate(planNameKeys[planPicker.value], planName),
    });
  }

  planPicker?.addEventListener("change", () => {
    syncPlanLimits();
    updatePackageTotal();
  });
  studentCountInput?.addEventListener("input", updatePackageTotal);
  document.addEventListener("testavimai:language-changed", () => {
    updatePackageTotal();
    accountTypeReady.then((type) => { if (type) updatePurchaseDescription(); });
  });
  updatePackageTotal();

  packageForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(packageForm);
    const studentCount = Number(form.get("student_count"));
    const selectedPlan = String(form.get("plan"));
    const isSchoolAdmin = selectedPlan.startsWith("school_");
    const minimumCount = isSchoolAdmin ? 150 : 15;
    const maximumCount = isSchoolAdmin ? Math.floor(2147483647 / (priceByPlan[selectedPlan] || 1)) : 75;
    const correctPlan = Boolean(priceByPlan[selectedPlan]);
    const termEndDates = [
      String(form.get("term_1_end") || ""),
      String(form.get("term_2_end") || ""),
      String(form.get("term_3_end") || ""),
    ];
    if (guestMode) {
      setTeacherFormStatus(packageStatus, "Mokyklos Premium paketui įsigyti prisijunk prie savo paskyros.", "error");
      return;
    }
    if (!Number.isSafeInteger(studentCount) || studentCount < minimumCount || studentCount > maximumCount) {
      setTeacherFormStatus(packageStatus, isSchoolAdmin
        ? "Mokyklos pirkimui pasirink bent 150 mokinių."
        : "Vienu mokytojo pirkimu galima pasirinkti nuo 15 iki 75 mokinių.", "error");
      return;
    }
    if (!correctPlan) {
      setTeacherFormStatus(packageStatus, "Pasirink šiai paskyrai skirtą Premium planą.", "error");
      return;
    }
    if (termEndDates.some((date) => !date) || !(termEndDates[0] < termEndDates[1] && termEndDates[1] < termEndDates[2])) {
      setTeacherFormStatus(packageStatus, "Įrašyk visas tris mokyklos kalendoriaus datas chronologine tvarka.", "error");
      return;
    }
    const button = packageForm.querySelector("[type=submit]");
    button.disabled = true;
    setTeacherFormStatus(packageStatus, "Atidaromas saugus Stripe atsiskaitymas…");
    try {
      const url = await createTeacherCheckoutSession({
        studentCount,
        plan: String(form.get("plan")),
        termEndDates,
      });
      window.location.assign(url);
    } catch (error) {
      console.error("Nepavyko pradėti mokyklos Premium pirkimo.", error);
      setTeacherFormStatus(packageStatus, `Mokėjimo pradėti nepavyko: ${error.message}`, "error");
    } finally {
      button.disabled = false;
    }
  });

  const codeForm = document.querySelector("#teacher-code-form");
  const codeStatus = document.querySelector("#teacher-code-status");
  codeForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (guestMode) {
      setTeacherFormStatus(codeStatus, "Mokyklos Premium kodą gali aktyvuoti tik prisijungęs prie paskyros.", "error");
      return;
    }
    const button = codeForm.querySelector("[type=submit]");
    button.disabled = true;
    setTeacherFormStatus(codeStatus, "Tikrinamas aktyvavimo kodas…");
    try {
      const form = new FormData(codeForm);
      const result = await redeemTeacherPremiumCode(String(form.get("code") || ""));
      setTeacherFormStatus(codeStatus, `Premium mokiniui aktyvuotas iki ${formatDate(result.access_until)}.`, "success");
      const profile = await getMyProgress();
      profile.teacher_premium_until = await getMyTeacherPremiumUntil();
      applyOwnProgress(profile);
    } catch (error) {
      console.error("Nepavyko aktyvuoti mokyklos Premium kodo.", error);
      setTeacherFormStatus(codeStatus, error.message, "error");
    } finally {
      button.disabled = false;
    }
  });

  document.querySelector("#teacher-copy-codes")?.addEventListener("click", async () => {
    const codes = document.querySelector("#teacher-order-codes-list")?.value;
    if (!codes) return;
    try {
      await navigator.clipboard.writeText(codes);
      setTeacherFormStatus(packageStatus, "Visi mokinių kodai nukopijuoti.", "success");
    } catch (error) {
      console.error("Mokinių kodų nukopijuoti nepavyko.", error);
      setTeacherFormStatus(packageStatus, "Kopijavimas nepavyko. Pažymėk kodų sąrašą ir nukopijuok jį rankiniu būdu.", "error");
    }
  });
  accountTypeReady.then((isTeacher) => {
    if (isTeacher) return loadTeacherPurchaseHistory();
  });

  const paymentStatus = new URLSearchParams(window.location.search).get("teacher_payment");
  if (paymentStatus === "success") {
    document.querySelector('[data-profile-tab="subscriptions"]')?.click();
    const sessionId = new URLSearchParams(window.location.search).get("session_id") || "";
    if (!/^cs_(test|live)_[A-Za-z0-9]+$/.test(sessionId)) {
      setTeacherFormStatus(packageStatus, "Mokėjimas atliktas, tačiau pirkimo nuoroda netinkama. Atnaujink puslapį arba kreipkis į administratorių.", "error");
      return;
    }
    setTeacherFormStatus(packageStatus, "Tikrinamas mokėjimas ir ruošiami kodai…");
    getCodesAfterPayment(sessionId).then(async (purchase) => {
      if (codesField) codesField.value = purchase.codes.join("\n");
      if (codesSection) codesSection.hidden = false;
      if (codesHeading) codesHeading.textContent = `Mokėjimas patvirtintas · ${purchase.student_count} kodų · ${planName(purchase.plan)}`;
      setTeacherFormStatus(packageStatus, "Mokėjimas patvirtintas. Nukopijuok ir saugiai perduok kiekvienam mokiniui po vieną kodą.", "success");
      if (await accountTypeReady) await loadTeacherPurchaseHistory();
    }).catch((error) => {
      console.error("Apmokėtų mokyklos kodų parodyti nepavyko.", error);
      setTeacherFormStatus(packageStatus, `Kodų įkelti nepavyko: ${error.message}`, "error");
    });
  } else if (paymentStatus === "cancelled") {
    document.querySelector('[data-profile-tab="subscriptions"]')?.click();
    setTeacherFormStatus(packageStatus, "Mokėjimas atšauktas. Paskyra nebuvo apmokestinta.");
  }
}

async function initializeProfile(progressPromise = getMyProgress()) {
  try {
    const [profile, teacherPremiumUntil] = await Promise.all([
      progressPromise,
      getMyTeacherPremiumUntil(),
    ]);
    profile.teacher_premium_until = teacherPremiumUntil;
    applyOwnProgress(profile);
    const bioInput = document.querySelector("#profile-bio");
    bioInput?.addEventListener("input", updateBioWordCount);
    bioInput?.addEventListener("blur", () => {
      const error = validateProfileBio(bioInput.value);
      if (error) setStatus(error, "error");
    });
    const privacy = document.querySelector("#profile-private-account");
    if (privacy && guestMode) setStatus("Privatumo ir viešo profilio nustatymai veikia tik prisijungus prie bendros paskyros.");
    privacy?.addEventListener("change", async () => {
      privacy.disabled = true;
      try {
        await saveCommunitySettings();
      } catch (error) {
        console.error("Nepavyko išsaugoti profilio privatumo nustatymo.", error);
        privacy.checked = !privacy.checked;
        setStatus(error.message, "error");
      } finally {
        privacy.disabled = guestMode;
      }
    });

    const avatarInput = document.querySelector("#profile-avatar-input");
    avatarInput?.addEventListener("change", async () => {
      const file = avatarInput.files?.[0];
      if (!file) return;
      try {
        const preparedImage = await prepareAvatarImage(file);
        if (guestMode) {
          const reader = new FileReader();
          const avatarData = await new Promise((resolve, reject) => {
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(new Error("Nepavyko nuskaityti pasirinktos nuotraukos."));
            reader.readAsDataURL(preparedImage);
          });
          localStorage.setItem(guestAvatarKey, avatarData);
          showOwnAvatar(document.querySelector("#profile-avatar"), avatarData);
          setStatus("Svečio profilio nuotrauka išsaugota šiame įrenginyje.", "success");
        } else {
          setStatus("Įkeliama profilio nuotrauka…");
          window.currentCommunityAvatarUrl = await uploadAvatar(preparedImage);
          await saveCommunitySettings();
          setStatus("Profilio nuotrauka atnaujinta.", "success");
        }
      } catch (error) {
        console.error("Nepavyko atnaujinti profilio nuotraukos.", error);
        setStatus(error.message, "error");
      } finally {
        avatarInput.value = "";
      }
    });
    const savedAvatarUrl = profile.avatar_url;
    if (savedAvatarUrl) window.currentCommunityAvatarUrl = savedAvatarUrl;
  } catch (error) {
    console.error("Nepavyko įkelti mokymosi profilio.", error);
    setStatus(error.message, "error");
  }
}

const page = document.body.dataset.communityPage;
if (page === "leaderboard") showLeaderboard().catch((error) => {
  console.error("Nepavyko įkelti leaderboard.", error);
  const migrationHint = ["PGRST202", "42883"].includes(error.code)
    ? " Atrodo, kad Supabase duomenų bazėje dar neįdiegtos mokymosi migracijos. Žr. supabase/README.md."
    : "";
  setStatus(`Leaderboard įkelti nepavyko: ${error.message}${migrationHint}`, "error");
});
if (page === "profile") showPublicProfile().catch((error) => {
  console.error("Nepavyko įkelti viešo profilio.", error);
  setStatus(`Profilio įkelti nepavyko: ${error.message}`, "error");
});
if (document.body.dataset.page === "profile") {
  const progressPromise = getMyProgress();
  initializeProfile(progressPromise);
  initializeTeacherPremium(progressPromise);
}
