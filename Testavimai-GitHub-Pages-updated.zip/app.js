const makeQuestions = (rows) => rows.map(([question, a, b, c, d, correct, explanation], questionIndex) => {
  const answers = [a, b, c, d];
  const offset = (questionIndex + 1) % answers.length;
  return {
    question,
    answers: [...answers.slice(offset), ...answers.slice(0, offset)],
    correct: (correct - offset + answers.length) % answers.length,
    explanation,
  };
});

const shuffledQuestions = (items) => {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result.map((item) => {
    const answerOrder = [0, 1, 2, 3];
    for (let index = answerOrder.length - 1; index > 0; index -= 1) {
      const swapIndex = Math.floor(Math.random() * (index + 1));
      [answerOrder[index], answerOrder[swapIndex]] = [answerOrder[swapIndex], answerOrder[index]];
    }
    return {
      ...item,
      answers: answerOrder.map((answerIndex) => item.answers[answerIndex]),
      correct: answerOrder.indexOf(item.correct),
      answerOrder,
    };
  });
};

const questions = {
  matematika: makeQuestions([
    ["Išspręsk lygtį: 3(x − 2) = 2x + 5.", "9", "11", "13", "−1", 1, "3x − 6 = 2x + 5, todėl x = 11."],
    ["Kam lygu 2⁵ · 2³ ÷ 2⁶?", "2", "4", "8", "16", 1, "Laipsnių rodikliai: 5 + 3 − 6 = 2, taigi 2² = 4."],
    ["Stačiojo trikampio statiniai yra 6 cm ir 8 cm. Kokia įžambinė?", "10 cm", "12 cm", "14 cm", "48 cm", 0, "Pagal Pitagoro teoremą c = √(6² + 8²) = √100 = 10 cm."],
    ["Kam lygu √50 + √18?", "√68", "5√2", "8√2", "68", 2, "√50 = 5√2, √18 = 3√2, taigi suma yra 8√2."],
    ["Funkcija y = 2x − 3. Kam lygus y, kai x = −4?", "−5", "−11", "5", "11", 1, "y = 2 · (−4) − 3 = −11."],
    ["Apskritimo spindulys 5 cm. Koks jo ilgis (π ≈ 3,14)?", "15,7 cm", "31,4 cm", "78,5 cm", "25 cm", 1, "C = 2πr = 2 · 3,14 · 5 = 31,4 cm."],
    ["Kokios yra lygties x² − 5x + 6 = 0 šaknys?", "−2 ir −3", "1 ir 6", "2 ir 3", "−1 ir −6", 2, "Šaknų suma 5, sandauga 6, todėl x = 2 ir x = 3."],
    ["Sprendžiama sistema x + y = 7, x − y = 1. Kam lygu x · y?", "10", "14", "7", "12", 3, "Sudėję lygtis gauname x = 4, tada y = 3, todėl x · y = 12."],
    ["Prekės kaina 80 € pabrango 25 %, o paskui atpigo 20 %. Kokia galutinė kaina?", "75 €", "80 €", "85 €", "100 €", 1, "80 · 1,25 = 100, o 100 · 0,8 = 80 €."],
    ["Aritmetinės progresijos pirmasis narys 4, skirtumas 3. Kam lygus dešimtasis narys?", "28", "34", "31", "40", 2, "a₁₀ = 4 + 9 · 3 = 31."],
    ["Kokia taisyklingojo šešiakampio vidaus kampų suma?", "540°", "720°", "900°", "360°", 1, "(6 − 2) · 180° = 720°."],
    ["Kam lygus sin 30°?", "√3/2", "√2/2", "1/2", "1", 2, "Tai lentelinė reikšmė: sin 30° = 1/2."],
    ["Išspręsk nelygybę: 5 − 2x > 11.", "x > −3", "x < −3", "x > 3", "x < 3", 1, "−2x > 6; dalijant iš neigiamo skaičiaus nelygybės ženklas pasikeičia: x < −3."],
    ["Užrašyk skaičių 0,00045 standartiniu pavidalu.", "4,5 · 10⁻³", "4,5 · 10⁻⁵", "4,5 · 10⁴", "4,5 · 10⁻⁴", 3, "Kablelį perstūmus 4 vietas į dešinę gauname 4,5 · 10⁻⁴."],
    ["Cilindro pagrindo spindulys 3 cm, aukštis 10 cm. Koks jo tūris?", "30π cm³", "60π cm³", "90π cm³", "900π cm³", 2, "V = πr²h = π · 9 · 10 = 90π cm³."],
    ["Dėžėje yra 3 raudoni ir 5 mėlyni rutuliai. Traukiami 2 rutuliai iš eilės negrąžinant. Kokia tikimybė, kad abu raudoni?", "3/28", "9/64", "1/4", "3/16", 0, "3/8 · 2/7 = 6/56 = 3/28."],
    ["Duomenų 2, 3, 3, 5, 12 mediana yra:", "3", "5", "3,5", "12", 0, "Penkių surikiuotų skaičių vidurinis narys yra 3."],
    ["Kokia mažiausia funkcijos y = x² − 4x + 3 reikšmė?", "−1", "0", "3", "−4", 0, "Viršūnė ties x = 2, o y = 4 − 8 + 3 = −1."],
    ["Supaprastink: (a + b)² − (a − b)².", "2ab", "4ab", "2a² + 2b²", "0", 1, "(a² + 2ab + b²) − (a² − 2ab + b²) = 4ab."],
    ["Trikampiai panašūs, panašumo koeficientas 3. Mažesniojo plotas 4 cm². Koks didesniojo plotas?", "12 cm²", "36 cm²", "16 cm²", "108 cm²", 1, "Plotų santykis lygus koeficiento kvadratui: 4 · 9 = 36 cm²."],
    ["Išskaidyk dauginamaisiais: x² − 49.", "(x − 7)²", "(x − 7)(x + 7)", "(x + 7)²", "x(x − 49)", 1, "Kvadratų skirtumas: a² − b² = (a − b)(a + b)."],
    ["Įbrėžtas apskritimo kampas remiasi į 80° lanką. Koks jo dydis?", "80°", "160°", "40°", "20°", 2, "Įbrėžtas kampas lygus pusei lanko: 80° ÷ 2 = 40°."],
    ["Išspręsk lygtį: |x − 3| = 5.", "8 ir −2", "8 ir 2", "−8 ir 2", "5 ir −5", 0, "x − 3 = 5 arba x − 3 = −5, taigi x = 8 arba x = −2."],
    ["Supaprastink: (2x³)² · x.", "4x⁶", "2x⁷", "4x⁷", "4x⁵", 2, "(2x³)² = 4x⁶, o 4x⁶ · x = 4x⁷."],
    ["Kokia yra tiesės, einančios per taškus (1; 3) ir (3; 7), lygtis?", "y = 2x + 1", "y = 2x + 3", "y = x + 2", "y = 4x − 1", 0, "Krypties koeficientas (7 − 3)/(3 − 1) = 2, o 3 = 2 · 1 + b, todėl b = 1."],
    ["Skaičiaus 30 % lygu 45. Kiek yra 20 % to skaičiaus?", "9", "15", "22,5", "30", 3, "Skaičius yra 45 ÷ 0,3 = 150, o 20 % iš 150 yra 30."],
    ["Kvadrato įstrižainė 10 cm. Koks kvadrato plotas?", "100 cm²", "25 cm²", "50 cm²", "20 cm²", 2, "Kvadrato plotas = d²/2 = 100/2 = 50 cm²."],
    ["Dviratininkas 2 val. važiavo 15 km/h greičiu, o 1 val. – 24 km/h. Koks vidutinis greitis?", "19,5 km/h", "18 km/h", "20 km/h", "17 km/h", 1, "Visas kelias 30 + 24 = 54 km per 3 val., todėl 54 ÷ 3 = 18 km/h."],
    ["Kuris skaičius yra iracionalusis?", "√49", "0,(3)", "√12", "−5/7", 2, "√12 negalima užrašyti paprastąja trupmena; √49 = 7, o 0,(3) = 1/3."],
    ["Kam lygus lygties 2x² − 3x − 5 = 0 diskriminantas?", "−31", "49", "19", "−49", 1, "D = (−3)² − 4 · 2 · (−5) = 9 + 40 = 49."],
  ]),
  "lietuvių kalba": makeQuestions([
    ["Kaip taisyklingai rašomas medžio pavadinimas?", "ąžuolas", "ąžouolas", "ažuolas", "ąžuolą", 0, "Medžio pavadinimas rašomas „ąžuolas“."],
    ["Kuris sakinys taisyklingai atskirtas kableliu?", "Žinau, kad tu ateisi.", "Žinau kad, tu ateisi.", "Žinau kad tu, ateisi.", "Žinau kad tu ateisi.", 0, "Šalutinis dėmuo „kad tu ateisi“ atskiriamas kableliu."],
    ["Kokia kalbos dalis yra žodis „greitai“?", "Būdvardis", "Veiksmažodis", "Prieveiksmis", "Daiktavardis", 2, "„Greitai“ yra prieveiksmis, nusakantis, kaip vyksta veiksmas."],
    ["Kas yra pasakotojas kūrinyje?", "Kūrinio skaitytojas", "Balsas, pasakojantis įvykius", "Visada pagrindinis veikėjas", "Visada autorius", 1, "Pasakotojas perteikia kūrinio įvykius; jis nebūtinai yra autorius."],
    ["Kuris žodis yra veiksmažodis?", "Žalias", "Skaityti", "Knyga", "Greitai", 1, "„Skaityti“ reiškia veiksmą, todėl yra veiksmažodis."],
    ["Kuris žodis yra daiktavardis?", "Bėgti", "Linksmas", "Miškas", "Vakar", 2, "„Miškas“ pavadina daiktą arba vietą, todėl yra daiktavardis."],
    ["Kuris žodis yra būdvardis?", "Dainuoti", "Mėlynas", "Vakar", "Stalas", 1, "„Mėlynas“ nusako daikto ypatybę."],
    ["Kokį klausimą dažniausiai atsako prieveiksmis „tyliai“?", "Koks?", "Kas?", "Kaip?", "Kiek?", 2, "„Tyliai“ atsako į klausimą „kaip?“."],
    ["Kuriame žodyje parašyta nosinė ę?", "kęsti", "kesti", "kėsti", "kysti", 0, "Taisyklinga forma yra „kęsti“."],
    ["Kuris sakinys yra klausiamasis?", "Šiandien šviečia saulė.", "Ar šiandien šviečia saulė?", "Kaip gražu lauke!", "Uždaryk langą.", 1, "Klausiamasis sakinys klausia ir baigiamas klaustuku."],
    ["Koks skyrybos ženklas rašomas sakinio pabaigoje po šūksnio?", "Kablelis", "Dvitaškis", "Šauktukas", "Kabutės", 2, "Šaukiamasis sakinys baigiamas šauktuku."],
    ["Kas kūrinyje vadinama tema?", "Kūrinio pavadinimas", "Apie ką kūrinys", "Autoriaus biografija", "Knygos puslapių skaičius", 1, "Tema nusako, apie ką kūrinyje kalbama."],
    ["Kas yra pagrindinė kūrinio mintis?", "Svarbiausia autoriaus perteikiama idėja", "Veikėjo vardas", "Kūrinio veiksmo vieta", "Knygos pavadinimas", 0, "Pagrindinė mintis nusako, ką kūriniu norima pasakyti."],
    ["Kaip vadinamas kūrinio veikėjas, kurio istorija svarbiausia?", "Pasakotojas", "Pagrindinis veikėjas", "Autorius", "Skaitytojas", 1, "Pagrindinis veikėjas yra svarbiausias kūrinio personažas."],
    ["Kuris žodis parašytas taisyklingai?", "ąžuolas", "ąžouolas", "ažuolas", "ąžuoląs", 0, "Taisyklinga rašyba – „ąžuolas“."],
    ["Kuris žodis yra būtojo laiko veiksmažodis?", "Skaito", "Skaitys", "Skaitė", "Skaityti", 2, "„Skaitė“ nusako praeityje vykusį veiksmą."],
    ["Kuriame sakinyje tinkamai vartojamas kablelis kreipiniui?", "Mama, ateik čia.", "Mama ateik, čia.", "Mama ateik čia.", "Mama, ateik, čia.", 0, "Kreipinys „Mama“ atskiriamas kableliu."],
    ["Koks yra žodžio „aukštas“ antonimas?", "Didelis", "Žemas", "Platus", "Ilgas", 1, "„Žemas“ yra priešingos reikšmės žodis."],
    ["Koks yra žodžio „džiaugsmas“ sinonimas?", "Liūdesys", "Rūpestis", "Laimė", "Pyktis", 2, "„Laimė“ yra artimos reikšmės žodis."],
    ["Kuris žodis yra įvardis?", "Mes", "Žalias", "Bėga", "Greitai", 0, "„Mes“ yra įvardis, pakeičiantis daiktavardį."],
    ["Kuriame sakinyje yra palyginimas?", "Ežeras buvo gilus.", "Ji greita kaip vėjas.", "Paukštis nuskrido.", "Atėjo vakaras.", 1, "Junginys „kaip vėjas“ lygina veikėjos greitį."],
    ["Ką eilėraštyje vadiname eilute?", "Vieną poezijos teksto eilę", "Knygos skyrių", "Pjesės veiksmą", "Pastraipos pavadinimą", 0, "Eilėraštį sudaro eilutės ir jų grupės – posmai."],
    ["Kaip vadinama kelių eilėraščio eilučių grupė?", "Pastraipa", "Posmas", "Skyrius", "Dialogas", 1, "Eilėraščio eilučių grupė vadinama posmu."],
    ["Kuris sakinys parašytas taisyklingai?", "Mes vakar lankėmės muziejuje.", "Mes vakar lankėsi muziejuje.", "Mes vakar lankysimės muziejuje vakar.", "Mes vakar lankaisi muziejuje.", 0, "„Mes lankėmės“ yra taisyklingai suderintos veiksmažodžio formos."],
    ["Kokia kalbos dalis yra žodis „penki“?", "Skaitvardis", "Prieveiksmis", "Būdvardis", "Jungtukas", 0, "„Penki“ nurodo skaičių, todėl yra skaitvardis."],
    ["Kuris žodis yra prielinksnis?", "Po", "Bet", "Jis", "Bėga", 0, "„Po“ yra prielinksnis, vartojamas su linksniuojamaisiais žodžiais."],
    ["Kokiu ženklu skiriama tiesioginė kalba?", "Tik kableliu", "Brūkšniu arba kabutėmis", "Tik dvitaškiu", "Skliaustais", 1, "Tiesioginė kalba dažnai išskiriama brūkšniu arba kabutėmis."],
    ["Kuriame žodyje yra priešdėlis?", "Pamiškė", "Miškas", "Miškininkas", "Miškingas", 0, "Žodyje „pamiškė“ priešdėlis „pa-“ eina prieš šaknį."],
    ["Ką pasakėčia dažnai siekia perteikti?", "Moralą arba pamokymą", "Istorinę datą", "Gamtos aprašymą", "Matematinę taisyklę", 0, "Pasakėčia dažnai baigiama moraliniu pamokymu."],
    ["Kuris žodis yra jungtukas?", "Ir", "Ant", "Jis", "Gražus", 0, "„Ir“ jungia žodžius ar sakinio dalis."],
  ]),
  istorija: makeQuestions([
    ["Kuriais metais Lietuva atkūrė nepriklausomybę?", "1988 m.", "1990 m.", "1991 m.", "1992 m.", 1, "Nepriklausomybė atkurta 1990 m. kovo 11 d."],
    ["Kurią dieną Lietuva atkūrė nepriklausomybę?", "Vasario 16-ąją", "Kovo 11-ąją", "Liepos 6-ąją", "Sausio 13-ąją", 1, "Lietuvos nepriklausomybė atkurta 1990 m. kovo 11 d."],
    ["Kas buvo pirmasis Lietuvos karalius?", "Vytautas Didysis", "Mindaugas", "Gediminas", "Algirdas", 1, "Mindaugas buvo pirmasis Lietuvos karalius."],
    ["Kada pasirašytas Lietuvos Nepriklausomybės Aktas?", "1918 m. vasario 16 d.", "1990 m. kovo 11 d.", "1253 m. liepos 6 d.", "1940 m. birželio 15 d.", 0, "Aktas pasirašytas 1918 m. vasario 16 dieną."],
    ["Kuriais metais karūnuotas Mindaugas?", "1009 m.", "1253 m.", "1387 m.", "1410 m.", 1, "Mindaugas karūnuotas 1253 m."],
    ["Kada minima Lietuvos valstybės atkūrimo diena?", "Vasario 16-ąją", "Kovo 11-ąją", "Liepos 6-ąją", "Sausio 13-ąją", 0, "Vasario 16-ąją minima 1918 m. valstybės atkūrimo diena."],
    ["Kada minima Lietuvos karaliaus Mindaugo karūnavimo diena?", "Vasario 16-ąją", "Kovo 11-ąją", "Liepos 6-ąją", "Rugsėjo 1-ąją", 2, "Liepos 6-ąją minima Mindaugo karūnavimo ir Valstybės diena."],
    ["Koks mūšis įvyko 1410 metais?", "Žalgirio mūšis", "Saulės mūšis", "Durbės mūšis", "Oršos mūšis", 0, "Žalgirio mūšis įvyko 1410 m."],
    ["Kas vadovavo Lietuvos ir Lenkijos kariuomenei Žalgirio mūšyje?", "Mindaugas ir Algirdas", "Jogaila ir Vytautas", "Gediminas ir Kęstutis", "Vytenis ir Traidenis", 1, "Mūšiui vadovavo Lenkijos karalius Jogaila ir Lietuvos didysis kunigaikštis Vytautas."],
    ["Koks miestas buvo Lietuvos Didžiosios Kunigaikštystės sostinė?", "Ryga", "Vilnius", "Krokuva", "Varšuva", 1, "Vilnius buvo Lietuvos Didžiosios Kunigaikštystės sostinė."],
    ["Kas buvo Lietuvos didysis kunigaikštis Gediminas?", "Vilniaus įkūrimo legendos valdovas", "Pirmasis Lietuvos karalius", "Žalgirio mūšio vadas", "1918 m. Akto signataras", 0, "Vilniaus įkūrimo legenda siejama su didžiuoju kunigaikščiu Gediminu."],
    ["Kada Lietuva pateko į Sovietų Sąjungos okupaciją?", "1918 m.", "1920 m.", "1940 m.", "1990 m.", 2, "Sovietų Sąjunga okupavo Lietuvą 1940 metais."],
    ["Kada prasidėjo Baltijos kelias?", "1989 m. rugpjūčio 23 d.", "1990 m. kovo 11 d.", "1918 m. vasario 16 d.", "1991 m. sausio 13 d.", 0, "Baltijos kelias vyko 1989 m. rugpjūčio 23 d."],
    ["Kokias tris valstybes sujungė Baltijos kelias?", "Lietuvą, Latviją ir Estiją", "Lietuvą, Lenkiją ir Latviją", "Estiją, Suomiją ir Švediją", "Latviją, Rusiją ir Estiją", 0, "Gyvoji grandinė sujungė Lietuvą, Latviją ir Estiją."],
    ["Kada vyko Sausio įvykiai Lietuvoje?", "1989 m. sausį", "1991 m. sausį", "1990 m. kovą", "1992 m. liepą", 1, "Sovietų agresija prieš Lietuvą vyko 1991 m. sausio 13 d."],
    ["Kokia buvo Lietuvos partizanų pagrindinė veikla po Antrojo pasaulinio karo?", "Kova už Lietuvos laisvę", "Žalgirio mūšio atkūrimas", "Prekyba Baltijos jūroje", "Knygnešystė spaudos draudimo metais", 0, "Partizanai ginklu priešinosi sovietų okupacijai ir kovojo už laisvę."],
    ["Kada panaikintas lietuviškos spaudos lotyniškais rašmenimis draudimas?", "1864 m.", "1904 m.", "1918 m.", "1940 m.", 1, "Draudimas panaikintas 1904 m."],
    ["Kas spaudos draudimo laikotarpiu slapta gabeno lietuviškas knygas?", "Knygnešiai", "Karvedžiai", "Amatininkai", "Kronikininkai", 0, "Knygnešiai platino lietuviškas knygas nepaisydami draudimo."],
    ["Kada įvyko Saulės mūšis?", "1236 m.", "1253 m.", "1387 m.", "1410 m.", 0, "Saulės mūšis įvyko 1236 metais."],
    ["Kuri valstybė kartu su Lietuva sudarė Abiejų Tautų Respubliką?", "Švedija", "Lenkija", "Prūsija", "Livonija", 1, "Abiejų Tautų Respubliką sudarė Lenkijos Karalystė ir Lietuvos Didžioji Kunigaikštystė."],
    ["Kada pasirašyta Liublino unija?", "1385 m.", "1410 m.", "1569 m.", "1795 m.", 2, "Liublino unija sudaryta 1569 metais."],
    ["Kokia buvo pirmoji Lietuvos Respublikos sostinė 1919 m.?", "Kaunas", "Klaipėda", "Vilnius", "Panevėžys", 0, "Kaunas tapo laikinąja sostine, kai Vilnius buvo užimtas."],
    ["Kada Lietuva tapo Europos Sąjungos nare?", "1990 m.", "1991 m.", "2004 m.", "2015 m.", 2, "Lietuva įstojo į Europos Sąjungą 2004 metais."],
    ["Kada Lietuva tapo NATO nare?", "1991 m.", "2004 m.", "2007 m.", "2015 m.", 1, "Lietuva į NATO įstojo 2004 metais."],
    ["Kas buvo Lietuvos karalius, karūnuotas 1253 metais?", "Mindaugas", "Gediminas", "Vytautas", "Jogaila", 0, "Mindaugas karūnuotas Lietuvos karaliumi 1253 m."],
    ["Kada įvyko Durbės mūšis?", "1236 m.", "1260 m.", "1323 m.", "1410 m.", 1, "Durbės mūšis įvyko 1260 metais."],
    ["Koks įvykis pažymimas Kovo 11-ąją?", "Lietuvos nepriklausomybės atkūrimas", "Pirmojo Nepriklausomybės Akto pasirašymas", "Mindaugo karūnavimas", "Žalgirio mūšis", 0, "Kovo 11-ąją minima 1990 m. paskelbta nepriklausomybės atkūrimo diena."],
    ["Kokia buvo svarbiausia 1918 m. vasario 16 d. Akto reikšmė?", "Paskelbta nepriklausoma Lietuvos valstybė", "Įkurta Europos Sąjunga", "Lietuva įstojo į NATO", "Panaikinta baudžiava", 0, "Aktu paskelbta nepriklausoma Lietuvos valstybė."],
    ["Kokiu būdu istorikai tiria praeitį?", "Naudoja šaltinius ir juos kritiškai vertina", "Remiasi vien legendomis", "Atspėja įvykius", "Nenaudoja jokių įrodymų", 0, "Istorikai analizuoja rašytinius, daiktinius ir kitus istorijos šaltinius."],
    ["Kuri data siejama su Lietuvos įstojimu į Europos Sąjungą?", "2004 m. gegužės 1 d.", "1990 m. kovo 11 d.", "1918 m. vasario 16 d.", "2001 m. rugsėjo 1 d.", 0, "Lietuva Europos Sąjungos nare tapo 2004 m. gegužės 1 d."],
  ]),
  biologija: makeQuestions([
    ["Kuri ląstelės dalis saugo genetinę informaciją?", "Branduolys", "Membrana", "Citoplazma", "Vakuolė", 0, "Eukariotinių ląstelių genetinė informacija saugoma branduolyje."],
    ["Kokių dujų augalai išskiria fotosintezės metu?", "Azoto", "Anglies dioksido", "Deguonies", "Vandenilio", 2, "Fotosintezės metu augalai išskiria deguonį."],
    ["Kiek kamerų turi žmogaus širdis?", "Dvi", "Trys", "Keturias", "Šešias", 2, "Širdį sudaro du prieširdžiai ir du skilveliai."],
    ["Kuri augalo dalis sugeria vandenį iš dirvožemio?", "Žiedas", "Lapas", "Šaknis", "Vaisius", 2, "Šaknys sugeria vandenį ir mineralines medžiagas."],
    ["Ko reikia fotosintezei?", "Šviesos, vandens ir anglies dioksido", "Tik deguonies", "Tik dirvožemio", "Azoto ir cukraus", 0, "Fotosintezei augalui reikia šviesos, vandens ir anglies dioksido."],
    ["Kokia ląstelės dalis reguliuoja, kas patenka į ląstelę ir iš jos išeina?", "Ląstelės membrana", "Branduolėlis", "Chromosoma", "Ribosoma", 0, "Membrana atskiria ląstelę nuo aplinkos ir reguliuoja medžiagų judėjimą."],
    ["Kurios ląstelės dalys augalams suteikia žalią spalvą?", "Chloroplastai", "Mitochondrijos", "Branduoliai", "Ribosomos", 0, "Chloroplastuose yra žalio pigmento chlorofilo."],
    ["Kokia yra pagrindinė raudonųjų kraujo kūnelių funkcija?", "Pernešti deguonį", "Virškinti maistą", "Gaminti hormonus", "Saugoti kaulus", 0, "Raudonieji kraujo kūneliai hemoglobinu perneša deguonį."],
    ["Kuris organas pumpuoja kraują?", "Plaučiai", "Širdis", "Skrandis", "Inkstai", 1, "Širdies susitraukimai varinėja kraują kraujagyslėmis."],
    ["Kokia yra plaučių pagrindinė funkcija?", "Dujų apykaita", "Maisto virškinimas", "Kraujo gamyba", "Judėjimo valdymas", 0, "Plaučiuose kraujas pasisavina deguonį ir pašalina anglies dioksidą."],
    ["Kuri maisto medžiaga yra svarbiausias greitos energijos šaltinis?", "Angliavandeniai", "Vanduo", "Mineralinės medžiagos", "Vitaminai", 0, "Angliavandeniai organizmui suteikia lengvai panaudojamos energijos."],
    ["Kuris organas pradeda baltymų virškinimą?", "Skrandis", "Plaučiai", "Širdis", "Šlapimo pūslė", 0, "Skrandyje fermentai pradeda skaidyti baltymus."],
    ["Kaip vadinamas gyvūnas, mintantis tik augalais?", "Plėšrūnas", "Žolėdis", "Visaėdis", "Parazitas", 1, "Žolėdžiai minta augalais."],
    ["Kas yra ekosistema?", "Organizmų ir jų aplinkos visuma", "Tik vienas gyvūnas", "Tik negyvoji gamta", "Gyvūnų rūšies pavadinimas", 0, "Ekosistemą sudaro organizmai ir jų tarpusavio ryšiai su aplinka."],
    ["Kuris organizmas yra gamintojas mitybos grandinėje?", "Žalias augalas", "Vilkas", "Grybas", "Erelis", 0, "Augalai gamina organines medžiagas fotosintezės būdu."],
    ["Kokia DNR funkcija?", "Saugo paveldimą informaciją", "Virškina maistą", "Perneša deguonį", "Sutraukia raumenis", 0, "DNR saugo instrukcijas, svarbias organizmo požymiams ir veiklai."],
    ["Kaip vadinamas organizmo požymių perdavimas palikuonims?", "Paveldimumas", "Fotosintezė", "Kvėpavimas", "Virškinimas", 0, "Paveldimumu požymiai perduodami iš tėvų palikuonims."],
    ["Kuri organizmo sistema perduoda signalus nervais?", "Nervų sistema", "Virškinimo sistema", "Atramos sistema", "Kvėpavimo sistema", 0, "Nervų sistema priima ir perduoda signalus."],
    ["Kokie kaulai saugo smegenis?", "Kaukolės kaulai", "Šonkauliai", "Slanksteliai", "Dubens kaulai", 0, "Smegenis saugo kaukolė."],
    ["Koks procesas leidžia organizmui gauti energijos iš maisto medžiagų?", "Ląstelinis kvėpavimas", "Fotosintezė", "Apdulkinimas", "Garavimas", 0, "Ląstelinio kvėpavimo metu maisto medžiagos skaidomos ir išlaisvinama energija."],
    ["Kuri augalo dalis daugiausia vykdo fotosintezę?", "Lapas", "Šaknis", "Sėkla", "Vaisius", 0, "Lapuose gausu chloroplastų, todėl jie dažniausiai vykdo fotosintezę."],
    ["Kaip vadinama žiedadulkių pernaša ant piestelės purkos?", "Apdulkinimas", "Dygimas", "Garavimas", "Kvėpavimas", 0, "Apdulkinimo metu žiedadulkės patenka ant piestelės purkos."],
    ["Kokia yra pagrindinė inkstų funkcija?", "Filtruoti kraują ir gaminti šlapimą", "Pumpuoti kraują", "Skaidyti maistą burnoje", "Valdyti judesius", 0, "Inkstai filtruoja kraują ir šalina medžiagų apykaitos atliekas."],
    ["Kuris mikroorganizmas naudojamas jogurtui gaminti?", "Pieno rūgšties bakterijos", "Virusai", "Dumbliai", "Daugialąsčiai grybai", 0, "Pieno rūgšties bakterijos raugina pieną ir padeda gaminti jogurtą."],
    ["Ką rodo biologinė įvairovė?", "Gyvybės formų įvairovę", "Vienos rūšies individų dydį", "Vandens temperatūrą", "Dirvožemio spalvą", 0, "Biologinė įvairovė apima skirtingų rūšių, genų ir ekosistemų įvairovę."],
    ["Kuris gyvūnas yra stuburinis?", "Varliagyvis", "Sliekas", "Sraigė", "Medūza", 0, "Varliagyviai turi stuburą ir priklauso stuburiniams."],
    ["Kokia kraujo dalis padeda kovoti su ligų sukėlėjais?", "Baltieji kraujo kūneliai", "Raudonieji kraujo kūneliai", "Kraujo plazmos cukrus", "Trombocitų pigmentas", 0, "Baltieji kraujo kūneliai yra svarbi imuninės sistemos dalis."],
    ["Koks reiškinys vyksta, kai vanduo iš lapų pasišalina garų pavidalu?", "Transpiracija", "Apvaisinimas", "Dygimas", "Fermentacija", 0, "Transpiracija – vandens garų išsiskyrimas iš augalo, daugiausia per lapus."],
    ["Kurią funkciją atlieka griaučiai?", "Palaiko kūną ir saugo vidaus organus", "Gaminti tulžį", "Perneša orą į plaučius", "Virškina angliavandenius", 0, "Griaučiai palaiko kūną, padeda judėti ir saugo dalį vidaus organų."],
    ["Kaip vadinamas organizmas, mintantis ir augalais, ir gyvūnais?", "Visaėdis", "Žolėdis", "Gamintojas", "Parazitas", 0, "Visaėdžiai minta ir augalinės, ir gyvūninės kilmės maistu."],
  ]),
  fizika: makeQuestions([
    ["Koks yra jėgos matavimo vienetas?", "Niutonas (N)", "Džaulis (J)", "Vatas (W)", "Metras (m)", 0, "Jėga matuojama niutonais (N)."],
    ["Koks yra greičio apskaičiavimo būdas?", "Kelias padalytas iš laiko", "Laikas padalytas iš kelio", "Masė padauginta iš tūrio", "Jėga padalyta iš ploto", 0, "Greitis v = s/t, kelias padalijamas iš laiko."],
    ["Kokiu vienetu matuojama masė?", "Kilogramais", "Metrais", "Sekundėmis", "Džauliais", 0, "Masės SI vienetas yra kilogramas (kg)."],
    ["Kokia temperatūra pagal Celsijų atitinka vandens užšalimą normaliomis sąlygomis?", "0 °C", "10 °C", "50 °C", "100 °C", 0, "Normaliomis sąlygomis vanduo užšąla ties 0 °C."],
    ["Kokia energija sukaupta pakeltame kūne?", "Potencinė", "Tik garso", "Tik šviesos", "Cheminė degimo", 0, "Pakeltas kūnas turi gravitacinę potencinę energiją."],
    ["Kokiu vienetu matuojama elektros srovė?", "Amperais", "Voltais", "Omais", "Vatais", 0, "Elektros srovės stipris matuojamas amperais (A)."],
    ["Koks prietaisas matuoja elektros srovės stiprį?", "Ampermetras", "Termometras", "Dinamometras", "Barometras", 0, "Elektros srovės stiprį matuoja ampermetras."],
    ["Kokia šviesos sklidimo ypatybė pastebima šešėlyje?", "Šviesa sklinda tiesiomis linijomis", "Šviesa visada sklinda ratu", "Šviesai reikia garso", "Šviesa sklinda tik vandenyje", 0, "Vienalytėje terpėje šviesa sklinda tiesiomis linijomis."],
    ["Kaip vadinama jėga, kuri traukia kūnus prie Žemės?", "Gravitacijos jėga", "Tamprumo jėga", "Elektros srovė", "Trinties šiluma", 0, "Žemės gravitacija traukia kūnus jos centro link."],
    ["Koks yra garso sklidimo greitis ore maždaug kambario temperatūroje?", "Apie 340 m/s", "Apie 3 m/s", "Apie 3 000 km/s", "Apie 30 km/s", 0, "Ore garsas sklinda maždaug 340 m/s greičiu."],
    ["Kurioje terpėje garsas negali sklisti?", "Vakuume", "Vandenyje", "Ore", "Pliene", 0, "Garsui sklisti reikia dalelių, todėl vakuume jis sklinda negali."],
    ["Kaip apskaičiuojamas tankis?", "Masė padalyta iš tūrio", "Tūris padalytas iš masės", "Masė padauginta iš laiko", "Jėga padalyta iš greičio", 0, "Tankis ρ = m/V."],
    ["Koks yra ilgio SI matavimo vienetas?", "Metras", "Kilogramas", "Sekundė", "Kelvinas", 0, "Ilgio SI vienetas yra metras (m)."],
    ["Kas nutinka šviesai, kai ji atsispindi nuo veidrodžio?", "Ji pakeičia sklidimo kryptį", "Ji virsta garsu", "Ji visada sustoja", "Ji praranda visą energiją", 0, "Veidrodžio paviršius atspindi šviesą ir pakeičia jos kryptį."],
    ["Koks yra elektros įtampos matavimo vienetas?", "Voltas (V)", "Amperas (A)", "Omas (Ω)", "Niutonas (N)", 0, "Elektros įtampa matuojama voltais (V)."],
    ["Kas yra elektros grandinei būtina, kad tekėtų srovė?", "Uždara grandinė ir energijos šaltinis", "Atviras laidas", "Tik plastikinė liniuotė", "Garso šaltinis", 0, "Srovė teka uždara grandine, kai yra įtampos šaltinis."],
    ["Kuri medžiaga gerai praleidžia elektros srovę?", "Varis", "Guma", "Sausas medis", "Plastikas", 0, "Varis yra geras elektros laidininkas."],
    ["Kuri medžiaga yra elektros izoliatorius?", "Guma", "Varis", "Aliuminis", "Geležis", 0, "Guma prastai praleidžia elektros srovę ir naudojama izoliacijai."],
    ["Kokia jėga stabdo slystančio paviršiaus judėjimą?", "Trinties jėga", "Archimedo jėga", "Elektros įtampa", "Gravitacinė energija", 0, "Trinties jėga priešinasi besiliečiančių paviršių judėjimui."],
    ["Koks yra vandens virimo taškas normaliomis sąlygomis?", "100 °C", "0 °C", "50 °C", "212 °C", 0, "Esant normaliam atmosferos slėgiui vanduo verda ties 100 °C."],
    ["Kaip vadinamas kietosios medžiagos virtimas skysčiu?", "Lydymasis", "Garavimas", "Kondensacija", "Kietėjimas", 0, "Lydymosi metu kietoji medžiaga virsta skysčiu."],
    ["Kaip vadinamas dujų virtimas skysčiu?", "Kondensacija", "Lydymasis", "Garavimas", "Sublimacija", 0, "Kondensacijos metu dujos virsta skysčiu."],
    ["Koks prietaisas matuoja temperatūrą?", "Termometras", "Ampermetras", "Dinamometras", "Svarstyklės", 0, "Temperatūrai matuoti naudojamas termometras."],
    ["Kaip apskaičiuojamas mechaninis darbas, kai jėga veikia judėjimo kryptimi?", "Jėga × kelias", "Jėga ÷ laikas", "Masė × temperatūra", "Greitis ÷ kelias", 0, "Darbas W = F × s, kai jėga veikia judėjimo kryptimi."],
    ["Koks yra galios matavimo vienetas?", "Vatas (W)", "Džaulis (J)", "Niutonas (N)", "Paskalis (Pa)", 0, "Galia matuojama vatais (W)."],
    ["Kuri energijos rūšis siejama su judančiu kūnu?", "Kinetinė energija", "Tik potencinė energija", "Cheminė energija", "Branduolio krūvis", 0, "Judantis kūnas turi kinetinę energiją."],
    ["Koks jėgos poveikis gali pakeisti kūno judėjimą?", "Keisti greitį arba kryptį", "Keisti kūno spalvą", "Visada padidinti temperatūrą", "Panaikinti masę", 0, "Jėga gali pakeisti kūno greitį, judėjimo kryptį arba formą."],
    ["Ką rodo svarstyklės, kai sveriame daiktą?", "Masę", "Ilgį", "Temperatūrą", "Elektros srovę", 0, "Svarstyklėmis kasdienėje aplinkoje nustatoma kūno masė."],
    ["Kaip šiluma paprastai sklinda metalo strypu nuo karšto galo?", "Šilumos laidumu", "Tik garso banga", "Tik vakuume", "Elektros izoliacija", 0, "Metaluose šiluma sklinda laidumu."],
    ["Kurioje terpėje šviesa sklinda greičiausiai?", "Vakuume", "Vandenyje", "Stikle", "Deimante", 0, "Šviesa greičiausiai sklinda vakuume."],
  ]),
};

const subjectNames = {
  matematika: "Matematika",
  "lietuvių kalba": "Lietuvių kalba ir literatūra",
  istorija: "Istorija",
  biologija: "Biologija",
  fizika: "Fizika",
};

const questionList = document.querySelector("#practice-questions");
const practiceSubject = document.querySelector("#practice-subject");
const practiceStatus = document.querySelector("#practice-status");
const checkButton = document.querySelector("#check-answers");
const submitSelfTestButton = document.querySelector("#submit-self-test");
const questionPageLabel = document.querySelector("#question-page-label");
const previousQuestionButton = document.querySelector("#previous-question");
const nextQuestionButton = document.querySelector("#next-question");
const selfTestTimer = document.querySelector("#self-test-timer");
const selfTestTime = document.querySelector("#self-test-time");
const selfTestMode = new URLSearchParams(window.location.search).get("testas") === "1";
const selfTestExitButton = document.querySelector("#exit-self-test");
const selfTestDurationSeconds = 15 * 60;
const selfTestDifficulties = {
  easy: { label: "Lengvas · easy", index: 0 },
  medium: { label: "Vidutinis · medium", index: 1 },
  hard: { label: "Sunkus · hard", index: 2 },
};
const selfTestLevel = selfTestDifficulties[new URLSearchParams(window.location.search).get("difficulty")];
const selfTestContext = document.querySelector("#self-test-context");
const selfTestLimitContext = document.querySelector("#self-test-limit-context");
const selfTestRecommendation = document.querySelector("#self-test-recommendation");
const selfTestDifficultyDescription = document.querySelector("#self-test-difficulty-description");
const selfTestDifficultyDescriptions = {
  easy: "Lengvas lygis: pagrindinės sąvokos ir paprastesni uždaviniai.",
  medium: "Vidutinis lygis: mišrūs klausimai, žinių taikymas ir kelių žingsnių uždaviniai.",
  hard: "Sunkus lygis: sudėtingesni klausimai ir savarankiškas žinių taikymas.",
};
const selfTestDailyLimit = 15;
const selfTestDraftKey = selfTestMode
  ? `testavimai-self-test-draft-${new URLSearchParams(window.location.search).get("dalykas")}-${new URLSearchParams(window.location.search).get("difficulty")}`
  : "";
let recommendedNextDifficulty = null;
if (!selfTestMode && document.querySelector("#self-test-difficulty")) {
  const difficultyPicker = document.querySelector("#self-test-difficulty");
  const updateDifficultyDescription = () => {
    if (selfTestDifficultyDescription) {
      selfTestDifficultyDescription.textContent = selfTestDifficultyDescriptions[difficultyPicker.value];
    }
  };
  difficultyPicker.addEventListener("change", updateDifficultyDescription);
  updateDifficultyDescription();
}
if (!selfTestMode && document.querySelector("#self-test-difficulty")) {
  try {
    const savedDifficulty = localStorage.getItem("testavimai-self-test-recommended-difficulty");
    if (selfTestDifficulties[savedDifficulty]) {
      document.querySelector("#self-test-difficulty").value = savedDifficulty;
      if (selfTestDifficultyDescription) {
        selfTestDifficultyDescription.textContent = selfTestDifficultyDescriptions[savedDifficulty];
      }
      if (selfTestRecommendation) {
        selfTestRecommendation.textContent = window.testavimai?.t("adaptive_recommendation", {
          level: selfTestDifficulties[savedDifficulty].label,
        }) || `Kitas rekomenduojamas sunkumas: ${selfTestDifficulties[savedDifficulty].label}.`;
        selfTestRecommendation.hidden = false;
      }
    }
  } catch (error) {
    console.error("Nepavyko nuskaityti rekomenduojamo testo sunkumo.", error);
  }
}
let currentSubject = "";
let checkedAnswers = new Set();
let correctAnswers = new Set();
let currentQuestionIndex = 0;
let selfTestSubmitted = false;
let selfTestStarted = false;
let selfTestTimedOut = false;
let allowSelfTestExit = false;
let selfTestDeadline = 0;
let selfTestTimerInterval;
let selfTestQuestionLimit = null;
const selfTestQuestionBanks = new Map();

if (selfTestMode) {
  document.body.classList.add("self-test-focus-mode");
  const selfTestModeLabel = document.querySelector(".self-test-mode-label");
  if (selfTestModeLabel) selfTestModeLabel.hidden = false;
  if (selfTestExitButton) selfTestExitButton.hidden = false;
  const brandLink = document.querySelector(".site-header .brand");
  brandLink?.removeAttribute("href");
  brandLink?.setAttribute("aria-disabled", "true");
  brandLink?.setAttribute("aria-label", "Testavimai");
  brandLink?.setAttribute("tabindex", "-1");
}

window.addEventListener("beforeunload", (event) => {
  if (!selfTestMode || !selfTestStarted || selfTestSubmitted || allowSelfTestExit) return;
  event.preventDefault();
  event.returnValue = "";
});

selfTestExitButton?.addEventListener("click", () => {
  if (!window.confirm("Ar tikrai norite išeiti iš testo? Neužbaigti atsakymai bus prarasti.")) return;
  allowSelfTestExit = true;
  window.location.replace("index.html");
});

function subjectQuestions(subject) {
  const bank = questions[subject];
  if (!selfTestMode || !selfTestLevel) return bank;
  if (selfTestQuestionBanks.has(subject)) return selfTestQuestionBanks.get(subject);
  const start = Math.floor(bank.length * selfTestLevel.index / 3);
  const end = Math.floor(bank.length * (selfTestLevel.index + 1) / 3);
  const levelQuestions = shuffledQuestions(bank.slice(start, end).map((item, index) => ({
    ...item,
    sourceQuestionIndex: start + index,
  })));
  const selectedQuestions = selfTestQuestionLimit === null ? levelQuestions : levelQuestions.slice(0, selfTestQuestionLimit);
  selfTestQuestionBanks.set(subject, selectedQuestions);
  return selectedQuestions;
}

function questionCountLabel(count) {
  const lastTwoDigits = count % 100;
  if ((lastTwoDigits >= 11 && lastTwoDigits <= 19) || count % 10 === 0) return `${count} klausimų`;
  return count % 10 === 1 ? `${count} klausimas` : `${count} klausimai`;
}

function updateSelfTestTimer() {
  if (!selfTestMode || selfTestSubmitted || !selfTestTime) return;
  const secondsRemaining = Math.max(0, Math.ceil((selfTestDeadline - Date.now()) / 1000));
  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  selfTestTime.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  selfTestTimer.classList.toggle("is-low", secondsRemaining <= 5 * 60);
  if (secondsRemaining === 0) submitSelfTest(true);
}

function startSelfTestTimer(deadline = null) {
  if (!selfTestTimer || !selfTestTime) return;
  window.clearInterval(selfTestTimerInterval);
  selfTestTimer.hidden = false;
  selfTestDeadline = deadline || Date.now() + selfTestDurationSeconds * 1000;
  updateSelfTestTimer();
  selfTestTimerInterval = window.setInterval(updateSelfTestTimer, 1000);
}

function readSelfTestDraft(subject) {
  try {
    const stored = JSON.parse(localStorage.getItem(selfTestDraftKey) || "null");
    const age = Date.now() - Number(stored?.savedAt);
    if (!stored || stored.subject !== subject || stored.difficulty !== selfTestLevel.label
      || !Number.isFinite(age) || age < 0 || age > 24 * 60 * 60 * 1000
      || !Number.isFinite(stored.deadline) || stored.deadline <= Date.now()
      || !Number.isSafeInteger(stored.currentIndex) || stored.currentIndex < 0
      || !stored.answers || typeof stored.answers !== "object" || Array.isArray(stored.answers)) {
      localStorage.removeItem(selfTestDraftKey);
      return null;
    }
    return stored;
  } catch (error) {
    console.error("Nepavyko atkurti bandomojo testo juodraščio.", error);
    return null;
  }
}

function saveSelfTestDraft() {
  if (!selfTestMode || selfTestSubmitted || !currentSubject || !selfTestDeadline) return;
  try {
    const answers = {};
    subjectQuestions(currentSubject).forEach((item, index) => {
      const selected = questionList.querySelector(`[data-question="${index}"] input:checked`);
      if (selected) answers[item.sourceQuestionIndex] = item.answers[Number(selected.value)];
    });
    localStorage.setItem(selfTestDraftKey, JSON.stringify({
      subject: currentSubject,
      difficulty: selfTestLevel.label,
      savedAt: Date.now(),
      deadline: selfTestDeadline,
      currentIndex: currentQuestionIndex,
      answers,
    }));
  } catch (error) {
    console.error("Nepavyko išsaugoti bandomojo testo juodraščio.", error);
    practiceStatus.textContent = `Testo juodraščio išsaugoti nepavyko: ${error.message}`;
  }
}

function createSelfTestReportLink(item) {
  const link = document.createElement("a");
  link.className = "practice-question-report";
  const questionId = `worksheet-${currentSubject}-${item.sourceQuestionIndex ?? "practice"}`;
  const testDetails = selfTestMode ? `\nTesto lygis: ${selfTestLevel.label}` : "";
  const number = Number.isInteger(item.sourceQuestionIndex) ? `\nKlausimo Nr.: ${item.sourceQuestionIndex + 1}` : "";
  link.href = `mailto:pagalba@testavimai.lt?subject=${encodeURIComponent("Netikslumas Testavimai klausime")}&body=${encodeURIComponent(`Klausimo ID: ${questionId}\nDalykas: ${currentSubject}${testDetails}${number}\nKlausimas: ${item.question}\n\nAprašyk pastebėtą netikslumą:`)}`;
  link.textContent = "Pranešti apie klausimo netikslumą";
  return link;
}

function updateQuestionPage() {
  const fieldsets = [...questionList.querySelectorAll(".practice-question")];
  if (fieldsets.length === 0) return;
  fieldsets.forEach((fieldset, index) => {
    fieldset.hidden = index !== currentQuestionIndex;
  });
  questionPageLabel.textContent = `${currentQuestionIndex + 1} / ${fieldsets.length}`;
  previousQuestionButton.disabled = currentQuestionIndex === 0;
  nextQuestionButton.disabled = currentQuestionIndex === fieldsets.length - 1;

  const total = subjectQuestions(currentSubject).length;
  if (selfTestMode) {
    checkButton.hidden = true;
    submitSelfTestButton.hidden = selfTestSubmitted;
    const answered = fieldsets.filter((fieldset) => fieldset.querySelector("input:checked")).length;
    if (selfTestSubmitted) {
      const percentage = Math.round((correctAnswers.size / total) * 100);
      const timeoutMessage = selfTestTimedOut ? " Laikas baigėsi; neatsakyti klausimai įvertinti 0 taškų." : "";
      practiceStatus.textContent = `Rezultatas: ${correctAnswers.size} iš ${total} teisingai · ${percentage} %. Peržiūri klausimą ${currentQuestionIndex + 1} iš ${total}.${timeoutMessage}`;
      if (recommendedNextDifficulty) {
        const recommendation = window.testavimai?.t("adaptive_recommendation", {
          level: selfTestDifficulties[recommendedNextDifficulty].label,
        }) || `Kitas rekomenduojamas sunkumas: ${selfTestDifficulties[recommendedNextDifficulty].label}.`;
        practiceStatus.textContent += ` ${recommendation}`;
      }
    } else {
      practiceStatus.textContent = `Klausimas ${currentQuestionIndex + 1} iš ${total} · Atsakyta ${answered} iš ${total}.`;
    }
    return;
  }

  checkButton.hidden = false;
  submitSelfTestButton.hidden = true;
  checkButton.disabled = checkedAnswers.has(currentQuestionIndex);
  if (checkedAnswers.size === total) {
    const percentage = Math.round((correctAnswers.size / total) * 100);
    practiceStatus.textContent = `Rezultatas: ${correctAnswers.size} iš ${total} teisingai · ${percentage} % · Užduotis ${currentQuestionIndex + 1} iš ${total}.`;
  } else {
    practiceStatus.textContent = `Užduotis ${currentQuestionIndex + 1} iš ${total} · Patikrinta ${checkedAnswers.size} iš ${total}.`;
  }
}

function renderWorksheet(subject) {
  if (!questionList || !questions[subject]) return;
  currentSubject = subject;
  checkedAnswers = new Set();
  correctAnswers = new Set();
  currentQuestionIndex = 0;
  selfTestSubmitted = false;
  selfTestTimedOut = false;
  if (selfTestMode) selfTestStarted = true;
  document.querySelectorAll(".practice-subject-button").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.worksheetSubject === subject);
    button.setAttribute("aria-pressed", String(button.dataset.worksheetSubject === subject));
  });
  if (selfTestContext) selfTestContext.hidden = !selfTestMode;
  const subjectPicker = document.querySelector("#practice-subject-picker");
  const subjectBank = subjectQuestions(subject);
  let restoredDraft = null;
  if (subjectPicker) subjectPicker.hidden = selfTestMode;
  if (selfTestMode) {
    document.querySelector("#self-test-difficulty-name").textContent = selfTestLevel.label;
    document.querySelector("#practice-heading").textContent = "Bandomasis testas.";
    const instructions = subjectBank.length === 1
      ? "Atsakyk į 1 klausimą."
      : `Atsakyk į visus ${subjectBank.length} klausimus.`;
    document.querySelector(".worksheet-heading > p").textContent = `${instructions} Pateikus testą bus parodyti atsakymai ir rezultatas${window.testavimai?.showExplanations?.() === false ? "." : " bei paaiškinimai."}`;
    restoredDraft = readSelfTestDraft(subject);
  } else if (selfTestTimer) {
    selfTestTimer.hidden = true;
    selfTestTimer.classList.remove("is-low");
    window.clearInterval(selfTestTimerInterval);
  }
  practiceSubject.textContent = subjectNames[subject];
  document.querySelector(".worksheet-panel-heading span").textContent = selfTestMode
    ? `${questionCountLabel(subjectBank.length)} · po vieną puslapyje`
    : `${subjectBank.length} užduočių · po vieną puslapyje`;
  practiceStatus.textContent = `${selfTestMode ? "Klausimas" : "Užduotis"} 1 iš ${subjectBank.length} · ${selfTestMode ? "Atsakyta" : "Patikrinta"} 0 iš ${subjectBank.length}.`;
  questionList.replaceChildren();

  subjectBank.forEach((item, questionIndex) => {
    const fieldset = document.createElement("fieldset");
    fieldset.className = "practice-question";
    fieldset.dataset.question = String(questionIndex);
    const legend = document.createElement("legend");
    legend.tabIndex = -1;
    legend.innerHTML = `<span class="practice-number">${String(questionIndex + 1).padStart(2, "0")}</span><span></span>`;
    legend.lastElementChild.textContent = item.question;
    fieldset.append(legend);
    const difficulty = document.createElement("p");
    difficulty.className = "practice-question-level";
    const levelName = { easy: "Lengvas", medium: "Vidutinis", hard: "Sunkus" }[new URLSearchParams(window.location.search).get("difficulty")] || "Praktika";
    difficulty.textContent = `${levelName} lygis · Pasirinkimo klausimas`;
    fieldset.append(difficulty);

    const options = document.createElement("div");
    options.className = "practice-options";
    item.answers.forEach((answer, answerIndex) => {
      const label = document.createElement("label");
      label.className = "practice-option";
      const input = document.createElement("input");
      input.type = "radio";
      input.name = `question-${questionIndex}`;
      input.value = String(answerIndex);
      input.setAttribute("aria-label", answer);
      const text = document.createElement("span");
      text.textContent = answer;
      label.append(input, text);
      options.append(label);
    });
    const explanation = document.createElement("p");
    explanation.className = "practice-explanation";
    explanation.hidden = true;
    const report = createSelfTestReportLink(item);
    const answerResult = document.createElement("p");
    answerResult.className = "practice-answer-result";
    answerResult.setAttribute("aria-live", "polite");
    answerResult.hidden = true;
    fieldset.append(options, answerResult, explanation);
    if (report) fieldset.append(report);
    questionList.append(fieldset);
  });

  if (selfTestMode) {
    subjectBank.forEach((item, index) => {
      const savedAnswer = restoredDraft?.answers?.[item.sourceQuestionIndex];
      if (typeof savedAnswer !== "string") return;
      const answerIndex = item.answers.indexOf(savedAnswer);
      if (answerIndex >= 0) {
        const radio = questionList.querySelector(`[data-question="${index}"] input[value="${answerIndex}"]`);
        if (radio) radio.checked = true;
      }
    });
    currentQuestionIndex = Math.min(restoredDraft?.currentIndex || 0, subjectBank.length - 1);
    startSelfTestTimer(restoredDraft?.deadline || null);
    if (restoredDraft) {
      document.querySelector(".worksheet-heading > p").textContent =
        "Atkūrėme neišsiųstą testą. Tavo pažymėti atsakymai ir likęs laikas išsaugoti šiame įrenginyje.";
    }
  }
  checkButton.textContent = "Tikrinti atsakymą";
  checkButton.hidden = selfTestMode;
  submitSelfTestButton.hidden = !selfTestMode;
  questionPageLabel.hidden = false;
  previousQuestionButton.hidden = false;
  nextQuestionButton.hidden = false;
  updateQuestionPage();
  if (selfTestMode) saveSelfTestDraft();
  const url = new URL(window.location.href);
  url.searchParams.set("dalykas", subject);
  history.replaceState(null, "", `${url.pathname}${url.search}#praktika`);
}

async function recordWorksheetAnswers(questionIds, answerIndices) {
  if (!questionIds.length) return;
  try {
    const { recordPracticeAnswers } = await import("./progress.js");
    const result = await recordPracticeAnswers(questionIds, answerIndices);
    const answers = result.answers || [];
    try {
      const { recordSubjectAttempt } = await import("./learning-summary.js");
      answers.forEach((answer, index) => {
        const subject = questionIds[index]?.match(/^worksheet-(.*)-\d+$/)?.[1];
        if (subject && typeof answer.is_correct === "boolean") {
          recordSubjectAttempt(subject, answer.is_correct, selfTestMode ? `${selfTestLevel.label} bandomasis testas` : "Bendros žinios");
        }
      });
    } catch (error) {
      console.error("Nepavyko atnaujinti dalykų pažangos suvestinės.", error);
    }
    if (result.progress?.is_guest || answers.some((answer) => answer.is_guest)) {
      const correct = answers.filter((answer) => answer.is_correct).length;
      practiceStatus.textContent = `Atsakymai patikrinti: ${correct} teisingi iš ${answers.length}. Svečio režime XP ir pasiekimai nekaupiami.`;
      return;
    }
    const gained = answers.reduce((total, answer) => total + (answer.points_delta || 0), 0);
    const correct = answers.filter((answer) => answer.is_correct).length;
    const bonus = answers.some((answer) => answer.streak_bonus) ? " Pasiekta 10 dienų serija — papildomi 80 XP!" : "";
    const quota = result.unprocessed_answers
      ? ` Dienos 15 klausimų limitas pasiektas; į pažangą įrašyta ${answers.length} klausimų.`
      : "";
    practiceStatus.textContent = `Atsakymai įrašyti: ${correct} teisingi iš ${answers.length} · ${gained > 0 ? "+" : ""}${gained} XP.${bonus}${quota}`;
  } catch (error) {
    console.error("Nepavyko išsaugoti užduočių XP.", error);
    practiceStatus.textContent = `Atsakymai patikrinti, bet XP įrašyti nepavyko: ${error.message}`;
  }
}

async function checkWorksheet() {
  if (!currentSubject || selfTestMode) return;
  try {
    const { getMyProgress } = await import("./progress.js");
    const progress = await getMyProgress();
    if (!progress.is_premium && Number(progress.daily_questions_remaining || 0) <= 0) {
      practiceStatus.textContent = "Šiandien išnaudojai 15 nemokamų klausimų. Premium nariams dienos klausimų limitas netaikomas.";
      return;
    }
  } catch (error) {
    console.error("Nepavyko patikrinti dienos klausimų limito.", error);
    practiceStatus.textContent = `Nepavyko patikrinti dienos klausimų limito: ${error.message}`;
    return;
  }
  const items = subjectQuestions(currentSubject);
  const fieldset = questionList.querySelector(`[data-question="${currentQuestionIndex}"]`);
  const selected = fieldset.querySelector("input:checked");
  if (!selected) {
    practiceStatus.textContent = "Pasirink atsakymą ir tada spausk „Tikrinti atsakymą“.";
    return;
  }

  const item = items[currentQuestionIndex];
  const isCorrect = Number(selected.value) === item.correct;
  const explanation = fieldset.querySelector(".practice-explanation");
  const answerResult = fieldset.querySelector(".practice-answer-result");
  fieldset.classList.remove("is-correct", "is-incorrect");
  fieldset.classList.add(isCorrect ? "is-correct" : "is-incorrect");
  answerResult.textContent = isCorrect ? "Teisingai." : "Dar ne visai.";
  answerResult.hidden = false;
  explanation.textContent = `${isCorrect ? "Teisingai. " : "Dar ne visai. "}${item.explanation}`;
  fieldset.querySelector(".practice-explanation-steps")?.remove();
  if (item.steps?.length && window.testavimai?.showExplanations?.() !== false) {
    const steps = document.createElement("ol");
    steps.className = "practice-explanation-steps";
    item.steps.forEach((step) => {
      const stepItem = document.createElement("li");
      stepItem.textContent = step;
      steps.append(stepItem);
    });
    explanation.after(steps);
  }
  explanation.hidden = window.testavimai?.showExplanations?.() === false;
  checkedAnswers.add(currentQuestionIndex);
  if (isCorrect) correctAnswers.add(currentQuestionIndex);
  else correctAnswers.delete(currentQuestionIndex);
  updateQuestionPage();
  recordWorksheetAnswers(
    [`worksheet-${currentSubject}-${item.sourceQuestionIndex ?? currentQuestionIndex}`],
    [item.answerOrder?.[Number(selected.value)] ?? Number(selected.value)],
  );
}

function submitSelfTest(timedOut = false) {
  if (!selfTestMode || !currentSubject || selfTestSubmitted) return;
  const fieldsets = [...questionList.querySelectorAll(".practice-question")];
  const unansweredIndex = fieldsets.findIndex((fieldset) => !fieldset.querySelector("input:checked"));
  if (!timedOut && unansweredIndex !== -1) {
    currentQuestionIndex = unansweredIndex;
    updateQuestionPage();
    practiceStatus.textContent = `Dar neatsakyta į ${fieldsets.length - fieldsets.filter((fieldset) => fieldset.querySelector("input:checked")).length} klausimus. Atsakyk į visus prieš pateikdamas testą.`;
    return;
  }

  fieldsets.forEach((fieldset, index) => {
    const item = subjectQuestions(currentSubject)[index];
    const selectedInput = fieldset.querySelector("input:checked");
    const isCorrect = selectedInput !== null && Number(selectedInput.value) === item.correct;
    const answerResult = fieldset.querySelector(".practice-answer-result");
    const explanation = fieldset.querySelector(".practice-explanation");
    fieldset.classList.add(isCorrect ? "is-correct" : selectedInput ? "is-incorrect" : "is-unanswered");
    answerResult.textContent = selectedInput ? (isCorrect ? "Teisingai." : "Dar ne visai.") : "Neatsakyta.";
    answerResult.hidden = false;
    explanation.textContent = `${selectedInput ? (isCorrect ? "Teisingai. " : "Dar ne visai. ") : "Neatsakyta. "}${item.explanation}`;
    explanation.hidden = window.testavimai?.showExplanations?.() === false;
    fieldset.querySelectorAll("input").forEach((input) => { input.disabled = true; });
    checkedAnswers.add(index);
    if (isCorrect) correctAnswers.add(index);
  });

  selfTestSubmitted = true;
  selfTestTimedOut = timedOut;
  try {
    localStorage.removeItem(selfTestDraftKey);
  } catch (error) {
    console.error("Nepavyko pašalinti užbaigto testo juodraščio.", error);
  }
  const scorePercent = Math.round((correctAnswers.size / fieldsets.length) * 100);
  import("./learning-summary.js").then(({ recordTestResult }) => {
    return recordTestResult({
      title: `${subjectNames[currentSubject]} · ${selfTestLevel.label}`,
      subject: subjectNames[currentSubject],
      difficulty: selfTestLevel.label,
      correct: correctAnswers.size,
      total: fieldsets.length,
    });
  }).catch((error) => {
    console.error("Bandomojo testo rezultato išsaugoti nepavyko.", error);
    practiceStatus.textContent += " Testo istorijos įrašyti nepavyko.";
  });
  const currentDifficulty = new URLSearchParams(window.location.search).get("difficulty");
  const difficultyIndex = selfTestDifficulties[currentDifficulty]?.index ?? 1;
  const nextIndex = fieldsets.length < 5
    ? difficultyIndex
    : scorePercent >= 85
      ? Math.min(2, difficultyIndex + 1)
      : scorePercent <= 50
        ? Math.max(0, difficultyIndex - 1)
        : difficultyIndex;
  recommendedNextDifficulty = Object.keys(selfTestDifficulties).find((key) => selfTestDifficulties[key].index === nextIndex);
  try {
    if (recommendedNextDifficulty) {
      localStorage.setItem("testavimai-self-test-recommended-difficulty", recommendedNextDifficulty);
    }
  } catch (error) {
    console.error("Nepavyko išsaugoti rekomenduojamo testo sunkumo.", error);
  }
  window.clearInterval(selfTestTimerInterval);
  if (selfTestTime) selfTestTime.textContent = timedOut ? "00:00" : selfTestTime.textContent;
  if (selfTestTimer) {
    selfTestTimer.classList.remove("is-low");
    selfTestTimer.querySelector("span").textContent = timedOut ? "Laikas baigėsi" : "Testas pateiktas";
  }
  updateQuestionPage();
  const scoredAnswers = fieldsets.flatMap((fieldset, index) => {
    const selected = fieldset.querySelector("input:checked");
    if (!selected) return [];
    const item = subjectQuestions(currentSubject)[index];
    return [{
      questionId: `worksheet-${currentSubject}-${item.sourceQuestionIndex ?? index}`,
      answerIndex: item.answerOrder?.[Number(selected.value)] ?? Number(selected.value),
    }];
  });
  recordWorksheetAnswers(
    scoredAnswers.map((answer) => answer.questionId),
    scoredAnswers.map((answer) => answer.answerIndex),
  );
}

questionList?.addEventListener("change", (event) => {
  if (!event.target.matches("input[type=radio]")) return;
  if (selfTestMode) {
    saveSelfTestDraft();
    updateQuestionPage();
    return;
  }
  const fieldset = event.target.closest(".practice-question");
  const index = Number(fieldset.dataset.question);
  if (!checkedAnswers.has(index)) return;
  checkedAnswers.delete(index);
  correctAnswers.delete(index);
  fieldset.classList.remove("is-correct", "is-incorrect");
  fieldset.querySelector(".practice-explanation").hidden = true;
  fieldset.querySelector(".practice-answer-result").hidden = true;
  if (index === currentQuestionIndex) updateQuestionPage();
});

previousQuestionButton?.addEventListener("click", () => {
  if (currentQuestionIndex === 0) return;
  currentQuestionIndex -= 1;
  saveSelfTestDraft();
  updateQuestionPage();
  questionList.querySelector(".practice-question:not([hidden]) legend")?.focus();
});

nextQuestionButton?.addEventListener("click", () => {
  if (!currentSubject || currentQuestionIndex >= subjectQuestions(currentSubject).length - 1) return;
  currentQuestionIndex += 1;
  saveSelfTestDraft();
  updateQuestionPage();
  questionList.querySelector(".practice-question:not([hidden]) legend")?.focus();
});

document.querySelectorAll("[data-worksheet-subject]").forEach((button) => {
  button.addEventListener("click", () => {
    const subject = button.dataset.worksheetSubject;
    window.location.href = `praktika.html?dalykas=${encodeURIComponent(subject)}`;
  });
});

checkButton?.addEventListener("click", checkWorksheet);
submitSelfTestButton?.addEventListener("click", submitSelfTest);

window.addEventListener("pagehide", () => {
  if (!selfTestMode) return;
  saveSelfTestDraft();
  window.clearInterval(selfTestTimerInterval);
  questionList?.querySelectorAll("input[type=radio]").forEach((input) => { input.checked = false; });
});

window.addEventListener("pageshow", (event) => {
  if (selfTestMode && event.persisted) window.location.reload();
});

const selfTestStatus = document.querySelector("#self-test-status");
document.querySelectorAll("[data-self-test-subject]").forEach((button) => {
  button.addEventListener("click", () => {
    const difficulty = document.querySelector("#self-test-difficulty").value;
    const subject = button.dataset.selfTestSubject;
    const url = new URL("testas.html", window.location.href);
    url.searchParams.set("testas", "1");
    url.searchParams.set("difficulty", difficulty);
    url.searchParams.set("dalykas", subject);
    url.hash = "praktika";
    window.location.href = url.href;
  });
});

if (questionList) {
  const requestedSubject = new URLSearchParams(window.location.search).get("dalykas");
  if (selfTestMode) {
    const allowedTestSubjects = ["lietuvių kalba", "matematika", "istorija", "biologija", "fizika"];
    if (selfTestLevel && allowedTestSubjects.includes(requestedSubject) && questions[requestedSubject]) {
      if (selfTestLimitContext) selfTestLimitContext.textContent = "Tikrinamas likęs dienos klausimų limitas...";
      import("./progress.js").then(({ getMyProgress }) => getMyProgress())
        .then((progress) => {
          const levelCount = Math.floor(questions[requestedSubject].length * (selfTestLevel.index + 1) / 3)
            - Math.floor(questions[requestedSubject].length * selfTestLevel.index / 3);
          if (!progress.is_premium) {
            selfTestQuestionLimit = Math.min(levelCount, Number(progress.daily_questions_remaining || 0));
            if (selfTestLimitContext) {
              selfTestLimitContext.textContent = selfTestQuestionLimit === 0
                ? `Išnaudotas ${selfTestDailyLimit} nemokamų dienos klausimų limitas. Premium naudotojams jis netaikomas.`
                : `Nemokamas dienos limitas bendrai praktikai ir testams: liko ${progress.daily_questions_remaining} iš ${selfTestDailyLimit} klausimų. Šiame teste bus iki ${selfTestQuestionLimit === 1 ? "1 klausimo" : `${selfTestQuestionLimit} klausimų`}.`;
            }
          } else if (selfTestLimitContext) {
            selfTestLimitContext.textContent = "Premium naudotojams dienos klausimų limitas netaikomas. Šiame teste – iki 10 klausimų.";
          }
          if (!progress.is_premium && selfTestQuestionLimit <= 0) {
            if (selfTestContext) selfTestContext.hidden = false;
            document.querySelector("#self-test-difficulty-name").textContent = selfTestLevel.label;
            practiceStatus.textContent = "Šiandien išnaudojai 15 nemokamų klausimų, skirtų bendrai praktikai ir testams. Premium nariams dienos klausimų limitas netaikomas.";
            checkButton.hidden = true;
            submitSelfTestButton.hidden = true;
            questionPageLabel.hidden = true;
            previousQuestionButton.hidden = true;
            nextQuestionButton.hidden = true;
            return;
          }
          renderWorksheet(requestedSubject);
        })
        .catch((error) => {
          console.error("Nepavyko patikrinti bandomojo testo dienos limito.", error);
          if (selfTestLimitContext) selfTestLimitContext.textContent = "Dienos klausimų limito patikrinti nepavyko.";
          practiceStatus.textContent = `Nepavyko patikrinti bandomojo testo dienos limito: ${error.message}`;
        });
    } else {
      if (selfTestContext) selfTestContext.hidden = false;
      document.querySelector("#self-test-difficulty-name").textContent = selfTestLevel?.label || "nepasirinktas sunkumas";
      practiceStatus.textContent = "Testo nuoroda netaisyklinga. Grįžk į pradžią ir pasirink sunkumą bei dalyką.";
      checkButton.hidden = true;
      submitSelfTestButton.hidden = true;
      questionPageLabel.hidden = true;
      previousQuestionButton.hidden = true;
      nextQuestionButton.hidden = true;
    }
  } else if (requestedSubject && questions[requestedSubject]) {
    renderWorksheet(requestedSubject);
  }
}

const homeProgressRing = document.querySelector("#home-progress-ring");
const homeLimitNote = document.querySelector("#self-test-limit-note");
if (homeProgressRing || homeLimitNote) {
  import("./progress.js").then(({ getMyProgress }) => getMyProgress())
    .then((progress) => {
      if (homeProgressRing) {
        const correctToday = Math.max(0, Number(progress.correct_today ?? progress.correctToday ?? 0));
        const currentStreak = Math.max(0, Number(progress.current_streak ?? progress.currentStreak ?? 0));
        document.querySelector("#home-correct-today").textContent = String(correctToday);
        document.querySelector("#home-current-streak").textContent = String(currentStreak);
        homeProgressRing.style.strokeDashoffset = String(308 - (308 * Math.min(5, correctToday)) / 5);
        document.querySelector("#home-progress-note").textContent = correctToday >= 5
          ? "Šiandienos tikslas pasiektas"
          : `Dar ${5 - correctToday} iki dienos tikslo`;
      }
      if (homeLimitNote) {
        homeLimitNote.textContent = progress.is_premium
          ? "Premium naudotojams dienos klausimų limitas netaikomas. Viename teste – iki 10 klausimų."
          : `Šiandien liko ${progress.daily_questions_remaining} iš 15 nemokamų klausimų bendrai praktikai ir testams. Viename teste – iki 10 klausimų.`;
      }
    })
    .catch((error) => {
      console.error("Nepavyko įkelti pradžios puslapio pažangos ir dienos limito.", error);
      if (homeProgressRing) document.querySelector("#home-progress-note").textContent = "Pažangos įkelti nepavyko";
      if (homeLimitNote) homeLimitNote.textContent = "Dienos klausimų limito patikrinti nepavyko. Perkrauk puslapį ir bandyk dar kartą.";
    });
}

const searchInput = document.querySelector("#subject-search");
const cards = [...document.querySelectorAll(".subject-card")];
const noResults = document.querySelector("#no-results");

searchInput?.addEventListener("input", () => {
  const query = searchInput.value.trim().toLocaleLowerCase("lt-LT");
  let visibleCount = 0;
  cards.forEach((card) => {
    const matches = card.dataset.subject.toLocaleLowerCase("lt-LT").includes(query);
    card.hidden = !matches;
    if (matches) visibleCount += 1;
  });
  if (noResults) noResults.hidden = visibleCount > 0;
});

document.addEventListener("keydown", (event) => {
  if (event.key === "/" && searchInput && document.activeElement !== searchInput) {
    event.preventDefault();
    searchInput.focus();
  }
});
